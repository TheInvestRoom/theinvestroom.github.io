---
name: animation
description: Tous les styles d'animation, et le montage complet de ceux déjà créés dans ce projet.
argument-hint: "[ton mot à commenter]"
disable-model-invocation: true
---

Mot pour l'appel à commenter : $ARGUMENTS

Les styles disponibles :
- /trajet : Ville en 3D, un trajet qui se dessine
- /une : Une de journal, le surligneur passe
- /lavis : Paysage à l'encre qui se peint seul
- /eclate : Vue éclatée, chaque couche nommée
- /table : La preuve posée sur la table, annotée
- /chiffre : Un grand nombre, une courbe, une note
- /appli : Maquette d'application sur un téléphone
- /demo : Démo de logiciel avec un curseur qui clique
- /frise : Frise de dates en diagonale

Regarde les compositions enregistrées dans le fichier Root du projet.
- S'il n'y en a aucune parmi ces styles, n'écris aucun code : affiche cette liste et dis comment lancer une commande (exemple : `/lavis La rivière n'a pas de nom`).
- Sinon, fais le montage avec celles qui existent, sans en inventer d'autres, et enregistre-le avec l'id exact `Montage` :

Dans ce projet Remotion, assemble mes compositions en un Reel muet de 22 s. Pour chaque style, 2,7 s : un écran de chat sombre où l'on tape /nom-du-style sur un clavier AZERTY dessiné (la touche grossit à chaque lettre), le message part, une ligne « Animation avec nom-du-style… » apparaît avec une étoile qui tourne, l'animation démarre dans une carte du chat, puis la carte grandit jusqu'au plein écran. Termine sur une grille de 9 tuiles qui se remplissent une à une, chaque animation rejouée en petit, avec un titre au-dessus et mon appel à commenter : [mon mot]. Ne mets aucun son : j'ajouterai la musique sur Instagram.

Règles :
- Adapte la durée et la grille finale au nombre de styles présents. S'il n'y a pas de mot, retire l'appel à commenter.
- Aucun crochet ni texte modèle ne doit rester à l'écran.
- Termine en vérifiant le code avec `npx tsc --noEmit`, puis indique la commande d'aperçu : `npx remotion studio`.
