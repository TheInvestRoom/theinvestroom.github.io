---
name: appli
description: Maquette d'application sur un téléphone. Crée une animation Remotion de 3 s, en code, sans générateur vidéo.
argument-hint: "[ton contenu]"
disable-model-invocation: true
---

Contenu donné : $ARGUMENTS

Dans ce projet Remotion, crée une composition 1080×1920 à 30 i/s, 3 s, sans image. Fond gris clair en dégradé. Un téléphone sombre aux coins très arrondis arrive du bas, légèrement tourné en 3D, puis se redresse. Sur son écran : un libellé, un montant qui compte jusqu'à [24 860 €], une courbe verte qui se trace, un sélecteur de période et trois lignes qui apparaissent l'une après l'autre. Trois petites cartes blanches avec ombre douce sortent ensuite autour du téléphone, avec un léger rebond. Contenu de l'application : [mon appli et mes écrans].

Règles :
- Les passages entre crochets sont des exemples. Remplace-les par le contenu donné ci-dessus ; s'il est vide, garde les exemples. N'invente pas de chiffre présenté comme réel.
- Aucun crochet ni texte modèle (« [titre] », « [date] », « [mon événement] ») ne doit rester à l'écran. Si une information manque, écris un exemple réaliste et neutre, ou retire cet élément.
- Crée un fichier par composition, et enregistre-la dans le fichier Root du projet avec l'id exact `Appli` (durée 90 images), sans toucher aux autres compositions.
- Si ce dossier n'est pas un projet Remotion, dis-le et donne la commande pour en créer un : `npx create-video@latest --yes --blank mon-projet`.
- Tout doit rester dans le cadre 1080×1920 et l'animation doit se calculer avec useCurrentFrame, sans Math.random (utilise `random()` de Remotion).
- Termine en vérifiant le code avec `npx tsc --noEmit`, puis indique la commande d'aperçu : `npx remotion studio`.
