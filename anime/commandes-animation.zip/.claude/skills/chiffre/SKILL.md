---
name: chiffre
description: Un grand nombre, une courbe, une note. Crée une animation Remotion de 3 s, en code, sans générateur vidéo.
argument-hint: "[ton contenu]"
disable-model-invocation: true
---

Contenu donné : $ARGUMENTS

Dans ce projet Remotion, crée une composition 1080×1920 à 30 i/s, 3 s, sans image. Fond noir, en-tête en police mono, puis un nombre géant qui compte de [0,4] à [4,2] avec des chiffres de largeur fixe et une unité plus petite [M m²]. Sous le nombre, une courbe avec axe des années se trace en même temps que le compteur : le point final reste calé sur le chiffre affiché. Blanche jusqu'à un point de bascule, elle devient orange après. Ce point reçoit une annotation : une date, un titre et une ligne [mon événement]. Ajoute une petite pastille orange [× 10]. Utilise seulement mes données : [mes valeurs par année].

Règles :
- Les passages entre crochets sont des exemples. Remplace-les par le contenu donné ci-dessus ; s'il est vide, garde les exemples. N'invente pas de chiffre présenté comme réel.
- Aucun crochet ni texte modèle (« [titre] », « [date] », « [mon événement] ») ne doit rester à l'écran. Si une information manque, écris un exemple réaliste et neutre, ou retire cet élément.
- Crée un fichier par composition, et enregistre-la dans le fichier Root du projet avec l'id exact `Chiffre` (durée 90 images), sans toucher aux autres compositions.
- Si ce dossier n'est pas un projet Remotion, dis-le et donne la commande pour en créer un : `npx create-video@latest --yes --blank mon-projet`.
- Tout doit rester dans le cadre 1080×1920 et l'animation doit se calculer avec useCurrentFrame, sans Math.random (utilise `random()` de Remotion).
- Termine en vérifiant le code avec `npx tsc --noEmit`, puis indique la commande d'aperçu : `npx remotion studio`.
