---
name: demo
description: Démo de logiciel avec un curseur qui clique. Crée une animation Remotion de 3 s, en code, sans générateur vidéo.
argument-hint: "[ton contenu]"
disable-model-invocation: true
---

Contenu donné : $ARGUMENTS

Dans ce projet Remotion, crée une composition 1080×1920 à 30 i/s, 3 s, sans image ni capture d'écran : l'interface est dessinée en code. Fond vert d'eau. Une fenêtre sombre de logiciel entre, avec un aperçu, une frise de vignettes et une tête de lecture qui avance. Un panneau de réglages apparaît par-dessus avec un léger rebond. Une bulle blanche annonce [Clique sur Exporter]. Un curseur traverse l'écran avec une courbe douce et clique sur le bouton bleu : le bouton s'enfonce, une barre le remplit, puis il affiche [Terminé ✓]. Remplace par mon logiciel et mes réglages : [lesquels].

Règles :
- Les passages entre crochets sont des exemples. Remplace-les par le contenu donné ci-dessus ; s'il est vide, garde les exemples. N'invente pas de chiffre présenté comme réel.
- Aucun crochet ni texte modèle (« [titre] », « [date] », « [mon événement] ») ne doit rester à l'écran. Si une information manque, écris un exemple réaliste et neutre, ou retire cet élément.
- Crée un fichier par composition, et enregistre-la dans le fichier Root du projet avec l'id exact `Demo` (durée 90 images), sans toucher aux autres compositions.
- Si ce dossier n'est pas un projet Remotion, dis-le et donne la commande pour en créer un : `npx create-video@latest --yes --blank mon-projet`.
- Tout doit rester dans le cadre 1080×1920 et l'animation doit se calculer avec useCurrentFrame, sans Math.random (utilise `random()` de Remotion).
- Termine en vérifiant le code avec `npx tsc --noEmit`, puis indique la commande d'aperçu : `npx remotion studio`.
