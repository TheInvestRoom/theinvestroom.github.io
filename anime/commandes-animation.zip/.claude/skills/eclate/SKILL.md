---
name: eclate
description: Vue éclatée, chaque couche nommée. Crée une animation Remotion de 3 s, en code, sans générateur vidéo.
argument-hint: "[ton contenu]"
disable-model-invocation: true
---

Contenu donné : $ARGUMENTS

Dans ce projet Remotion, crée une composition 1080×1920 à 30 i/s, 3 s, en SVG isométrique calculé, sans image. Fond presque noir avec une lueur centrale. Un immeuble fermé s'ouvre verticalement en 6 couches qui s'écartent : fondations sombres, poteaux rouges en trame, noyau orange, plancher vert, façade vitrée bleue sur deux côtés, toiture de 16 panneaux blancs dont un orange. Chaque couche reçoit à droite un trait orange, un numéro en police mono, un nom et une note technique, qui entrent l'un après l'autre. Finis par un titre en bas : [Un immeuble, ouvert] et une ligne [VUE ÉCLATÉE · 6 COUCHES · TRAME 6 M]. Garde toutes les étiquettes à l'intérieur du cadre. Remplace l'immeuble par : [mon objet et ses couches].

Règles :
- Les passages entre crochets sont des exemples. Remplace-les par le contenu donné ci-dessus ; s'il est vide, garde les exemples. N'invente pas de chiffre présenté comme réel.
- Aucun crochet ni texte modèle (« [titre] », « [date] », « [mon événement] ») ne doit rester à l'écran. Si une information manque, écris un exemple réaliste et neutre, ou retire cet élément.
- Crée un fichier par composition, et enregistre-la dans le fichier Root du projet avec l'id exact `Eclate` (durée 90 images), sans toucher aux autres compositions.
- Si ce dossier n'est pas un projet Remotion, dis-le et donne la commande pour en créer un : `npx create-video@latest --yes --blank mon-projet`.
- Tout doit rester dans le cadre 1080×1920 et l'animation doit se calculer avec useCurrentFrame, sans Math.random (utilise `random()` de Remotion).
- Termine en vérifiant le code avec `npx tsc --noEmit`, puis indique la commande d'aperçu : `npx remotion studio`.
