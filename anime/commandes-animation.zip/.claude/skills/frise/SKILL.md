---
name: frise
description: Frise de dates en diagonale. Crée une animation Remotion de 3 s, en code, sans générateur vidéo.
argument-hint: "[ton contenu]"
disable-model-invocation: true
---

Contenu donné : $ARGUMENTS

Dans ce projet Remotion, crée une composition 1080×1920 à 30 i/s, 3 s, sans image. Fond gris bleuté très clair, titre gras en haut avec les derniers mots en bleu : [D'un garage à 31 pays]. Une ligne bleue épaisse se trace en diagonale du haut vers le bas. À chaque date placée le long de la ligne, une carte blanche sort avec un léger rebond (titre gras, une ligne de détail), et la dernière carte est pleine en bleu. Mes dates : [année, titre et détail pour chaque étape].

Règles :
- Les passages entre crochets sont des exemples. Remplace-les par le contenu donné ci-dessus ; s'il est vide, garde les exemples. N'invente pas de chiffre présenté comme réel.
- Aucun crochet ni texte modèle (« [titre] », « [date] », « [mon événement] ») ne doit rester à l'écran. Si une information manque, écris un exemple réaliste et neutre, ou retire cet élément.
- Crée un fichier par composition, et enregistre-la dans le fichier Root du projet avec l'id exact `Frise` (durée 90 images), sans toucher aux autres compositions.
- Si ce dossier n'est pas un projet Remotion, dis-le et donne la commande pour en créer un : `npx create-video@latest --yes --blank mon-projet`.
- Tout doit rester dans le cadre 1080×1920 et l'animation doit se calculer avec useCurrentFrame, sans Math.random (utilise `random()` de Remotion).
- Termine en vérifiant le code avec `npx tsc --noEmit`, puis indique la commande d'aperçu : `npx remotion studio`.
