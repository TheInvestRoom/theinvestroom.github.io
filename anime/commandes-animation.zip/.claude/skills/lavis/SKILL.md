---
name: lavis
description: Paysage à l'encre qui se peint seul. Crée une animation Remotion de 3 s, en code, sans générateur vidéo.
argument-hint: "[ton contenu]"
disable-model-invocation: true
---

Contenu donné : $ARGUMENTS

Dans ce projet Remotion, crée une composition 1080×1920 à 30 i/s, 3 s, entièrement en SVG, sans image. Un papier crème qui se peint tout seul : d'abord une trame fine qui s'efface, puis un soleil rouge qui monte, puis trois rangées de montagnes de crêtes calculées (de la plus pâle à la plus sombre, chacune s'évapore vers le bas en brume), des oiseaux, un rocher sombre avec un pin à droite, et une petite barque qui avance sur l'eau. À gauche, un titre vertical espacé et un petit sceau rouge qui se pose en dernier. Contenu du titre : [LA RIVIÈRE N'A PAS DE NOM].

Règles :
- Les passages entre crochets sont des exemples. Remplace-les par le contenu donné ci-dessus ; s'il est vide, garde les exemples. N'invente pas de chiffre présenté comme réel.
- Aucun crochet ni texte modèle (« [titre] », « [date] », « [mon événement] ») ne doit rester à l'écran. Si une information manque, écris un exemple réaliste et neutre, ou retire cet élément.
- Crée un fichier par composition, et enregistre-la dans le fichier Root du projet avec l'id exact `Lavis` (durée 90 images), sans toucher aux autres compositions.
- Si ce dossier n'est pas un projet Remotion, dis-le et donne la commande pour en créer un : `npx create-video@latest --yes --blank mon-projet`.
- Tout doit rester dans le cadre 1080×1920 et l'animation doit se calculer avec useCurrentFrame, sans Math.random (utilise `random()` de Remotion).
- Termine en vérifiant le code avec `npx tsc --noEmit`, puis indique la commande d'aperçu : `npx remotion studio`.
