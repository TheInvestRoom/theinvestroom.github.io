---
name: table
description: La preuve posée sur la table, annotée. Crée une animation Remotion de 3 s, en code, sans générateur vidéo.
argument-hint: "[ton contenu]"
disable-model-invocation: true
---

Contenu donné : $ARGUMENTS

Dans ce projet Remotion, crée une composition 1080×1920 à 30 i/s, 3 s, sans image. Fond : tapis de découpe vert avec sa grille. Une feuille crème scotchée se pose avec un léger rebond, avec une légende en police mono, un titre en serif et un graphique dont la courbe se trace. Puis un feutre rouge entoure la zone clé, trait dessiné progressivement, et écrit à la main une annotation. Enfin, une étiquette en capitales et une seconde note avec une phrase surlignée se posent en bas, légèrement de travers. Contenu : [mon constat, ma courbe, mon annotation]. N'invente aucun chiffre : utilise seulement ceux que je donne.

Règles :
- Les passages entre crochets sont des exemples. Remplace-les par le contenu donné ci-dessus ; s'il est vide, garde les exemples. N'invente pas de chiffre présenté comme réel.
- Aucun crochet ni texte modèle (« [titre] », « [date] », « [mon événement] ») ne doit rester à l'écran. Si une information manque, écris un exemple réaliste et neutre, ou retire cet élément.
- Crée un fichier par composition, et enregistre-la dans le fichier Root du projet avec l'id exact `Table` (durée 90 images), sans toucher aux autres compositions.
- Si ce dossier n'est pas un projet Remotion, dis-le et donne la commande pour en créer un : `npx create-video@latest --yes --blank mon-projet`.
- Tout doit rester dans le cadre 1080×1920 et l'animation doit se calculer avec useCurrentFrame, sans Math.random (utilise `random()` de Remotion).
- Termine en vérifiant le code avec `npx tsc --noEmit`, puis indique la commande d'aperçu : `npx remotion studio`.
