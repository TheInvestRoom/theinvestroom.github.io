---
name: trajet
description: Ville en 3D, un trajet qui se dessine. Crée une animation Remotion de 3 s, en code, sans générateur vidéo.
argument-hint: "[ton contenu]"
disable-model-invocation: true
---

Contenu donné : $ARGUMENTS

Dans ce projet Remotion, crée une composition 1080×1920 à 30 i/s, 3 s, sans aucune image ni générateur vidéo : tout en SVG calculé image par image. Une ville en 3D avec une vraie projection en perspective : au moins 300 immeubles blanc cassé de hauteurs variées (dessus clair, côtés plus sombres, triés du plus loin au plus proche), une rivière bleu pâle, quelques arbres ronds. Un trajet bleu épais suit les rues et se dessine d'un point de départ jusqu'à une épingle rouge, avec une pastille bleue à l'avant. La caméra suit d'abord la pastille de près, puis monte pour montrer tout le trajet. Sur la fin, ajoute des noms de quartier et une carte blanche en bas avec [12 min, 4,2 km] et un bouton [Y aller]. Contenu : [Du site à l'agence].

Règles :
- Les passages entre crochets sont des exemples. Remplace-les par le contenu donné ci-dessus ; s'il est vide, garde les exemples. N'invente pas de chiffre présenté comme réel.
- Aucun crochet ni texte modèle (« [titre] », « [date] », « [mon événement] ») ne doit rester à l'écran. Si une information manque, écris un exemple réaliste et neutre, ou retire cet élément.
- Crée un fichier par composition, et enregistre-la dans le fichier Root du projet avec l'id exact `Trajet` (durée 90 images), sans toucher aux autres compositions.
- Si ce dossier n'est pas un projet Remotion, dis-le et donne la commande pour en créer un : `npx create-video@latest --yes --blank mon-projet`.
- Tout doit rester dans le cadre 1080×1920 et l'animation doit se calculer avec useCurrentFrame, sans Math.random (utilise `random()` de Remotion).
- Termine en vérifiant le code avec `npx tsc --noEmit`, puis indique la commande d'aperçu : `npx remotion studio`.
