# Audit de `avant.html` avec le skill apple-design

Chaque problème indique la ligne concernée dans `avant.html` et la règle du skill qu'il enfreint (numéro de section du `SKILL.md`).

## A. Réactivité et retour visuel

| # | Problème | Lignes | Règle enfreinte |
|---|---|---|---|
| A1 | Le bouton « Voir » ne change d'état que **300 ms après le clic**, à cause d'un `setTimeout` ajouté exprès. | 121-125 | §1 Response : « Be vigilant about every latency… Anything on the input path that isn't essential is a regression. » |
| A2 | Aucun bouton (« Voir », « Ajouter », « Valider », liens de la barre du bas) ne réagit **au moment de l'appui** : il n'y a pas de style `:active`. Le seul retour arrive au relâchement, et en retard. | 37-46, 51, 61 | §1 « Respond on pointer-down, not on release » ; §10 « Tap: highlight on touch-down (instant), commit on touch-up. » |
| A3 | « Valider » ne fait rien et n'affiche rien, même si les champs sont vides. Aucun retour, aucune validation. | 117 | §16 Feedback : « Confirm meaningful actions… validate inline (not on submit). » |
| A4 | Le champ de recherche ne fait rien. Il promet une fonction qui n'existe pas. | 74 | §16 Purpose : « every element earns its place » ; Feedback (statut). |
| A5 | « OK ! » ne dit pas ce qui s'est passé. Le libellé est générique et le point d'exclamation crie. | 124 | §16 « Direct, specific labels beat safe generic ones. » |

## B. Animation du panneau « Nouveau chantier »

| # | Problème | Lignes | Règle enfreinte |
|---|---|---|---|
| B1 | Pendant 700 ms, la variable `occupe` **bloque toute action** : impossible de refermer le panneau en cours d'ouverture, ou de le rattraper pendant qu'il se ferme. | 127-142 | §3 Interruptibility : « Never lock out input during a transition. » |
| B2 | L'animation est une **transition CSS de durée fixe** (`0.7s`) et non un ressort. Elle ne peut pas être reprise ou inversée à partir de sa position actuelle. | 56 | §3 « Avoid CSS transitions… for anything gesture-driven » ; §4 « Behavior over animation — use springs. » |
| B3 | La courbe est `linear` et dure 0,7 s, ce qui est lent et mécanique. Apple utilise un ressort (amortissement 1.0, réponse 0,3 à 0,4 s). | 56 | §4 Defaults / Quick Reference : « Default UI spring: damping 1.0, response 0.3–0.4. » |
| B4 | On anime la propriété `bottom`, qui force un recalcul de mise en page à chaque image, au lieu de `transform`. | 55-58 | §11 « Animate only compositor-friendly properties — transform and opacity. » |
| B5 | Le panneau **ne se manipule pas au doigt** : on ne peut ni le tirer vers le bas pour le fermer ni le suivre 1:1. | 112-118 | §2 Direct manipulation (1:1, Pointer Events + `setPointerCapture`, respect du point de prise). |
| B6 | Comme il n'y a pas de geste, la vitesse du doigt n'est pas transmise et l'élan n'est pas projeté. Un léger lancer vers le bas ne peut pas fermer la feuille. | — | §5 Velocity handoff ; §6 Momentum projection. |
| B7 | Le panneau s'arrête net en haut, sans résistance progressive au-delà de sa limite. | — | §9 Rubber-banding. |
| B8 | Le voile apparaît et disparaît **d'un coup** (`display: none/block`) pendant que le panneau glisse. Le voile et le panneau ne sont pas synchronisés, et le voile reste affiché 700 ms après le début de la fermeture. | 53, 133, 141 | §11 (continuité des images) ; §13 Harmony (les retours doivent tomber « on the same frame ») ; §14 (« avoid abrupt brightness jumps »). |
| B9 | Pas de `prefers-reduced-motion` : le panneau glisse même quand l'utilisateur a demandé moins de mouvement. | 54-58 | §14 Reduced motion : remplacer le glissement par un fondu court. |

## C. Matériaux, profondeur et ombres

| # | Problème | Lignes | Règle enfreinte |
|---|---|---|---|
| C1 | Les ombres sont **dures et opaques** (`0 6px 0`, `0 8px 0`, `0 6px 0 #000`). Elles donnent un effet d'autocollant et ne suggèrent aucune profondeur. | 12, 27, 45 | §12 Materials & depth (« bigger surfaces read as thicker », ombre douce adaptée au contexte) ; §16 Craft. |
| C2 | La barre du bas est **opaque** (gris `#9e9e9e`), avec une bordure de 4 px. Elle occupe une bande fixe au lieu d'être une couche translucide sous laquelle le contenu défile. | 47-50 | §12 « Build nav/toolbars/sheets as translucent layers… not opaque bars. » ; « Scroll edge effects, not hard dividers. » |
| C3 | Le bouton « Ajouter » flotte par-dessus le contenu, compensé par un `padding-bottom: 190px` arbitraire. Il ne tient pas compte de la zone sûre (encoche, barre d'accueil). | 24, 42-46 | §16 Craft (« every spacing… is a deliberate choice you can defend ») ; §16 Flexibility. |
| C4 | Les bordures de 6 px et 3 px (panneau, stats, bouton) servent de séparateurs décoratifs. | 19, 43, 55 | §12 « not hard dividers » ; §16 Simplicity. |
| C5 | Pas de `prefers-reduced-transparency` ni de `prefers-contrast`. | — | §14. |

## D. Typographie

| # | Problème | Lignes | Règle enfreinte |
|---|---|---|---|
| D1 | Quatre familles de polices se mélangent (Arial, Arial Black, Georgia, et la police par défaut des boutons) au lieu de la police système. | 8, 15, 20, 32, 59 | §15 « Default to the platform's system font. » |
| D2 | Le titre est grand mais son interlettrage est **positif** (`letter-spacing: 4px`), et il est en majuscules avec une ombre noire de 3 px. | 14-16 | §15 « Large display text wants negative tracking. » ; « a fixed letter-spacing is wrong somewhere. » |
| D3 | Le texte de 11 px en majuscules a un interlettrage fixe de 2 px (« Voir »), tout comme « Ajouter » (15 px, 1 px). Les majuscules partout nuisent à la lecture. | 38-39, 44 | §15 Tracking « size-specific — never one value for all sizes ». |
| D4 | Les textes sont trop petits : 10 px (libellés des stats), 11 px (adresse, %, « Voir »), 13 px (recherche, ce qui déclenche aussi le zoom automatique sur iOS). | 21, 23, 33, 36, 38 | §15 Dynamic Type / §16 Flexibility (gamme complète de capacités). |
| D5 | Toutes les tailles sont en **px**, sans `line-height` réfléchi. La mise en page ne suit pas la taille de texte choisie par l'utilisateur. | partout | §15 « spacing in rem/em, not fixed px » ; « Leading tracks size inversely. » |
| D6 | La hiérarchie repose sur des couleurs criardes et du soulignement, pas sur la graisse, la taille et l'interligne. | 20, 32 | §15 « Build hierarchy from weight + size + leading as a set. » |

## E. Couleur, contraste et hiérarchie

| # | Problème | Lignes | Règle enfreinte |
|---|---|---|---|
| E1 | Contrastes illisibles : adresse `#bbb` sur blanc (environ 1,9:1), pourcentage `#aaa` (environ 2,3:1), libellés `#ffe0b2` sur orange, liens `#eee` sur gris `#9e9e9e` (environ 1,6:1). | 21, 33, 36, 51 | §16 Simplicity (clarté par le contraste) ; §14 Accessibilité. |
| E2 | Il y a six couleurs vives sans rôle défini : dégradé violet-bleu, orange, violet, rouge-orange, vert, gris. Tout crie, donc rien ne ressort. | 10, 19, 38, 43, 48 | §16 Simplicity : « the most important thing is the most obvious » ; Craft : « Nothing is random. » |
| E3 | Le seul avertissement important (« EN RETARD ») est noyé dans un texte gris de 11 px. La tuile « retards » a la même couleur que les autres. | 19, 90 | §16 Feedback : « warn before problems » ; hiérarchie. |
| E4 | L'état d'avancement n'est indiqué que par la **couleur** de la barre (vert, orange, rouge), sans libellé ni légende. | 81, 89, 97 | §16 Flexibility (accessibilité) ; §14. |
| E5 | Les noms de chantier sont **bleus et soulignés** comme des liens, mais on ne peut pas cliquer dessus. | 32 | §16 Familiarity : « things that look the same must behave the same ». |
| E6 | Pas de mode sombre. | — | §16 Craft : « colors that adapt to light/dark ». |

## F. Cohérence et repères

| # | Problème | Lignes | Règle enfreinte |
|---|---|---|---|
| F1 | Les cartes ont des **arrondis différents** : 0 pour la première, 22 px pour la deuxième (`nth-child(2)`), 0 pour la troisième. | 29-30 | §16 Familiarity / consistency ; Craft (« misaligned… read as carelessness »). |
| F2 | Le contenu des cartes est centré, ce qui rend la lecture d'une liste plus difficile. Le bouton « Voir » est loin de ce qu'il concerne. | 26 | §16 Grouping & mapping. |
| F3 | Les onglets ont des libellés vagues et en anglais dans une appli en français : « Home », « Page 2 », « Settings ». | 106-108 | §16 « Name nav items for their contents… not vague umbrellas ("Home") ». |
| F4 | Aucun onglet n'est marqué comme actif : on ne sait pas où l'on se trouve. | 105-109 | §16 Wayfinding : « Where am I? » |
| F5 | Les émojis servent d'icônes de navigation. Leur rendu change selon le système et ils ne s'accordent pas avec le style des libellés. | 106-108 | §16 Craft : « clear iconography ». |
| F6 | Le bouton de fermeture « ✖ » est un `<span>` : il n'est pas atteignable au clavier, sa zone de toucher est d'environ 22 px, et Échap ne ferme pas le panneau. | 62, 113 | §16 Wayfinding : « How do I get out? Never trap the user. » ; Flexibility. |
| F7 | Les champs n'ont pas de libellé : le placeholder disparaît dès qu'on tape. Le fond reste actif au clavier quand le panneau modal est ouvert. | 74, 115-116 | §16 Simplicity / Flexibility ; §12 « Dim to focus » (le fond doit vraiment passer à l'arrière-plan). |
| F8 | Les zones de toucher sont trop petites : « Voir » mesure environ 25 px de haut. | 38 | §10 « Add ~10px of hysteresis/hit padding around the target ». |
| F9 | **Incohérence de données** : la tuile affiche « 2 retards », mais un seul chantier est marqué « EN RETARD ». | 71, 90 | §16 Responsibility / Craft (confiance). *Je n'ai pas modifié ce chiffre, c'est à vérifier côté données.* |

---

## Ce qui a été corrigé dans `apres.html`

- **A1-A2** : chaque bouton réagit à l'appui (`:active`, réduction d'échelle de 100 ms). « Voir » change d'état tout de suite au relâchement, sans délai.
- **A3** : formulaire avec libellés visibles. La validation se fait au fil de la saisie : le nom est obligatoire et l'erreur apparaît en sortant du champ. « Valider » ajoute la carte en tête de liste, met à jour les stats et ferme le panneau.
- **A4** : la recherche filtre les cartes par nom et adresse, sans tenir compte des accents. Un message s'affiche quand aucun chantier ne correspond.
- **A5** : « OK ! » devient « Vu ✓ », avec `aria-pressed`.
- **B1-B8** : le panneau est une vraie feuille animée par un ressort, écrit en JS sans dépendance :
  - ressort critique (amortissement 1.0, réponse 0,4 s) pour les ouvertures et fermetures au bouton ;
  - amortissement 0.8 et réponse 0,3 s seulement après un geste ;
  - on peut l'interrompre à tout moment : l'animation repart toujours de la position affichée, en gardant sa vitesse ;
  - on peut tirer la feuille 1:1 (Pointer Events, capture, point de prise respecté, seuil de 10 px) ;
  - au relâchement, la vitesse est transmise et l'élan est projeté (`decelerationRate 0.998`) ;
  - une résistance progressive s'applique en haut ;
  - seul `transform` est animé ;
  - l'opacité du voile est calculée à chaque image à partir de la position de la feuille.
- **B9, C5** : prise en charge de `prefers-reduced-motion` (fondu de 200 ms), `prefers-reduced-transparency` et `prefers-contrast: more`.
- **C1-C4** : ombres douces, barre d'onglets translucide (`backdrop-filter`) sous laquelle le contenu défile, plus de bordures décoratives, espacements en `rem` et prise en compte de la zone sûre (`env(safe-area-inset-*)`).
- **D1-D6** : police `system-ui`. Interlettrage négatif sur le grand titre, proche de 0 sur le corps de texte. Plus de majuscules forcées. Texte de 13 px minimum (17 px pour le champ de recherche). Hiérarchie construite par la graisse, la taille et l'interligne.
- **E1-E6** : palette sobre avec une seule couleur d'accent, contrastes AA. Les couleurs vert, orange et rouge sont réservées à l'état et sont toujours doublées d'un texte (pastille « En retard », chiffre de retards en rouge). Barres de progression accessibles (`role="progressbar"`). Mode sombre.
- **F1-F8** : arrondi de 16 px identique pour toutes les cartes, contenu aligné à gauche, « Voir » placé à côté de l'avancement. Onglets « Chantiers / Documents / Réglages » avec des icônes SVG et un onglet actif (`aria-current`). Vrai bouton Fermer de 44 px, touche Échap, focus placé dans le panneau puis rendu au bouton d'origine, fond rendu `inert`. Zones de toucher de 44 px minimum.
- **F9** : signalé seulement, le chiffre « 2 » est conservé tel quel.

> Remarque : « Documents » et « Réglages » remplacent « Page 2 » et « Settings ». « Documents » est une proposition, puisque le contenu de « Page 2 » n'est pas connu.
