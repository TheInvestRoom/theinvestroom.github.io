# Surface de plancher : Maison d'exemple

Règles appliquées : art. **R111-22** (surface de plancher) et **R431-2** (seuil de 150 m² pour l'architecte), code de l'urbanisme.
Données : voir `releve.json` (cotes lues, mesures au pixel à 75,1 px/m, hypothèses).

## Tableau ligne par ligne

| Niveau | Élément | Calcul | m² | Article |
|---|---|---|---:|---|
| RDC | Surface brute au nu intérieur | 11,60 × 8,40 | **+97,44** | R111-22 (al. 1) |
| RDC | Embrasures des baies extérieures | (0,60 + 1,20 + 1,00 + 1,20 + 2,40 + 1,20 + 1,00) = 8,60 m × 0,30 | −2,58 | R111-22 1° |
| RDC | Porte cellier → garage (0,90 m) | ne donne pas sur l'extérieur : rien à déduire | 0,00 | R111-22 1° (non applicable) |
| RDC | Emprise de l'escalier au RDC (1,00 × 3,20) | c'est un plancher, pas une trémie : comptée | 0,00 | R111-22 2° (non applicable) |
| RDC | Cellier-chaufferie (9,2 m²) | maison individuelle, pas de partie commune : compté | 0,00 | R111-22 6° et 7° (non applicables) |
| RDC | Cloisons intérieures 7 cm | non déductibles : comptées (≈ 2,4 m², estimé) | 0,00 | règle de l'énoncé |
| **RDC** | **Sous-total** | 97,44 − 2,58 | **94,86** | |
| Garage | Surface brute au nu intérieur | 3,20 × 6,00 | **+19,20** | R111-22 (al. 1) |
| Garage | Stationnement | 3,20 × 6,00 | −19,20 | R111-22 4° |
| **Garage** | **Sous-total** | 19,20 − 19,20 | **0,00** | |
| Combles | Surface brute au nu intérieur | 11,60 × 8,40 | **+97,44** | R111-22 (al. 1) |
| Combles | Bande nord ≤ 1,80 m | 11,60 × 1,50 | −17,40 | R111-22 3° |
| Combles | Bande sud ≤ 1,80 m | 11,60 × 1,50 | −17,40 | R111-22 3° |
| Combles | Trémie d'escalier (partie hors bande nord) | 1,00 × 3,20 = 3,20, dont 1,00 × 1,30 déjà déduits au 3° ; reste 1,00 × 1,90 | −1,90 | R111-22 2° |
| Combles | Embrasures des baies extérieures (pignons) | (1,00 + 1,00 + 1,00 + 0,80) = 3,80 m × 0,30 | −1,14 | R111-22 1° |
| Combles | Fenêtre de toit | dans le rampant, au-dessus de la bande déjà déduite | 0,00 | — |
| Combles | Combles non aménageables | aucun (combles aménagés) | 0,00 | R111-22 5° (non applicable) |
| Combles | Cloisons intérieures 7 cm | non déductibles : comptées (≈ 1,6 m², estimé) | 0,00 | règle de l'énoncé |
| **Combles** | **Sous-total** | 97,44 − 34,80 − 1,90 − 1,14 | **59,60** | |
| Tous | Abattement 10 % | logement collectif seulement | 0,00 | R111-22 8° (non applicable) |
| **TOTAL** | **Surface de plancher** | 94,86 + 0,00 + 59,60 | **154,46** | |

## Vérification des additions (refaite deux fois)

1. Brut : 97,44 + 19,20 + 97,44 = **214,08**. Déductions : 2,58 + 19,20 + 17,40 + 17,40 + 1,90 + 1,14 = **59,62**. 214,08 − 59,62 = **154,46**.
2. Par niveau : 94,86 + 0,00 + 59,60 = **154,46**. ✔ Les deux méthodes donnent le même total.

## Ce qui reste compté alors qu'on pourrait croire le contraire

- **Cloisons intérieures** : jamais déduites (≈ 2,4 m² au RDC, ≈ 1,6 m² dans les combles, estimés par différence avec les surfaces écrites).
- **Cellier-chaufferie 9,2 m²** : le 6° (locaux techniques) ne s'applique pas à une maison individuelle, et le 7° (caves et celliers) seulement s'ils sont desservis par une partie commune, ce qui n'est pas le cas ici.
- **Buanderie, WC, dressing** : comptés.
- **Emprise de l'escalier au RDC** (3,20 m²) : comptée. Seule la trémie de l'étage est un vide.
- **Porte vers le garage** : son embrasure n'est pas déduite, elle ne donne pas sur l'extérieur.

## Piège évité

La **surface habitable écrite sur le plan (141,7 m²)** n'est pas la surface de plancher. Elle exclut le cellier-chaufferie (150,9 − 9,2 = 141,7), l'escalier et les cloisons.

## Résultat

- Surface de plancher : **154,46 m²**
- Seuil R431-2 : 150 m². **Écart : +4,46 m²** au-dessus du seuil.
- Sensibilité : même en déduisant la trémie entière une deuxième fois (−1,30 m²) et en ajoutant l'incertitude sur les baies (±0,1 m²), on reste au-dessus de 153 m².

## Verdict : **ARCHITECTE OBLIGATOIRE** (art. R431-2)
