# Fiche des déductions : surface de plancher et seuil des 150 m²

Textes vérifiés le 4 novembre 2026 sur Légifrance et service-public.fr.

## Le seuil (code de l'urbanisme, art. R*431-2 a)
Une personne qui construit ou modifie pour elle-même une construction à usage autre qu'agricole n'est pas tenue de recourir
à un architecte si la **surface de plancher n'excède pas 150 m²**. Au-delà, l'architecte est obligatoire pour le permis de
construire. Pour des travaux sur une construction existante, il l'est aussi dès que les travaux font passer le total au-dessus
du seuil. Le recours n'est jamais obligatoire pour un projet soumis à simple déclaration préalable (service-public, F20568).
https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000038682379
https://www.service-public.gouv.fr/particuliers/vosdroits/F20568

## Le calcul (art. R111-22)
Somme des surfaces de chaque niveau **clos et couvert**, mesurée **au nu intérieur des façades**, après déduction :
1. de l'épaisseur des murs autour des embrasures des portes et fenêtres donnant sur l'extérieur ;
2. des vides et trémies des escaliers et ascenseurs ;
3. des surfaces dont la hauteur sous plafond est inférieure ou égale à 1,80 m ;
4. des surfaces aménagées pour le stationnement (garage, rampes, aires de manœuvre) ;
5. des combles non aménageables ;
6. des locaux techniques d'un groupe de bâtiments ou d'un immeuble **autre qu'une maison individuelle** ;
7. des caves et celliers annexes à des logements, **seulement s'ils sont desservis uniquement par une partie commune** ;
8. de 10 % des surfaces d'habitation, **seulement si les logements sont desservis par des parties communes intérieures**.
https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031721274/

## Ce qui reste compté dans une maison (les pièges)
- les cloisons intérieures : elles ne se déduisent pas ;
- le cellier, la chaufferie, la buanderie : les alinéas 6 et 7 ne jouent pas pour une maison individuelle sans partie commune ;
- l'emprise de l'escalier au niveau bas : c'est un plancher, seule la trémie au-dessus est un vide ;
- la surface habitable écrite sur un plan ou une annonce n'est **pas** la surface de plancher.

## Avant de déposer
Le calcul de Claude est une aide. Fais vérifier ta surface de plancher par le service urbanisme de ta mairie (ou un architecte),
surtout si tu es à quelques m² du seuil.
