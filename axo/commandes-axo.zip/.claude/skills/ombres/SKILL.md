---
name: ombres
description: Les ombres du 21 juin, de 8 h à 20 h, sur la maison en 3D.
argument-hint: "[image de l'axo]"
disable-model-invocation: true
---

Monte la maison en volume (les deux niveaux, la terrasse, l'acrotère, les grandes baies en sombre sur les façades) et calcule les ombres portées du 21 juin sur le terrain, la terrasse et la maison elle-même, avec la vraie course du soleil (formules solaires classiques : déclinaison, angle horaire, hauteur, azimut ; heure solaire), pour Paris (48,85° N) si le lieu n'est pas donné, en respectant le nord de l'axo. Image finale : l'ombre de 16 h (ou l'heure la plus parlante), avec un petit diagramme de la course du soleil et un tableau discret heure / hauteur / azimut de 8 h à 20 h. Vidéo : les ombres tournent autour de la maison de 8 h à 20 h, l'heure affichée change.

Axo donnée : $ARGUMENTS (s'il n'y a rien, prends l'image d'axonométrie du dossier courant).

Commence toujours comme ça :
1. Ouvre l'image et lis-la vraiment : chaque niveau dessiné, les cotes, les surfaces écrites, le nord, les hauteurs (niveaux, hauteurs sous plafond, acrotère), les murs (extérieurs, refends, cloisons et leurs épaisseurs), les baies, l'escalier, la trémie, la terrasse.
2. Si `maison.json` existe déjà, réutilise-le. Sinon écris-le : pour chaque niveau, les murs (segments en mètres, épaisseur, porteur ou non), les baies (position, largeur, allège, hauteur), les pièces (nom, contour, surface), l'escalier (position, sens de montée, nombre de marches), la trémie ; puis les niveaux, les hauteurs, la toiture, l'orientation. Repère : x vers l'est, y vers le nord, origine au coin sud-ouest, nus extérieurs. Écris aussi ce que tu n'as pas pu lire.
3. Vérifie ta lecture avant de dessiner : les cotes et les surfaces recalculées depuis `maison.json` doivent coller à celles écrites sur l'axo (5 cm sur les cotes, 0,5 m² sur les surfaces), sinon corrige `maison.json`.

Dessine ensuite en code, avec un script Python (matplotlib, numpy, Pillow ; installe ce qui manque avec pip, ffmpeg sert à la vidéo). Aucun générateur d'images : tout se calcule depuis `maison.json`. Pour une vue en 3D, utilise une axonométrie isométrique vue du même côté que l'axo donnée, avec un ordre de dessin juste (algorithme du peintre sur des boîtes alignées, ou petit z-buffer) : aucune face cachée qui passe devant.

Ce que tu rends, dans le dossier courant :
- `ombres.png` : le dessin final, 1080 × 1920 en portrait. Le dessin occupe au moins 85 % de la largeur et reste lisible sur un téléphone ; la place libre au-dessus et en dessous sert à la légende, au ciel ou au sol, jamais à du vide. Trait net, niveau d'un rendu d'école d'architecture ou d'agence, jamais un graphique de tableur. Palette sobre : fond papier clair, noir pour ce qui est coupé ou porteur, une ou deux couleurs d'accent. Pas de titre géant : un petit cartouche discret (nom du dessin, échelle graphique, nord).
- `ombres.mp4` : 3 s, 1080 × 1920, 30 i/s, H.264, yuv420p, où le dessin se construit sous les yeux et se termine sur l'image finale tenue les 20 dernières images. La première image n'est jamais vide.

Ouvre le PNG pour le regarder, et corrige s'il y a du texte coupé ou qui se chevauche, ou une face cachée qui passe devant. Termine en disant en quelques lignes ce que le dessin montre, avec les chiffres que tu as calculés, ce que tu as lu sur l'axo et ce que tu as supposé parce qu'elle ne le dit pas. N'invente rien sans le dire.
