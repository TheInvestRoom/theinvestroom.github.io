---
name: planche-axo
description: Les dessins de l'axo sur une planche A3.
argument-hint: "[dossier des dessins]"
disable-model-invocation: true
---

Mets en page sur une planche A3 paysage les dessins déjà produits dans le dossier courant ($ARGUMENTS s'il est donné) : `plan.png`, `coupe.png`, `structure.png`, `circulations.png`, `ombres.png`, `eclate.png` (ceux qui existent), plus l'axo de départ en petit.

Règles : grille régulière, marges égales, chaque dessin recadré sur son contenu (sans ses marges vides) mais jamais déformé, un titre de projet discret, un numéro et un nom sous chaque dessin, un cartouche (projet, date, échelle « sans échelle »). Fond papier clair.

Ce que tu rends, dans le dossier courant :
- `planche.png` : 4961 × 3508 (A3 à 300 dpi) ;
- `planche.pdf` : la même en A3 ;
- `planche-mobile.png` : 1080 × 1920, la même planche réorganisée en portrait (2 colonnes), lisible sur un téléphone.

Ouvre les PNG pour les regarder, corrige les chevauchements, et dis en une ligne ce que contient la planche.
