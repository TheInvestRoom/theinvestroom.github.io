---
name: axo
description: L'axonométrie coupée de la maison, meublée, depuis le croquis.
argument-hint: "[photo du croquis]"
disable-model-invocation: true
---

Dessine l'axonométrie isométrique de la maison coupée à 1,20 m (sans toit, on voit dedans), vue depuis le coin bas gauche du croquis : murs en volume avec leur tranche coupée en noir, ouvertures dans les murs, sol de chaque pièce dans une teinte douce, mobilier simple en volume à l'échelle, petites silhouettes humaines, ombre portée légère au sol. C'est l'image la plus belle du lot : elle doit donner envie à elle seule. Rends `axo.png` et `axo.mp4` : le sol, puis les murs qui montent, puis les meubles et les ombres.

Croquis donné : $ARGUMENTS (s'il n'y a rien, prends la photo de croquis du dossier courant).

Commence toujours comme ça :
1. Si `maison.json` existe déjà dans le dossier, réutilise-le tel quel et passe à l'étape 3.
2. Sinon, ouvre la photo et lis vraiment le croquis : le contour, chaque mur et cloison, chaque porte (où, de quel côté elle s'ouvre), chaque fenêtre (sur quel mur, où), le nom écrit dans chaque pièce, chaque cote écrite, le nord. Puis écris `maison.json` : murs (segments en mètres, extérieurs 0,30 m, cloisons 0,10 m sauf indication), baies (mur, position, largeur), portes, pièces (nom écrit sur le croquis, contour, surface), orientation. Repère : x vers la droite du dessin, y vers le haut du dessin, origine au coin bas gauche, nus extérieurs. Les cotes écrites sont la vérité ; ce qui n'est pas coté se mesure en proportion sur le croquis, en s'appuyant sur les cotes écrites. Écris aussi ce que tu n'as pas pu lire et ce que tu as supposé.
3. Vérifie avant de dessiner : chaque cote écrite sur le croquis doit se retrouver dans `maison.json` à 5 cm près, et la somme des surfaces doit coller au contour moins les murs. **Aucune pièce, porte ou fenêtre qui n'est pas sur le croquis** : tu n'ajoutes rien, tu ne déplaces rien. Ce que le croquis ne dit pas : hauteur sous plafond 2,50 m, toit-terrasse avec acrotère, allèges à 0,90 m ; dis-le à la fin.

Dessine ensuite en code, avec un script Python (matplotlib, numpy, Pillow ; installe ce qui manque avec pip, ffmpeg sert à la vidéo). Aucun générateur d'images : tout se calcule depuis `maison.json`. Pour une vue en 3D, ordre de dessin juste (algorithme du peintre sur des boîtes alignées, ou petit z-buffer) : aucune face cachée qui passe devant.

Règles de dessin, pour qu'il se lise plein écran sur un téléphone : PNG 1080 × 1920 en portrait, le dessin occupe au moins 85 % de la largeur ; peu de texte et en gros (noms des pièces, quelques cotes, surfaces), aucun tableau dans l'image, un cartouche minuscule (nom du dessin, échelle graphique, nord) ; la place libre au-dessus et en dessous sert au ciel, au sol ou au papier, jamais à du vide. Trait net, niveau d'un rendu d'agence ou d'école d'architecture, jamais un graphique de tableur. Palette sobre : fond papier clair, noir pour ce qui est coupé, une ou deux couleurs d'accent. La vidéo fait 3 s, 1080 × 1920, 30 i/s, H.264, yuv420p, se termine sur l'image finale tenue les 20 dernières images, et sa première image n'est jamais vide.

Ouvre le PNG pour le regarder, et corrige s'il y a du texte coupé ou qui se chevauche, ou une face cachée qui passe devant. Termine en disant en quelques lignes ce que le dessin montre, avec les chiffres calculés, ce que tu as lu sur le croquis et ce que tu as supposé. N'invente rien sans le dire.
