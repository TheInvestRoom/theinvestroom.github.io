---
name: coupe
description: La coupe de la maison, depuis le croquis.
argument-hint: "[photo du croquis]"
disable-model-invocation: true
---

Fais la coupe verticale qui montre le plus (elle traverse le séjour et l'entrée, ou les pièces principales), avec son trait de coupe sur une petite vignette en plan dans un coin. Éléments coupés en poché noir (murs, dalle, toit-terrasse et acrotère), éléments vus en trait fin, sol et terre hachurés, fenêtres et portes vues. Niveaux cotés (±0,00, sous plafond, acrotère), noms des pièces traversées, petites silhouettes humaines à l'échelle, ciel léger. Rends `coupe.png` et `coupe.mp4` : le sol, puis la dalle, puis les murs, puis les cotes.

Croquis donné : $ARGUMENTS (s'il n'y a rien, prends la photo de croquis du dossier courant).

Commence toujours comme ça :
1. Si `maison.json` existe déjà dans le dossier, réutilise-le tel quel et passe à l'étape 3.
2. Sinon, ouvre la photo et lis vraiment le croquis : le contour, chaque mur et cloison, chaque porte (où, de quel côté elle s'ouvre), chaque fenêtre (sur quel mur, où), le nom écrit dans chaque pièce, chaque cote écrite, le nord. Puis écris `maison.json` : murs (segments en mètres, extérieurs 0,30 m, cloisons 0,10 m sauf indication), baies (mur, position, largeur), portes, pièces (nom écrit sur le croquis, contour, surface), orientation. Repère : x vers la droite du dessin, y vers le haut du dessin, origine au coin bas gauche, nus extérieurs. Les cotes écrites sont la vérité ; ce qui n'est pas coté se mesure en proportion sur le croquis, en s'appuyant sur les cotes écrites. Écris aussi ce que tu n'as pas pu lire et ce que tu as supposé.
3. Vérifie avant de dessiner : chaque cote écrite sur le croquis doit se retrouver dans `maison.json` à 5 cm près, et la somme des surfaces doit coller au contour moins les murs. **Aucune pièce, porte ou fenêtre qui n'est pas sur le croquis** : tu n'ajoutes rien, tu ne déplaces rien. Ce que le croquis ne dit pas : hauteur sous plafond 2,50 m, toit-terrasse avec acrotère, allèges à 0,90 m ; dis-le à la fin.

Dessine ensuite en code, avec un script Python (matplotlib, numpy, Pillow ; installe ce qui manque avec pip, ffmpeg sert à la vidéo). Aucun générateur d'images : tout se calcule depuis `maison.json`. Pour une vue en 3D, ordre de dessin juste (algorithme du peintre sur des boîtes alignées, ou petit z-buffer) : aucune face cachée qui passe devant.

Règles de dessin, pour qu'il se lise plein écran sur un téléphone : PNG 1080 × 1920 en portrait, le dessin occupe au moins 85 % de la largeur ; peu de texte et en gros (noms des pièces, quelques cotes, surfaces), aucun tableau dans l'image, un cartouche minuscule (nom du dessin, échelle graphique, nord) ; la place libre au-dessus et en dessous sert au ciel, au sol ou au papier, jamais à du vide. Trait net, niveau d'un rendu d'agence ou d'école d'architecture, jamais un graphique de tableur. Palette sobre : fond papier clair, noir pour ce qui est coupé, une ou deux couleurs d'accent. La vidéo fait 3 s, 1080 × 1920, 30 i/s, H.264, yuv420p, se termine sur l'image finale tenue les 20 dernières images, et sa première image n'est jamais vide.

Ouvre le PNG pour le regarder, et corrige s'il y a du texte coupé ou qui se chevauche, ou une face cachée qui passe devant. Termine en disant en quelques lignes ce que le dessin montre, avec les chiffres calculés, ce que tu as lu sur le croquis et ce que tu as supposé. N'invente rien sans le dire.
