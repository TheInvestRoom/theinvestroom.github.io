---
name: planche-carnet
description: Le croquis et ses dessins sur une planche A3.
argument-hint: "[dossier des dessins]"
disable-model-invocation: true
---

Mets en page sur une planche A3 paysage la photo du croquis de départ et les dessins déjà produits dans le dossier courant ($ARGUMENTS s'il est donné) : `releve.png`, `meuble.png`, `axo.png`, `coupe.png`, `perspective.png` (ceux qui existent). Le croquis en premier, petit, comme point de départ ; l'axo en plus grand.

Règles : grille régulière, marges égales, chaque dessin recadré sur son contenu (sans ses marges vides) mais jamais déformé, un titre de projet discret, un numéro et un nom sous chaque dessin, un cartouche réduit (projet, date, « sans échelle »). Fond papier clair. Peu de texte, en gros.

Ce que tu rends, dans le dossier courant :
- `planche.png` : 4961 × 3508 (A3 à 300 dpi) ;
- `planche.pdf` : la même en A3 ;
- `planche-mobile.png` : 1080 × 1920, la même planche réorganisée en portrait (2 colonnes, l'axo en grand), lisible sur un téléphone.

Ouvre les PNG pour les regarder, corrige les chevauchements, et dis en une ligne ce que contient la planche.
