# Contrôle logement décent — Studio meublé « 18 m² », dernier étage, DPE F

Source : `annonce-studio.png` (relevé complet et suppositions dans `releve.json`).
Règles appliquées : décret n° 2002-120 du 30 janvier 2002, surfaces et volumes selon l'art. R156-1 CCH (parties < 1,80 m exclues). Date du contrôle : 6 novembre 2026.

## Verdict : **NON DÉCENT**

La pièce principale ne compte que **6,99 m²** à 1,80 m et plus (seuil 9 m²) et **15,5 m³** (seuil 20 m³) : aucune des deux options de l'article 4 n'est remplie.

## Les 6 contrôles

| # | Contrôle | Résultat | Chiffre trouvé | Seuil | Article |
|---|---|---|---|---|---|
| 1 | Pièce principale : surface et volume | ❌ | 6,99 m² (hauteur 1,80 à 2,70 m) · 15,5 m³ | 9 m² et 2,20 m, ou 20 m³ | art. 4 |
| 2 | Éclairement naturel + ouvrant sur l'air libre | ✅ | fenêtre de toit 78 × 98 cm (0,76 m²) | rien de chiffré dans le décret | art. 2, 7° |
| 3 | Ventilation | ✅ | VMC indiquée dans la SdE | il faut un dispositif | art. 2, 6° |
| 4 | Cuisine | ✅ | évier + 2 plaques + ballon d'eau chaude | appareil de cuisson + évier eau chaude/froide | art. 3, 4° |
| 5 | Sanitaires | ✅ | SdE + WC fermée, douche dessinée | WC séparé de la cuisine + douche ou baignoire, eau chaude/froide | art. 3, 5° |
| 6 | Performance énergétique | ✅ (jusqu'au 31/12/2027) | DPE F | F minimum depuis le 01/01/2025 ; E minimum le 01/01/2028 | art. 3 bis |

Les ✅ 2 à 5 ne reposent que sur ce que dit l'annonce. Ils sont à confirmer sur place (voir plus bas).

## Calculs (script `scripts/calcul.py`, vérifiés deux fois : formule exacte + grille de 1 mm)

Hypothèse de pente : 1,00 m contre le mur du bas (bas de pente), 2,70 m contre le mur d'entrée, variation linéaire sur 3,60 m.

```
h(d) = 1,00 + 1,70 × d / 3,60          (d = distance au mur bas de pente)
h = 1,80 m  ⇒  d = 0,80 × 3,60 / 1,70 = 1,694 m
Sol total (annonce)            5,00 × 3,60              = 18,00 m²
Emprise SdE + WC (cloisons)    1,68 × 1,51              =  2,54 m²   (entièrement au-dessus de 1,80 m)
Pièce principale, toutes h.    18,00 − 2,54             = 15,46 m²
Partie < 1,80 m (exclue)       5,00 × 1,694             =  8,47 m²
Surface habitable pièce princ. 5,00 × (3,60 − 1,694) − 2,54 = 6,99 m²
Volume bande ≥ 1,80 m          5,00 × ∫ h(d) de 1,694 à 3,60 = 21,44 m³
Volume SdE retiré              1,68 × ∫ h(d) de 2,09 à 3,60  =  5,94 m³
Volume habitable pièce princ.  21,44 − 5,94             = 15,50 m³
Hauteur sous plafond           de 1,80 à 2,70 m ; moyenne pondérée 15,50 / 6,99 = 2,22 m
Grille 1 mm (vérification)     6,993 m² · 15,497 m³     → identique
```

Calcul à la main pour contrôle : 5 × 1,906 = 9,53 m² ; 9,53 − 2,54 = 6,99 m². Hauteur moyenne de la bande = (1,80 + 2,70)/2 = 2,25 m, donc 9,53 × 2,25 = 21,44 m³. Hauteur moyenne au droit de la SdE : h(2,845) = 2,34 m, donc 2,54 × 2,34 = 5,94 m³. Au total 15,50 m³.

Le résultat tient malgré les incertitudes de lecture : il manque 2 m² et 4,5 m³. Une erreur de ± 2 cm sur les cotes de la SdE change la surface d'environ 0,06 m² seulement. Même avec un plafond à 2,70 m sur toute la bande, le volume ne dépasserait pas 9,53 × 2,70 − 2,54 × 2,70 = 18,9 m³, toujours sous les 20 m³.

Remarque : les 18 m² annoncés sont le sol total, SdE et partie basse compris. Ils ne correspondent pas à la surface calculée selon R156-1.

## À vérifier sur place

1. **Mesurer les hauteurs** au mètre laser : la hauteur au mur bas, au mur d'entrée, et l'endroit où le plafond passe à 1,80 m (prévu à 1,69 m du mur bas). Vérifier aussi qu'il n'y a pas une seconde pente ou une partie plus haute que la coupe n'a pas dessinée. C'est ce point qui décide du verdict.
2. Les dimensions réelles de la SdE.
3. La fenêtre de toit s'ouvre bien, et elle éclaire suffisamment la pièce.
4. La VMC fonctionne (extraction dans la SdE) et la pièce principale a des entrées d'air.
5. L'eau chaude **et** l'eau froide arrivent à l'évier comme à la douche, et le ballon fonctionne.
6. Le WC est bien dans la SdE fermée (séparé de la cuisine) et le carré barré est bien une douche.
7. Le DPE est en cours de validité, avec son numéro ADEME. La classe F ne sera plus suffisante au 1er janvier 2028 (E minimum).
