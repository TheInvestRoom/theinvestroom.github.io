---
name: filaire
description: La maquette en filaire, qui tourne sur elle-même.
argument-hint: "[maquette .obj]"
disable-model-invocation: true
---

Fais une vue en filaire de la maquette : toutes les arêtes des volumes en trait fin, les arêtes vues en noir et les arêtes cachées en pointillés gris clair (calcule vraiment ce qui est caché). Vue axonométrique, légèrement plongeante. PNG : la vue sous le meilleur angle. Vidéo : la maquette fait un tour complet sur elle-même en filaire, puis s'arrête sur l'angle du PNG.

Maquette donnée : $ARGUMENTS (s'il n'y a rien, prends le fichier .obj du dossier courant).

Commence toujours comme ça :
1. Ouvre la maquette et lis-la vraiment : les lignes de commentaire (unités, axe vertical, nord), les groupes (`g …`), les sommets et les faces. Si rien n'est dit, suppose des mètres et Z vers le haut, et dis-le.
2. Si `maquette.json` existe déjà, réutilise-le. Sinon écris-le : unités, axe vertical, nord, boîte englobante, niveaux (nom, altitude basse et haute, groupes qui le composent, emprise au sol en m²), nombre de faces. Un niveau = les groupes qui partagent le même préfixe (`niveau-0-…`) ; sans groupes, découpe par altitudes de dalles.
3. Vérifie ta lecture avant de dessiner : les dimensions de la boîte englobante et la hauteur de chaque niveau doivent être cohérentes avec la maquette (compte les faces lues, recoupe les altitudes), sinon corrige `maquette.json`.

Dessine ensuite en code, avec un script Python (numpy, matplotlib, shapely, Pillow ; trimesh si tu veux ; installe ce qui manque avec pip, et ffmpeg sert à la vidéo). Aucun générateur d'images : tout se calcule depuis la maquette.

Ce que tu rends, dans le dossier courant :
- `filaire.png` : le dessin final, 1080 × 1920 en portrait, sans marge perdue. Le dessin doit occuper au moins 70 % de la hauteur. Trait net, niveau d'un rendu d'école d'architecture ou d'agence, jamais un graphique de tableur ni une vue 3D de logiciel par défaut (pas d'axes, pas de grille). Pas de titre géant : un petit cartouche discret (nom du dessin, échelle graphique, nord si le dessin est en plan).
- `filaire.mp4` : 3 s, 1080 × 1920, 30 i/s, H.264, yuv420p, où la maquette tourne d'un tour complet et se termine sur l'image finale tenue les 20 dernières images. La première image n'est jamais vide.

Ouvre le PNG pour le regarder, et corrige s'il y a du texte coupé ou qui se chevauche, ou une face qui passe devant ce qu'elle devrait cacher. Termine en disant en quelques lignes ce que le dessin montre, ce que tu as lu dans la maquette et ce que tu as supposé parce qu'elle ne le dit pas. N'invente rien sans le dire.
