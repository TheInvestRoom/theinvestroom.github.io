---
name: ombres
description: Ombres portées de la maquette, calculées heure par heure.
argument-hint: "[maquette .obj]"
disable-model-invocation: true
---

Fais une étude d'ombres portées de cette maquette pour Paris (48,85° N), le 21 juin, de 8 h à 20 h, heure solaire. Calcule vraiment la hauteur et l'azimut du soleil heure par heure avec les formules astronomiques, oriente-les selon le nord de la maquette, et projette chaque volume sur le sol (union des ombres de toutes les boîtes). Dessin en axonométrie vue du dessus et du sud : la maquette en gris clair, l'ombre au sol en aplat translucide, l'heure et la hauteur du soleil écrites en grand. PNG : l'ombre de 16 h, avec en trait fin les contours des ombres de 8 h, 12 h et 18 h. Écris dans ta réponse la longueur de l'ombre la plus longue que tu as calculée.

Maquette donnée : $ARGUMENTS (s'il n'y a rien, prends le fichier .obj du dossier courant).

Commence toujours comme ça :
1. Ouvre la maquette et lis-la vraiment : les lignes de commentaire (unités, axe vertical, nord), les groupes (`g …`), les sommets et les faces. Si rien n'est dit, suppose des mètres et Z vers le haut, et dis-le.
2. Si `maquette.json` existe déjà, réutilise-le. Sinon écris-le : unités, axe vertical, nord, boîte englobante, niveaux (nom, altitude basse et haute, groupes qui le composent, emprise au sol en m²), nombre de faces. Un niveau = les groupes qui partagent le même préfixe (`niveau-0-…`) ; sans groupes, découpe par altitudes de dalles.
3. Vérifie ta lecture avant de dessiner : les dimensions de la boîte englobante et la hauteur de chaque niveau doivent être cohérentes avec la maquette (compte les faces lues, recoupe les altitudes), sinon corrige `maquette.json`.

Dessine ensuite en code, avec un script Python (numpy, matplotlib, shapely, Pillow ; trimesh si tu veux ; installe ce qui manque avec pip, et ffmpeg sert à la vidéo). Aucun générateur d'images : tout se calcule depuis la maquette.

Ce que tu rends, dans le dossier courant :
- `ombres.png` : le dessin final, 1080 × 1920 en portrait, sans marge perdue. Le dessin doit occuper au moins 70 % de la hauteur. Trait net, niveau d'un rendu d'école d'architecture ou d'agence, jamais un graphique de tableur ni une vue 3D de logiciel par défaut (pas d'axes, pas de grille). Pas de titre géant : un petit cartouche discret (nom du dessin, échelle graphique, nord si le dessin est en plan).
- `ombres.mp4` : 3 s, 1080 × 1920, 30 i/s, H.264, yuv420p, où l'ombre tourne autour de la maison de 8 h à 20 h et l'heure défile et se termine sur l'image finale tenue les 20 dernières images. La première image n'est jamais vide.

Ouvre le PNG pour le regarder, et corrige s'il y a du texte coupé ou qui se chevauche, ou une face qui passe devant ce qu'elle devrait cacher. Termine en disant en quelques lignes ce que le dessin montre, ce que tu as lu dans la maquette et ce que tu as supposé parce qu'elle ne le dit pas. N'invente rien sans le dire.
