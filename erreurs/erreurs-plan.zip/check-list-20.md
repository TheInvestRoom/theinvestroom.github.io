# Check-list : 20 contrôles d'un plan de logement neuf

Pour chaque contrôle : ✅ conforme, ❌ erreur (avec le chiffre mesuré), ? pas vérifiable sur ce plan.
Textes : arrêté du 24 décembre 2015 (accessibilité des logements neufs), arrêté du 24 mars 1982 (aération),
décret n° 2002-120 du 30 janvier 2002 (logement décent). Les « règles de l'art » ne sont pas des lois.

## Escalier
1. Escalier confortable : hauteur de marche h (hauteur d'étage ÷ nombre de contremarches) de 16 à 18 cm, et 2h + g entre 60 et 64 cm (formule de Blondel, règle de l'art).

## Unité de vie et circulations (arrêté du 24/12/2015)
2. Logement sur plusieurs niveaux : le niveau d'entrée contient une cuisine, un séjour, une chambre, un WC et une salle d'eau (art. 13).
3. Porte d'entrée : largeur nominale d'au moins 0,90 m, passage utile d'au moins 0,83 m (art. 11).
4. Portes intérieures : largeur nominale d'au moins 0,80 m, passage utile d'au moins 0,77 m (art. 11).
5. Circulations intérieures du logement : au moins 0,90 m de large (art. 11).
6. Chambre de l'unité de vie : autour d'un lit de 1,40 × 1,90 m, un passage de 0,90 m sur les deux grands côtés et de 1,20 m sur le petit côté libre, ou l'inverse (art. 13).
7. Chambre : un espace libre de 1,50 m de diamètre, hors lit et hors débattement de porte (art. 13).
8. Salle d'eau : un espace libre de 1,50 m de diamètre (empiètement de 25 cm toléré sur le débattement de porte, de 15 cm sous la vasque) (art. 13).
9. WC : un espace libre de 0,80 × 1,30 m à côté de la cuvette, hors débattement de porte (art. 13).
10. Cuisine : un passage de 1,50 m entre les appareils, les meubles fixes et les parois, hors débattement de porte (art. 13).
11. Seuils : 2 cm de ressaut au plus (art. 11).
12. Commandes : un interrupteur à l'entrée de chaque pièce, les commandes entre 0,90 et 1,30 m du sol (art. 11).

## Air et lumière
13. Sorties d'air (bouches d'extraction) au moins dans la cuisine, chaque salle de bains ou d'eau et chaque WC (arrêté du 24/03/1982, art. 2).
14. Entrées d'air dans toutes les pièces principales (arrêté du 24/03/1982, art. 2).
15. Pièces principales : éclairement naturel suffisant et un ouvrant donnant à l'air libre (décret 2002-120, art. 2, 7°).
16. Au moins une pièce principale de 9 m² sous 2,20 m de hauteur, ou de 20 m³ (décret 2002-120, art. 4).

## Dessin
17. Débattements : aucune porte ne heurte un équipement, un meuble fixe ou une autre porte (règle de l'art).
18. Cotes : la somme des cotes partielles égale la cote totale (règle de dessin).
19. Surfaces : chaque surface annoncée correspond aux cotes, à 2 % près (règle de dessin).
20. Échelle, nord et cartouche présents (règle de dessin).
