# Contrôle du plan « T4 en duplex · niveau d'entrée · 1/50 »

**7 erreurs trouvées** (7 ❌, 11 ✅, 2 ?).

## Erreurs, de la plus grave à la moins grave

1. **Porte d'entrée trop étroite** : 0,80 m (cotée « 80 » et mesurée 0,80 m), exigé ≥ 0,90 m nominal / 0,83 m utile (contrôle 3, art. 11).
2. **Dégagement trop étroit** : 0,80 m entre cloisons (coté et mesuré), exigé ≥ 0,90 m (contrôle 5, art. 11).
3. **Chambre 1 : passages autour du lit insuffisants** : 0,74 m de chaque grand côté (1,70 m au pied), exigé 0,90 m + 0,90 m + 1,20 m, ou 1,20 m + 1,20 m + 0,90 m (contrôle 6, art. 13). La pièce fait 2,90 m de large ; avec un lit de 1,40 m, il resterait 1,50 m pour 1,80 m nécessaires : il manque au moins 0,30 m.
4. **WC sans bouche d'extraction** : 0 bouche dans le WC (bouches seulement dans la cuisine et la salle d'eau), exigé : une dans chaque WC (contrôle 13, arrêté du 24/03/1982).
5. **Escalier trop raide** : h = 2,70 m ÷ 12 = 22,5 cm (exigé 16 à 18 cm) et 2h + g = 45 + 22 = 67 cm (exigé 60 à 64 cm) (contrôle 1, règle de l'art). Pour respecter la règle, il faudrait 15 ou 16 contremarches (h = 18 ou 16,9 cm).
6. **La porte de la salle d'eau heurte la vasque** : le vantail de 0,80 m balaie le meuble vasque sur environ 0,70 × 0,33 m (contrôle 17, règle de l'art).
7. **La chaîne de cotes ne boucle pas** : 6,53 + 0,80 + 2,90 = 10,23 m ≠ 10,40 m. Les 0,17 m manquants correspondent aux deux cloisons du dégagement (0,09 et 0,07 m mesurées), qui ne sont pas cotées (contrôle 18).

## Les 20 contrôles

| # | Contrôle | Résultat | Mesuré sur le plan | Exigé |
|---|---|---|---|---|
| 1 | Escalier (h et Blondel) | ❌ | h = 270 ÷ 12 = 22,5 cm ; 2h + g = 67 cm | h de 16 à 18 cm ; 2h + g de 60 à 64 cm |
| 2 | Unité de vie au niveau d'entrée | ✅ | cuisine + séjour, chambre 1, WC, salle d'eau | cuisine, séjour, chambre, WC, salle d'eau |
| 3 | Porte d'entrée | ❌ | 0,80 m | ≥ 0,90 m nominal / 0,83 m utile |
| 4 | Portes intérieures | ✅ | 4 portes cotées 80 (baies mesurées de 0,81 à 0,85 m) | ≥ 0,80 m nominal / 0,77 m utile (passage utile non dessiné) |
| 5 | Circulations | ❌ | dégagement 0,80 m | ≥ 0,90 m |
| 6 | Passages autour du lit | ❌ | 0,74 m / 0,74 m / 1,70 m | 0,90 / 0,90 / 1,20 m (ou 1,20 / 1,20 / 0,90 m) |
| 7 | Chambre : Ø 1,50 m | ✅ | Ø 1,50 m possible au pied du lit (bande libre de 1,70 m × 2,90 m, hors débattement) | Ø 1,50 m hors lit et hors débattement |
| 8 | Salle d'eau : Ø 1,50 m | ✅ | Ø 1,57 m au maximum avec les tolérances (1,39 m sans) | Ø 1,50 m (tolérances : 25 cm sur la porte, 15 cm sous la vasque) |
| 9 | WC : 0,80 × 1,30 m | ✅ | 0,82 × 1,49 m le long de la cuvette ; la porte ouvre vers l'extérieur | 0,80 × 1,30 m hors débattement |
| 10 | Cuisine : passage de 1,50 m | ✅ | aucun meuble fixe ni paroi face aux plans (> 1,50 m) ; les chaises (mobiles) sont à 1,23 m | ≥ 1,50 m |
| 11 | Seuils ≤ 2 cm | ? | non représenté | ≤ 2 cm |
| 12 | Interrupteurs et commandes | ? | aucune commande dessinée | à l'entrée de chaque pièce, de 0,90 à 1,30 m |
| 13 | Bouches d'extraction | ❌ | cuisine 1, salle d'eau 1, WC 0 | cuisine + salle d'eau + chaque WC |
| 14 | Entrées d'air | ✅ | séjour 3, chambre 1 : 1 | dans chaque pièce principale |
| 15 | Jour et ouvrant | ✅ | séjour 4 fenêtres, chambre 1 : 1 fenêtre | ouvrant sur l'air libre dans chaque pièce principale |
| 16 | Pièce de 9 m² | ✅ | séjour 48,5 m² ; chambre 10,4 m² | ≥ 9 m² (h ≥ 2,20 m) ou 20 m³ |
| 17 | Débattements | ❌ | la porte de la salle d'eau balaie la vasque (≈ 0,70 × 0,33 m) | aucun heurt |
| 18 | Somme des cotes | ❌ | 6,53 + 0,80 + 2,90 = 10,23 m | = 10,40 m |
| 19 | Surfaces à 2 % près | ✅ | ch. 2,90 × 3,60 = 10,44 ; SdE 2,90 × 1,93 = 5,60 ; WC 1,50 × 1,31 = 1,97 ; cellier 1,33 × 2,33 = 3,10 ; séjour 52,24 − entrée 1,56 − escalier 2,19 = 48,49 m² | écart ≤ 2 % (le plus grand : WC, 1,5 %) |
| 20 | Échelle, nord, cartouche | ✅ | 1/50 + échelle graphique, flèche N, cartouche | présents |

Méthode : échelle mesurée sur l'image à 164 px/m (échelle graphique 493 px pour 3 m ; intérieur 1 706 px pour 10,40 m ; 1 312 px pour 8,00 m). Les dimensions non cotées ont été mesurées au pixel, avec une incertitude d'environ ± 1 cm.
