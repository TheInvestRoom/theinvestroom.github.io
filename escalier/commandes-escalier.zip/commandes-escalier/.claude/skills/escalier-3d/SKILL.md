---
name: escalier-3d
description: Dessine en 3D (axonométrie) une version de l'escalier calculée par /escalier, avec le plancher, la trémie et l'échappée.
argument-hint: "[droit | quart] [escalier.json]"
disable-model-invocation: true
---

Dessine en 3D une version de l'escalier calculée par `/escalier`.

Données : $ARGUMENTS : la version (`droit` ou `quart` ; s'il n'y a rien, la version qui passe) et `escalier.json` (dans le dossier courant s'il n'est pas donné ; s'il n'existe pas, lance d'abord la démarche de `/escalier`).

Relis `escalier.json` et construis exactement les marches qu'il décrit (mêmes contours, mêmes hauteurs) : ne recalcule pas un autre escalier. Si tu trouves une incohérence, dis-la et ne la corrige pas en silence.

Fais simple et juste, en un seul script Python (numpy, Pillow ou matplotlib), sans générateur d'images :
- projection isométrique d'un point (x, y, z) : X = (x − y) × cos 30°, Y = (x + y) × sin 30° + z, vu depuis le côté opposé au mur (le mur reste derrière l'escalier) ; si l'escalier est mieux lisible en miroir, inverse x ;
- chaque marche est un prisme : son dessus (contour de `escalier.json` à la hauteur z), sa contremarche et sa joue côté jour, de z − h à z ; dessine les marches de la dernière à la première (de l'arrière vers l'avant), le plancher et le mur avant elles ;
- le sol du rez-de-chaussée en gris très clair, le mur porteur coupé à hauteur d'étage en gris moyen, le plancher de l'étage en tranche de 25 cm avec la trémie découpée et son chant en noir ; dessus des marches blanc cassé, contremarches et joues un ton plus sombre, arêtes en trait noir fin ;
- l'échappée la plus critique : un trait vertical épais du nez de marche (ligne des nez) au dessous du plancher, à l'aplomb du bord de trémie, en vert (#1F9D55) si la version passe, en rouge (#D93025) sinon, avec sa valeur en très gros (au moins 70 px) ; une silhouette humaine simple de 1,80 m, à l'échelle, debout sur cette marche ;
- `axo-<version>.png`, 1000 × 1120 px, portrait, fond blanc, le dessin sur au moins 80 % de la largeur ; un seul titre court en haut (« DROIT » ou « QUART TOURNANT ») ; aucun autre texte que l'échappée.

Ouvre le PNG pour le regarder, en entier puis en gros plan : les marches doivent se lire comme un vrai escalier (aucune face mal triée, aucune marche qui flotte), sinon corrige. Termine en disant en quelques lignes ce que montre la vue et ce que tu as supposé.
