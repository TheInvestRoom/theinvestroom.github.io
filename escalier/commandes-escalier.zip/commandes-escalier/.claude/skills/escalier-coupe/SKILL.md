---
name: escalier-coupe
description: Dessine la coupe de chaque version de l'escalier calculée par /escalier, avec l'échappée en couleur.
argument-hint: "[escalier.json]"
disable-model-invocation: true
---

Dessine en coupe les versions de l'escalier calculées par `/escalier`.

Données : $ARGUMENTS (s'il n'y a rien, prends `escalier.json` dans le dossier courant ; s'il n'existe pas, lance d'abord la démarche de `/escalier`).

Relis `escalier.json` et redessine exactement les marches qu'il décrit : ne recalcule pas un autre escalier. Si tu trouves une incohérence, dis-la et ne la corrige pas en silence.

En code, avec un script Python (matplotlib, numpy). Aucun générateur d'images.

Une image par version, dans le dossier courant : `coupe-droit.png` et `coupe-quart.png`. Chacune :
- 1000 × 1120 px, portrait, fond blanc ; le dessin occupe au moins 80 % de la largeur, rien de vide en haut ni en bas ;
- coupe le long du mur, dans l'axe de la volée qui passe sous le bord de trémie : sol du rez-de-chaussée, plancher de l'étage coupé en noir plein (poché) avec le vide de la trémie, marches coupées en noir, les marches vues en trait fin, garde-corps en trait fin ;
- l'**échappée** la plus critique : un trait vertical du nez de marche au dessous du plancher, sa valeur en très gros (au moins 70 px de haut), en vert (#1F9D55) si elle passe, en rouge (#D93025) si elle ne passe pas ; une silhouette humaine de 1,80 m debout sur cette marche, sa tête dans la même couleur si elle touche ;
- un seul titre court en haut (« DROIT » ou « QUART TOURNANT ») et, en bas, une seule ligne de chiffres en gros : « 16 marches · h 17,5 · g 28 » (avec les vraies valeurs) ;
- textes d'au moins 30 px, jamais coupés ni superposés, lisibles sur un téléphone ; trait net, rendu de planche d'école d'architecture, jamais un graphique de tableur.

Ouvre chaque PNG pour le regarder, en entier puis en gros plan, et corrige ce qui déborde, se chevauche ou est illisible. Termine en disant en quelques lignes ce que montre chaque coupe et ce que tu as supposé.
