---
name: escalier-plan
description: Dessine en plan les deux versions de l'escalier calculées par /escalier (droit, quart tournant), dans la trémie.
argument-hint: "[escalier.json]"
disable-model-invocation: true
---

Dessine en plan les versions de l'escalier calculées par `/escalier`.

Données : $ARGUMENTS (s'il n'y a rien, prends `escalier.json` dans le dossier courant ; s'il n'existe pas, lance d'abord la démarche de `/escalier`).

Relis `escalier.json` et redessine exactement les marches qu'il décrit (même nombre, mêmes girons, même placement) : ne recalcule pas un autre escalier. Si tu trouves une incohérence dans `escalier.json` (marche hors de la trémie, foulée qui ne tombe pas juste), dis-la et ne la corrige pas en silence.

En code, avec un script Python (matplotlib, numpy). Aucun générateur d'images.

Une image par version, dans le dossier courant : `plan-droit.png` et `plan-quart.png`. Chacune :
- 1000 × 1120 px, portrait, fond blanc ; le dessin occupe au moins 80 % de la largeur ;
- plan de l'étage au droit de l'escalier : mur porteur en noir plein (poché), contour de la trémie en trait mixte, les bords libres de plancher, les marches en trait fin numérotées de 1 à n depuis le départ, la ligne de foulée avec sa flèche de montée et le mot « monte » ;
- pour une version balancée, les marches balancées teintées d'un gris clair ; pour la partie qui dépasse de la trémie au rez-de-chaussée, un trait pointillé ;
- un seul titre court en haut (« DROIT » ou « QUART TOURNANT ») et, en bas, une seule ligne en gros : la place occupée au sol (« 3,92 × 0,90 m », avec les vraies valeurs) ;
- deux cotes seulement : les dimensions de la trémie ; textes d'au moins 30 px, jamais coupés ni superposés ; trait net, rendu de planche d'école d'architecture.

Ouvre chaque PNG pour le regarder, en entier puis en gros plan, et corrige ce qui déborde, se chevauche ou est illisible.

Termine en disant en quelques lignes ce que montre chaque plan et ce qui n'est pas dans `escalier.json` et que tu as supposé.
