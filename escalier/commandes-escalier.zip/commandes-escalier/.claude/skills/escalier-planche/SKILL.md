---
name: escalier-planche
description: Range les plans, coupes et 3D de l'escalier sur une planche, avec le calcul et le verdict de chaque version.
argument-hint: "[dossier des dessins]"
disable-model-invocation: true
---

Fais la planche de l'escalier, à partir de ce qu'ont produit `/escalier`, `/escalier-coupe`, `/escalier-plan` et `/escalier-3d`.

Données : $ARGUMENTS (s'il n'y a rien, le dossier courant : `escalier.json`, `calcul.md`, `coupe-*.png`, `plan-*.png`, `axo-*.png`).

Avec un script Python (Pillow), en réutilisant les images telles quelles, sans les redessiner :
- `planche.png`, 1000 × 1120 px, portrait, fond blanc : une colonne par version (droit, quart tournant), et pour chacune, de haut en bas, l'axo, la coupe et le plan, puis son verdict en une ligne (« PASSE · 2,05 m » en vert #1F9D55 ou « NE PASSE PAS · 1,74 m » en rouge #D93025, avec les vraies valeurs de `escalier.json`) ; la version recommandée encadrée ;
- un titre court en haut (« TON ESCALIER, 2 VERSIONS ») et une ligne de calcul commune en bas (« 2,80 m · 16 marches · 2h + g = 63 », avec les vraies valeurs) ;
- aucune image déformée (garde les proportions), aucun texte de moins de 26 px, rien qui déborde.

Ouvre la planche pour la regarder et corrige ce qui déborde ou se chevauche. Termine en une phrase : la version recommandée et son chiffre décisif.
