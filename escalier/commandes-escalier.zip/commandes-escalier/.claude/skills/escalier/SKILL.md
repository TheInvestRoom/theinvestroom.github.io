---
name: escalier
description: Calcule l'escalier qui passe dans ta trémie (marches, Blondel, échappée), en droit et en quart tournant, avec le verdict.
argument-hint: "[fichier des données ou données en clair : hauteur à franchir, épaisseur du plancher, trémie, largeur]"
disable-model-invocation: true
---

Tu dimensionnes l'escalier d'un projet comme un architecte le fait avant de le dessiner. Tu calcules seulement : les dessins viennent ensuite avec `/escalier-coupe`, `/escalier-plan` et `/escalier-3d`.

Données : $ARGUMENTS (s'il n'y a rien, prends le fichier `.md` du dossier courant qui décrit la trémie).

## 1. Lire les données

Relève : la hauteur à franchir H (sol fini à sol fini), l'épaisseur du plancher e (dalle, chape, plafond), la trémie (longueur × largeur), ce qui la borde (mur, bords libres), la largeur d'emmarchement voulue et la place disponible au départ. Si une donnée manque, choisis une valeur courante et note-la comme supposée.

## 2. Calculer deux versions : droit, puis quart tournant balancé

Pour chacune, en écrivant chaque calcul avec les chiffres :

1. **Nombre de hauteurs** n : H divisé par une hauteur visée de 17 cm environ, arrondi ; h = H / n. Référence des logements neufs (arrêté du 24 décembre 2015, logements sur plusieurs niveaux et maisons individuelles neuves construites pour être vendues ou louées) : h ≤ 18 cm, giron ≥ 24 cm, largeur ≥ 0,80 m. Écris que ce seuil ne s'impose pas à quelqu'un qui construit pour lui-même, mais qu'il reste la référence.
2. **Giron** g par la règle de Blondel (règle de l'art) : 2h + g entre 60 et 64 cm ; vise 63 cm, arrondis g au centimètre et donne 2h + g.
3. **Ligne de foulée** au milieu de l'emmarchement (escalier de moins de 1 m de large) : longueur de foulée = (n − 1) × g.
4. **Placement** : l'escalier longe le mur et arrive de plain-pied sur un bord de la trémie ; à l'étage, il reste dans la trémie. Le droit monte le long du grand côté. Le quart tournant monte le long du mur puis tourne d'un quart dans l'angle de la trémie : place 3 à 5 marches balancées dans le tournant, giron sur la ligne de foulée égal à g, collet côté jour d'au moins 10 cm (donne la plus petite valeur). Dis où chaque version commence au rez-de-chaussée et de combien elle sort de l'aplomb de la trémie.
5. **Échappée** : hauteur libre mesurée à la verticale entre la ligne des nez de marches et le dessous du plancher de l'étage (bords de trémie compris). Cherche le point le plus bas sur toute la montée, donne sa valeur au centimètre et la marche où il tombe. On vise au moins 2,00 m (usage courant ; aucun texte ne le fixe pour une maison). En dessous, la tête d'un adulte de 1,80 m touche le bord : la version **ne passe pas**.
6. **Verdict** : passe ou ne passe pas, avec le chiffre qui décide. Puis la version recommandée, en une phrase.

## 3. Écrire

Avec un petit script Python (bibliothèque standard), pour que les chiffres sortent d'un calcul et non d'une estimation :
- `escalier.json` : les données ; pour chaque version (`droit`, `quart`) : n, h, g, 2h + g, longueur de foulée, échappée mini, marche concernée, passe ou non ; et la géométrie de chaque marche en mètres (contour du dessus de la marche en plan, dans un repère dont l'origine est l'angle de la trémie contre le mur, x le long du mur, y vers l'intérieur ; et sa hauteur z), plus le contour de la trémie et la position du mur, pour que les autres commandes redessinent exactement le même escalier ;
- `calcul.md` : le calcul pas à pas, lisible par un étudiant, une ligne par étape, les chiffres réels, et le verdict.

Relis `calcul.md` contre `escalier.json` : les chiffres doivent être identiques. Termine en disant en quelques lignes les chiffres des deux versions, celle qui passe et ce que tu as supposé. N'invente rien sans le dire.
