# Escalier de la maison d'exemple : calcul

## Données

- Hauteur à franchir H = 2,80 m ; plancher e = 0,25 m, donc dessous du plancher à 2,80 − 0,25 = 2,55 m.
- Trémie 2,60 × 1,90 m, grand côté contre un mur porteur, trois bords libres. Emmarchement 0,90 m.
- Repère : origine à l'angle de la trémie contre le mur, x le long du mur, y vers l'intérieur.
- Supposé :
  - Hauteur de marche visée : 17 cm (valeur courante).
  - Le mur porteur se prolonge au rez-de-chaussée au-delà de l'angle x = 0 de la trémie (jusqu'à x = −2,00 m au moins), pour que l'escalier le longe dès son départ.
  - Épaisseur du mur : 0,20 m (sert seulement au dessin).
  - Nez de marche sans débord : le giron est la profondeur de la marche en plan.
  - Dessous du plancher plat, à 2,80 − 0,25 = 2,55 m, jusqu'au bord de la trémie (pas de retombée de poutre).
  - Le quart tournant arrive sur le grand bord libre de la trémie (y = 1,90 m) ; il tourne dans l'angle mur / petit bord libre (x = 2,60 m ; y = 0).
  - Échappée mesurée sur la ligne de foulée : le bord de trémie passé par-dessous (x = 0) coupe une volée droite à angle droit, donc la ligne des nez y a la même hauteur sur toute la largeur.

## Commun aux deux versions

1. Nombre de hauteurs : 2,80 / 0,17 = 16,47 → n = 16 ; h = 2,80 / 16 = 17,5 cm.
2. Référence des logements neufs (arrêté du 24 décembre 2015 : logements sur plusieurs niveaux et maisons individuelles neuves construites pour être vendues ou louées) : h ≤ 18 cm, giron ≥ 24 cm, largeur ≥ 0,80 m. Ce seuil ne s'impose pas à quelqu'un qui construit pour lui-même, mais il reste la référence. Ici h = 17,5 cm ≤ 18 ; largeur 0,90 m ≥ 0,80.
3. Blondel : g = 63 − 2 × 17,5 = 28 → g = 28 cm (≥ 24) ; 2h + g = 63 cm, dans 60–64.
4. Ligne de foulée au milieu de l'emmarchement (largeur < 1 m) : à 0,45 m du mur ; longueur = (16 − 1) × 0,28 = 4,20 m (15 girons).

## Version droite

5. L'escalier longe le mur (y = 0 à 0,90) et arrive sur le petit bord libre x = 2,60 m.
6. Départ : x = 2,60 − 4,20 = −1,60 m : il commence 1,60 m avant l'aplomb de la trémie (bord x = 0).
7. Échappée : au bord x = 0, la ligne des nez est à 0,175 + 1,60 × 0,175 / 0,28 = 1,175 m ; hauteur libre = 2,55 − 1,175 = 1,375 m, soit 1,37 m arrondi par défaut. C'est le point le plus bas : la verticale tombe sur la marche 6, 20 cm derrière son nez.
8. Verdict : **ne passe pas** — 1,37 m < 2,00 m : un adulte de 1,80 m se cogne au bord de la trémie.

## Version quart tournant balancé

9. 1re volée le long du mur (ligne de foulée y = 0,45), quart tournant dans l'angle mur / bord x = 2,60, 2e volée le long de ce bord (ligne de foulée x = 2,60 − 0,45 = 2,15), arrivée sur le grand bord libre y = 1,90 m.
10. Foulée de la 2e volée : 1,90 − 0,45 = 1,45 m ; angle de la ligne de foulée à 4,20 − 1,45 = 2,75 m du départ ; départ x = 2,15 − 2,75 = −0,60 m : il commence 0,60 m avant l'aplomb de la trémie.
11. Balancement : 5 marches balancées (n° 8 à 12), entre les contremarches droites 8 et 13. Giron sur la ligne de foulée = 28 cm pour toutes. Longueur du jour entre ces deux contremarches = 5 × 28 − 90 = 50 cm, partagée en 5 collets de 10 cm. Collet le plus petit : 10 cm (≥ 10). Giron côté mur au plus : 46,7 cm.
12. Échappée : le seul bord franchi par dessous est x = 0, sur la 1re volée droite. Ligne des nez = 0,175 + 0,60 × 0,175 / 0,28 = 0,550 m ; hauteur libre = 2,55 − 0,550 = 2,00 m. Point le plus bas : marche 3, 4 cm derrière son nez.
13. Verdict : **passe** — 2,00 m ≥ 2,00 m, sans aucune marge.

## Recommandation

Le quart tournant balancé : il tient dans la trémie, sort de 0,60 m au départ et laisse 2,00 m d'échappée, alors que le droit tombe à 1,37 m. La marge est nulle : un plancher plus épais ou un départ plus proche de la trémie le ferait échouer, à vérifier sur les cotes réelles.
