# Maison d'exemple (inventée) : l'escalier à placer

- Hauteur à franchir, du sol fini du rez-de-chaussée au sol fini de l'étage : 2,80 m
- Épaisseur du plancher de l'étage (dalle, chape et plafond compris) : 0,25 m
- Trémie réservée dans le plancher de l'étage : 2,60 m × 1,90 m
- La trémie longe un mur porteur sur son grand côté (2,60 m) ; ses trois autres côtés sont des bords de plancher libres.
- Largeur d'emmarchement voulue : 0,90 m
- Au rez-de-chaussée, la place est libre devant la trémie : l'escalier peut commencer en dehors de son aplomb.
- L'arrivée à l'étage se fait sur un bord de la trémie, de plain-pied avec le plancher de l'étage.
