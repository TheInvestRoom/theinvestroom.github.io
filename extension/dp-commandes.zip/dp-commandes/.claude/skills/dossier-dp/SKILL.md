---
name: dossier-dp
description: Les pièces graphiques de la déclaration préalable rangées sur une planche, avec la liste du bordereau.
argument-hint: "[nom du projet]"
disable-model-invocation: true
---

Nom du projet : $ARGUMENTS

Assemble les pièces PNG du dossier courant (`dp1.png`, `dp2.png`, `dp3.png`, `dp4.png`, celles qui existent) sur une seule planche de rendu, sans les redessiner ni les déformer. Grille stricte, marges égales, chaque pièce avec son code (DP1…) et son intitulé. En bas, la liste des pièces du bordereau du CERFA 13703 pour une extension (DP1 plan de situation, DP2 plan de masse, DP3 plan en coupe, DP4 plan des façades et des toitures, DP5 représentation de l'aspect extérieur, DP6 document graphique d'insertion, DP7 photo de l'environnement proche, DP8 photo du paysage lointain), avec une coche pour celles qui sont sur la planche et une case vide pour celles qui restent à faire. Rends `dossier.png` en 1080 × 1350 et `dossier.pdf` (A3). Termine en disant quelles pièces sont entrées dans la planche et lesquelles restent à faire.
