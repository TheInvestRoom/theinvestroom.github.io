---
name: dp1
description: DP1, plan de situation du terrain dans la commune, sur le Plan IGN.
argument-hint: "[adresse ou référence cadastrale]"
disable-model-invocation: true
---

Terrain : $ARGUMENTS (une adresse, ou une référence cadastrale de 14 caractères comme 91477000BT0159).

Commence toujours comme ça :
1. Si `permis/site.json` n'existe pas, lance `python outils/donnees_permis.py "<adresse>"` (ou `python outils/donnees_permis.py --parcelle <référence>`). Il télécharge une seule fois les données publiques de l'IGN dans `permis/` : la parcelle du cadastre en mètres (x vers l'est, y vers le nord), ses côtés (sur voie ou séparatifs, longueurs), les voisins, les bâtiments BD TOPO avec leur hauteur (`sur_parcelle` vrai pour ceux du terrain), les routes, la zone du PLU, les servitudes (`prescriptions_et_servitudes`), une grille d'altitudes RGE ALTI au pas de 2 m (`alti.json`) et des fonds Plan IGN et photo aérienne (`fonds.json` donne les mètres par pixel et le contour de la parcelle déjà en pixels). S'il existe, réutilise-le.
2. Lis `permis/site.json` : vérifie que la parcelle trouvée est bien celle demandée (commune, section, numéro, contenance), sinon arrête-toi et dis-le. Repère la maison existante : le bâtiment résidentiel du terrain, son contour exact et sa hauteur. Lis les servitudes : si le terrain est concerné par un plan de prévention des risques, un périmètre de monument historique ou un site protégé, écris-le en rouge dans le cartouche (« Terrain en zone … : règlement à vérifier ») et dis-le à la fin.
3. Lis `projet.txt` : c'est l'existant et le projet (extension, surélévation, abri…). S'il manque, arrête-toi et demande-le. N'invente aucune dimension : ce qui n'y est pas, tu le supposes et tu le dis.
Dessine ensuite en code, avec un script Python (matplotlib, numpy, shapely, Pillow ; installe ce qui manque avec pip ; ffmpeg sert à la vidéo). Aucun générateur d'images : tout se calcule depuis `permis/` et `projet.txt`. Convention de tout le dossier : l'existant en gris (trait gris foncé, aplat gris clair), le projet en orange brûlé (#D9541E), plein et bien visible.

Fais la pièce DP1 de la déclaration préalable : le plan de situation du terrain dans la commune. Deux vues l'une au-dessus de l'autre, de même largeur : en haut la commune (`fond_commune.png`), en bas le quartier (`fond_quartier.png`), recadrées autour du terrain, le Plan IGN un peu adouci pour que le terrain ressorte. Sur les deux, la parcelle en contour rouge vif épais avec un aplat rouge translucide, et sur la vue commune un cercle rouge autour, assez grand pour se voir sur un téléphone. Une échelle graphique exacte sur chaque vue, calculée depuis `metres_par_pixel`, et l'échelle approchée au 1/… pour la feuille A4. Le nord. Le nom de la commune, et sur la vue quartier le nom de la voie qui dessert le terrain. Reporte sur la vue quartier le point et l'angle de prise de vue de la photo lointaine DP8 (un petit cône numéroté 8, placé sur la voie, tourné vers le terrain).

Ce que tu rends, dans le dossier courant :
- `dp1.png` : 1080 × 1350 en portrait, fond blanc papier, à fond perdu, trait noir net de plusieurs épaisseurs, au plus 3 couleurs sobres en plus du gris et de l'orange du projet. Le niveau d'un dossier rendu par une agence d'architecture, jamais un graphique de tableur. Un cartouche propre en bas : « DP1 · Plan de situation », la commune, la référence cadastrale, l'échelle, le nord, la date, une légende « existant / projet », « Données © IGN · Licence Ouverte 2.0 ».
- `dp1.pdf` : la même pièce sur une feuille A4 portrait, à l'échelle écrite dans le cartouche (vérifie-la avec une cote connue).
- `dp1.mp4` : 3 s, 1080 × 1350, 30 i/s, H.264, yuv420p, où le dessin se construit sous les yeux (la vue commune apparaît, le cercle rouge se resserre sur le terrain, puis la vue quartier se déroule et la parcelle se trace), et se termine sur l'image finale tenue les 20 dernières images. La première image n'est jamais vide.

Ouvre le PNG pour le regarder, et corrige tout texte coupé, qui se chevauche ou trop petit pour se lire sur un téléphone. Termine en disant en quelques lignes ce que la pièce montre, les chiffres que tu as calculés et ce que tu as supposé. N'invente rien sans le dire.
