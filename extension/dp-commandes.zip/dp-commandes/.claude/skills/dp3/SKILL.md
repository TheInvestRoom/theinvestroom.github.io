---
name: dp3
description: DP3, coupe du terrain naturel (RGE ALTI), de la maison existante et de l'extension.
argument-hint: "[adresse ou référence cadastrale]"
disable-model-invocation: true
---

Terrain : $ARGUMENTS (une adresse, ou une référence cadastrale de 14 caractères comme 91477000BT0159).

Commence toujours comme ça :
1. Si `permis/site.json` n'existe pas, lance `python outils/donnees_permis.py "<adresse>"` (ou `python outils/donnees_permis.py --parcelle <référence>`). Il télécharge une seule fois les données publiques de l'IGN dans `permis/` : la parcelle du cadastre en mètres (x vers l'est, y vers le nord), ses côtés (sur voie ou séparatifs, longueurs), les voisins, les bâtiments BD TOPO avec leur hauteur (`sur_parcelle` vrai pour ceux du terrain), les routes, la zone du PLU, les servitudes (`prescriptions_et_servitudes`), une grille d'altitudes RGE ALTI au pas de 2 m (`alti.json`) et des fonds Plan IGN et photo aérienne (`fonds.json` donne les mètres par pixel et le contour de la parcelle déjà en pixels). S'il existe, réutilise-le.
2. Lis `permis/site.json` : vérifie que la parcelle trouvée est bien celle demandée (commune, section, numéro, contenance), sinon arrête-toi et dis-le. Repère la maison existante : le bâtiment résidentiel du terrain, son contour exact et sa hauteur. Lis les servitudes : si le terrain est concerné par un plan de prévention des risques, un périmètre de monument historique ou un site protégé, écris-le en rouge dans le cartouche (« Terrain en zone … : règlement à vérifier ») et dis-le à la fin.
3. Lis `projet.txt` : c'est l'existant et le projet (extension, surélévation, abri…). S'il manque, arrête-toi et demande-le. N'invente aucune dimension : ce qui n'y est pas, tu le supposes et tu le dis.
Dessine ensuite en code, avec un script Python (matplotlib, numpy, shapely, Pillow ; installe ce qui manque avec pip ; ffmpeg sert à la vidéo). Aucun générateur d'images : tout se calcule depuis `permis/` et `projet.txt`. Convention de tout le dossier : l'existant en gris (trait gris foncé, aplat gris clair), le projet en orange brûlé (#D9541E), plein et bien visible.

Fais la pièce DP3 de la déclaration préalable : le plan en coupe du terrain et de la construction, selon la coupe A-A : une ligne qui traverse la maison existante et l'extension de `projet.txt`, d'une limite de la parcelle à l'autre et un peu au-delà. Le profil du terrain naturel se lit dans `alti.json` (interpolation bilinéaire, un point tous les 0,50 m) ; dessine-le en trait plein épais. La maison existante coupée en gris (murs en poché gris, toiture à sa hauteur BD TOPO, pente supposée et dite), l'extension coupée en orange (murs en poché orange, toit plat, acrotère), avec les cotes de niveau en mètres NGF (plancher, acrotère, faîtage existant) et les hauteurs par rapport au terrain naturel. Les limites de la parcelle marquées et nommées sous le profil. L'échelle verticale est la même que l'échelle horizontale : n'exagère pas le relief.

Ce que tu rends, dans le dossier courant :
- `dp3.png` : 1080 × 1350 en portrait, fond blanc papier, à fond perdu, trait noir net de plusieurs épaisseurs, au plus 3 couleurs sobres en plus du gris et de l'orange du projet. Le niveau d'un dossier rendu par une agence d'architecture, jamais un graphique de tableur. Un cartouche propre en bas : « DP3 · Plan en coupe », la commune, la référence cadastrale, l'échelle, le nord, la date, une légende « existant / projet », « Données © IGN · Licence Ouverte 2.0 ».
- `dp3.pdf` : la même pièce sur une feuille A3 paysage, au 1/100, à l'échelle écrite dans le cartouche (vérifie-la avec une cote connue).
- `dp3.mp4` : 3 s, 1080 × 1350, 30 i/s, H.264, yuv420p, où le dessin se construit sous les yeux (le profil du terrain se trace de gauche à droite, la maison existante apparaît en gris, puis l'extension monte en orange et les cotes s'écrivent), et se termine sur l'image finale tenue les 20 dernières images. La première image n'est jamais vide.

Ouvre le PNG pour le regarder, et corrige tout texte coupé, qui se chevauche ou trop petit pour se lire sur un téléphone. Termine en disant en quelques lignes ce que la pièce montre, les chiffres que tu as calculés et ce que tu as supposé. N'invente rien sans le dire.
