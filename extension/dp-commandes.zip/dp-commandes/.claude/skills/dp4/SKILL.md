---
name: dp4
description: DP4, les façades touchées par l'extension, avant et après travaux, et la toiture.
argument-hint: "[adresse ou référence cadastrale]"
disable-model-invocation: true
---

Terrain : $ARGUMENTS (une adresse, ou une référence cadastrale de 14 caractères comme 91477000BT0159).

Commence toujours comme ça :
1. Si `permis/site.json` n'existe pas, lance `python outils/donnees_permis.py "<adresse>"` (ou `python outils/donnees_permis.py --parcelle <référence>`). Il télécharge une seule fois les données publiques de l'IGN dans `permis/` : la parcelle du cadastre en mètres (x vers l'est, y vers le nord), ses côtés (sur voie ou séparatifs, longueurs), les voisins, les bâtiments BD TOPO avec leur hauteur (`sur_parcelle` vrai pour ceux du terrain), les routes, la zone du PLU, les servitudes (`prescriptions_et_servitudes`), une grille d'altitudes RGE ALTI au pas de 2 m (`alti.json`) et des fonds Plan IGN et photo aérienne (`fonds.json` donne les mètres par pixel et le contour de la parcelle déjà en pixels). S'il existe, réutilise-le.
2. Lis `permis/site.json` : vérifie que la parcelle trouvée est bien celle demandée (commune, section, numéro, contenance), sinon arrête-toi et dis-le. Repère la maison existante : le bâtiment résidentiel du terrain, son contour exact et sa hauteur. Lis les servitudes : si le terrain est concerné par un plan de prévention des risques, un périmètre de monument historique ou un site protégé, écris-le en rouge dans le cartouche (« Terrain en zone … : règlement à vérifier ») et dis-le à la fin.
3. Lis `projet.txt` : c'est l'existant et le projet (extension, surélévation, abri…). S'il manque, arrête-toi et demande-le. N'invente aucune dimension : ce qui n'y est pas, tu le supposes et tu le dis.
Dessine ensuite en code, avec un script Python (matplotlib, numpy, shapely, Pillow ; installe ce qui manque avec pip ; ffmpeg sert à la vidéo). Aucun générateur d'images : tout se calcule depuis `permis/` et `projet.txt`. Convention de tout le dossier : l'existant en gris (trait gris foncé, aplat gris clair), le projet en orange brûlé (#D9541E), plein et bien visible.

Fais la pièce DP4 de la déclaration préalable : le plan des façades et des toitures, avant et après travaux. Pour chaque façade que l'extension modifie (en général la façade sur laquelle elle s'accole et celle sur le jardin), deux élévations au 1/100 l'une à côté de l'autre, « AVANT » en gris et « APRÈS » avec l'extension en orange, nommées par leur orientation réelle, alignées sur le même sol, le terrain naturel à leur pied tiré de `alti.json`. La maison existante dessinée simplement depuis son contour et sa hauteur (toiture et ouvertures existantes supposées et dites, sans fantaisie) ; l'extension avec les ouvertures de `projet.txt` à leur place et à leurs dimensions, les matériaux écrits en petit à côté, la hauteur de l'acrotère cotée. En plus, une petite vue en plan des toitures après travaux (pans existants, toit plat de l'extension, lanterneau). Tout tient dans le cadre portrait sans être minuscule.

Ce que tu rends, dans le dossier courant :
- `dp4.png` : 1080 × 1350 en portrait, fond blanc papier, à fond perdu, trait noir net de plusieurs épaisseurs, au plus 3 couleurs sobres en plus du gris et de l'orange du projet. Le niveau d'un dossier rendu par une agence d'architecture, jamais un graphique de tableur. Un cartouche propre en bas : « DP4 · Plan des façades et des toitures », la commune, la référence cadastrale, l'échelle, le nord, la date, une légende « existant / projet », « Données © IGN · Licence Ouverte 2.0 ».
- `dp4.pdf` : la même pièce sur une feuille A3 portrait, au 1/100, à l'échelle écrite dans le cartouche (vérifie-la avec une cote connue).
- `dp4.mp4` : 3 s, 1080 × 1350, 30 i/s, H.264, yuv420p, où le dessin se construit sous les yeux (les façades AVANT se dessinent en gris, puis à côté les façades APRÈS où l'extension s'ajoute en orange, ouverture par ouverture), et se termine sur l'image finale tenue les 20 dernières images. La première image n'est jamais vide.

Ouvre le PNG pour le regarder, et corrige tout texte coupé, qui se chevauche ou trop petit pour se lire sur un téléphone. Termine en disant en quelques lignes ce que la pièce montre, les chiffres que tu as calculés et ce que tu as supposé. N'invente rien sans le dire.
