"""Récupère tout ce que les données publiques disent d'une parcelle, en mètres (Lambert 93).

Usage :
    python recuperer_site.py --adresse "12 rue X 91120 Palaiseau" --sortie site.json
    python recuperer_site.py --insee 91477 --section AS --numero 0440 --sortie site.json

Sources (gratuites, sans clé) :
- Base Adresse Nationale (géocodage) : https://api-adresse.data.gouv.fr
- API Carto de l'IGN (cadastre, zonage et prescriptions du Géoportail de l'urbanisme) : https://apicarto.ign.fr
- Géoplateforme IGN, WFS (parcelles et bâtiments BD TOPO en Lambert 93) : https://data.geopf.fr/wfs/ows
- Géoplateforme IGN, altimétrie (RGE ALTI) : https://data.geopf.fr/altimetrie

Bibliothèque standard seulement : aucune installation.
"""
import argparse
import datetime
import json
import math
import sys
import urllib.parse
import urllib.request

UA = {"User-Agent": "capacite-parcelle/1.0"}


def get_json(url, params=None, timeout=90):
    if params:
        url = url + "?" + urllib.parse.urlencode(params, safe=",:|")
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


# ---------------------------------------------------------------- géométrie
def rings_of(geom):
    """Anneaux extérieurs d'un Polygon / MultiPolygon (coordonnées 2D)."""
    if geom["type"] == "Polygon":
        polys = [geom["coordinates"]]
    else:
        polys = geom["coordinates"]
    return [[(p[0], p[1]) for p in poly[0]] for poly in polys]


def aire(ring):
    s = 0.0
    for (x1, y1), (x2, y2) in zip(ring, ring[1:] + ring[:1]):
        s += x1 * y2 - x2 * y1
    return s / 2.0


def centroide(ring):
    a = aire(ring)
    cx = cy = 0.0
    for (x1, y1), (x2, y2) in zip(ring, ring[1:] + ring[:1]):
        f = x1 * y2 - x2 * y1
        cx += (x1 + x2) * f
        cy += (y1 + y2) * f
    return cx / (6 * a), cy / (6 * a)


def dedans(pt, ring):
    x, y = pt
    c = False
    n = len(ring)
    for i in range(n):
        x1, y1 = ring[i]
        x2, y2 = ring[(i + 1) % n]
        if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1) + x1:
            c = not c
    return c


def dist_seg(p, a, b):
    (px, py), (ax, ay), (bx, by) = p, a, b
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    t = 0 if L2 == 0 else max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / L2))
    return math.hypot(px - ax - t * dx, py - ay - t * dy)


def nettoyer(ring):
    """Retire le point de fermeture et les doublons."""
    out = []
    for p in ring:
        if not out or math.hypot(p[0] - out[-1][0], p[1] - out[-1][1]) > 0.01:
            out.append(p)
    if len(out) > 1 and math.hypot(out[0][0] - out[-1][0], out[0][1] - out[-1][1]) < 0.01:
        out.pop()
    return out


# ---------------------------------------------------------------- requêtes
def geocoder(adresse):
    d = get_json("https://api-adresse.data.gouv.fr/search/", {"q": adresse, "limit": 1})
    if not d["features"]:
        sys.exit("Adresse introuvable dans la Base Adresse Nationale.")
    f = d["features"][0]
    return f["geometry"]["coordinates"], f["properties"]


def parcelle_api_carto(args, point=None):
    base = "https://apicarto.ign.fr/api/cadastre/parcelle"
    if point:
        g = json.dumps({"type": "Point", "coordinates": point})
        d = get_json(base, {"geom": g})
    else:
        d = get_json(base, {"code_insee": args.insee, "section": args.section.upper(),
                            "numero": args.numero.zfill(4)})
    if not d["features"]:
        sys.exit("Aucune parcelle trouvée. Vérifie la référence cadastrale ou l'adresse.")
    return d["features"][0]


def wfs(typename, bbox4326):
    s, w, n, e = bbox4326
    return get_json("https://data.geopf.fr/wfs/ows", {
        "service": "WFS", "version": "2.0.0", "request": "GetFeature",
        "typeNames": typename, "outputFormat": "application/json",
        "srsName": "EPSG:2154", "count": 3000,
        "bbox": f"{s},{w},{n},{e},urn:ogc:def:crs:EPSG::4326"})


def gpu(couche, geom4326):
    try:
        return get_json(f"https://apicarto.ign.fr/api/gpu/{couche}",
                        {"geom": json.dumps(geom4326)})["features"]
    except Exception as exc:  # une couche absente ne doit pas tout arrêter
        return [{"erreur": str(exc)}]


def altitudes(lonlats):
    lons = "|".join(f"{p[0]:.7f}" for p in lonlats)
    lats = "|".join(f"{p[1]:.7f}" for p in lonlats)
    try:
        d = get_json("https://data.geopf.fr/altimetrie/1.0/calcul/alti/rest/elevation.json",
                     {"lon": lons, "lat": lats, "resource": "ign_rge_alti_wld", "zonly": "true"})
        return d["elevations"]
    except Exception:
        return []


# ---------------------------------------------------------------- principal
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--adresse")
    ap.add_argument("--insee")
    ap.add_argument("--section")
    ap.add_argument("--numero")
    ap.add_argument("--marge", type=float, default=70.0, help="contexte autour de la parcelle, en m")
    ap.add_argument("--sortie", default="site.json")
    args = ap.parse_args()

    adresse = None
    if args.adresse:
        pt, adresse = geocoder(args.adresse)
        cible = parcelle_api_carto(args, point=pt)
    elif args.insee and args.section and args.numero:
        cible = parcelle_api_carto(args)
    else:
        sys.exit("Donne --adresse ou --insee --section --numero.")
    idu = cible["properties"]["idu"]
    ring4326 = rings_of(cible["geometry"])[0]

    # emprise de recherche (degrés) autour de la parcelle
    lat0 = sum(p[1] for p in ring4326) / len(ring4326)
    dlat = args.marge / 111320.0
    dlon = args.marge / (111320.0 * math.cos(math.radians(lat0)))
    lons = [p[0] for p in ring4326]
    lats = [p[1] for p in ring4326]
    bbox = (min(lats) - dlat, min(lons) - dlon, max(lats) + dlat, max(lons) + dlon)

    parcelles = wfs("CADASTRALPARCELS.PARCELLAIRE_EXPRESS:parcelle", bbox)["features"]
    batiments = wfs("BDTOPO_V3:batiment", bbox)["features"]
    routes = wfs("BDTOPO_V3:troncon_de_route", bbox)["features"]

    cible93 = [f for f in parcelles if f["properties"].get("idu") == idu]
    if not cible93:
        sys.exit("Parcelle absente du WFS en Lambert 93 (décalage de millésime ?).")
    anneaux = rings_of(cible93[0]["geometry"])
    if len(anneaux) > 1:
        print("ATTENTION : parcelle en plusieurs morceaux ; seul le plus grand est étudié.")
    ring = max((nettoyer(r) for r in anneaux), key=lambda r: abs(aire(r)))
    if aire(ring) < 0:
        ring = ring[::-1]  # sens trigonométrique : l'extérieur est à droite de chaque arête
    ox, oy = centroide(ring)

    def loc(p):
        return [round(p[0] - ox, 3), round(p[1] - oy, 3)]

    voisins = []
    for f in parcelles:
        if f["properties"].get("idu") == idu:
            continue
        for r in rings_of(f["geometry"]):
            voisins.append((f["properties"].get("idu"), nettoyer(r)))

    lignes_routes = []
    for f in routes:
        g = f["geometry"]
        parts = [g["coordinates"]] if g["type"] == "LineString" else g["coordinates"]
        pr = f["properties"]
        nom = pr.get("nom_voie_ban_gauche") or pr.get("nom_collaboratif_gauche") or ""
        for part in parts:
            lignes_routes.append({"pts": [(p[0], p[1]) for p in part], "nom": nom,
                                  "largeur": pr.get("largeur_de_chaussee"),
                                  "prive": pr.get("prive"), "nature": pr.get("nature")})

    def route_proche(p):
        best = (1e9, None)
        for r in lignes_routes:
            for a, b in zip(r["pts"], r["pts"][1:]):
                d = dist_seg(p, a, b)
                if d < best[0]:
                    best = (d, r)
        return best

    # --- classement de chaque arête : voisine d'une autre parcelle, ou bord du domaine public
    aretes = []
    n = len(ring)
    for i in range(n):
        a, b = ring[i], ring[(i + 1) % n]
        L = math.hypot(b[0] - a[0], b[1] - a[1])
        mx, my = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
        nx, ny = (b[1] - a[1]) / L, -(b[0] - a[0]) / L  # normale extérieure (anneau trigonométrique)
        sondes = {}
        for d in (1.0, 3.0):
            p = (mx + nx * d, my + ny * d)
            sondes[d] = next((iv for iv, r in voisins if dedans(p, r)), None)
        dr, r = route_proche((mx + nx * 1.0, my + ny * 1.0))
        emprise_voie = None
        if sondes[1.0] is None and sondes[3.0] is None:
            typ = "voie"
            # largeur du domaine public en face : on avance jusqu'à la première parcelle d'en face
            d = 1.0
            while d <= 60:
                p = (mx + nx * d, my + ny * d)
                if any(dedans(p, rr) for _, rr in voisins):
                    emprise_voie = round(d, 1)
                    break
                d += 0.5
        elif sondes[1.0] is None or sondes[3.0] is None:
            typ = "a_verifier"
        else:
            typ = "separative"
        aretes.append({"a": a, "b": b, "longueur": L, "type": typ,
                       "voisin": sondes[1.0] or sondes[3.0],
                       "route": r["nom"] if r else None, "dist_route": round(dr, 1),
                       "largeur_chaussee": r["largeur"] if r else None,
                       "route_privee": r["prive"] if r else None,
                       "emprise_voie_m": emprise_voie})

    # arêtes minuscules : elles prennent le type de la voisine la plus longue
    for i, e in enumerate(aretes):
        if e["longueur"] < 0.6:
            av, ap_ = aretes[i - 1], aretes[(i + 1) % n]
            e["type"] = (av if av["longueur"] >= ap_["longueur"] else ap_)["type"]

    # --- regroupement en côtés
    def cle(e):
        return (e["type"], e["voisin"] if e["type"] == "separative" else e["route"])

    depart = next((i for i in range(n) if cle(aretes[i]) != cle(aretes[i - 1])), 0)
    cotes = []
    for k in range(n):
        e = aretes[(depart + k) % n]
        if cotes and cle(cotes[-1]["_e"][-1]) == cle(e):
            cotes[-1]["_e"].append(e)
        else:
            cotes.append({"_e": [e]})
    # côtés séparatifs consécutifs (plusieurs voisins) : on garde un côté par voisin
    for c in cotes:
        es = c.pop("_e")
        c["type"] = es[0]["type"]
        c["segments"] = [loc(e["a"]) + loc(e["b"]) for e in es]
        c["longueur"] = round(sum(e["longueur"] for e in es), 2)
        c["voisin"] = es[0]["voisin"]
        c["route"] = es[0]["route"]
        c["dist_route"] = min(e["dist_route"] for e in es)
        c["largeur_chaussee"] = es[0]["largeur_chaussee"]
        c["route_privee"] = es[0]["route_privee"]
        larg = [e["emprise_voie_m"] for e in es if e.get("emprise_voie_m")]
        c["emprise_voie_m"] = min(larg) if larg else None  # largeur entre alignements, mesurée au milieu de chaque arête

    # latérale ou fond : une limite séparative qui touche un côté sur voie est latérale
    nc = len(cotes)
    for i, c in enumerate(cotes):
        if c["type"] != "separative":
            continue
        touche_voie = cotes[i - 1]["type"] == "voie" or cotes[(i + 1) % nc]["type"] == "voie"
        c["role"] = "laterale" if touche_voie else "fond"
    for i, c in enumerate(cotes):
        c["id"] = f"{c['type'] if c['type'] != 'separative' else c['role']}_{i + 1}"

    # --- bâtiments (BD TOPO) : hauteur mesurée par l'IGN, à vérifier sur place
    bats = []
    for f in batiments:
        pr = f["properties"]
        for r in rings_of(f["geometry"]):
            r = [loc(p) for p in nettoyer(r)]  # repère local : en Lambert 93 brut, le centroïde perd sa précision
            c = centroide(r) if abs(aire(r)) > 0.5 else r[0]
            bats.append({"poly": r, "hauteur": pr.get("hauteur"),
                         "etages": pr.get("nombre_d_etages"), "usage": pr.get("usage_1"),
                         "leger": pr.get("construction_legere"),
                         "sur_parcelle": dedans(c, [loc(p) for p in ring])})

    # --- zonage, prescriptions, servitudes (Géoportail de l'urbanisme)
    geom_parcelle = {"type": "Polygon", "coordinates": [[list(p) for p in ring4326]]}
    zones = []
    for f in gpu("zone-urba", geom_parcelle):
        if "erreur" in f:
            zones.append(f)
            continue
        pr = f["properties"]
        url = pr.get("urlfic") or (
            f"https://data.geopf.fr/annexes/gpu/documents/{pr['partition']}/{pr['gpu_doc_id']}/{pr['nomfic']}"
            if pr.get("nomfic") else None)
        zones.append({"libelle": pr.get("libelle"), "libelle_long": pr.get("libelong"),
                      "type": pr.get("typezone"), "document": pr.get("idurba"),
                      "date_validation": pr.get("datvalid"), "reglement_pdf": url})
    autres = {}
    for couche in ("prescription-surf", "prescription-lin", "prescription-pct",
                   "info-surf", "info-lin", "info-pct",
                   "assiette-sup-s", "assiette-sup-l", "assiette-sup-p"):
        lst = []
        for f in gpu(couche, geom_parcelle):
            if "erreur" in f:
                lst.append(f)
                continue
            pr = f["properties"]
            lst.append({k: pr.get(k) for k in ("libelle", "txt", "typepsc", "stypepsc", "typeinf",
                                               "suptype", "nomsuplitt", "nomass", "idgen") if pr.get(k)})
        if lst:
            autres[couche] = lst

    alts = altitudes(ring4326[:-1][:60])

    site = {
        "genere_le": datetime.datetime.now().isoformat(timespec="minutes"),
        "sources": {
            "cadastre": "IGN Parcellaire Express (WFS data.geopf.fr) + API Carto cadastre",
            "batiments_routes": "IGN BD TOPO V3 (WFS data.geopf.fr)",
            "urbanisme": "Géoportail de l'urbanisme via API Carto GPU",
            "altimetrie": "IGN RGE ALTI (data.geopf.fr/altimetrie)",
        },
        "adresse_geocodee": adresse.get("label") if adresse else None,
        "parcelle": {
            "idu": idu, "commune": cible["properties"].get("nom_com"),
            "insee": cible["properties"].get("code_insee"),
            "section": cible["properties"].get("section"), "numero": cible["properties"].get("numero"),
            "contenance_cadastrale_m2": cible["properties"].get("contenance"),
            "surface_calculee_m2": round(abs(aire(ring)), 1),
            "polygone": [loc(p) for p in ring],
        },
        "origine_lambert93": [round(ox, 2), round(oy, 2)],
        "cotes": cotes,
        "voisins": [{"idu": iv, "poly": [loc(p) for p in r]} for iv, r in voisins],
        "batiments": bats,
        "routes": [{"pts": [loc(p) for p in r["pts"]], "nom": r["nom"], "largeur": r["largeur"]}
                   for r in lignes_routes],
        "zones": zones,
        "prescriptions_et_servitudes": autres,
        "altitudes_sommets_m": alts,
        "denivele_m": round(max(alts) - min(alts), 2) if alts else None,
    }
    with open(args.sortie, "w", encoding="utf-8") as fo:
        json.dump(site, fo, ensure_ascii=False, indent=1)

    # résumé lisible
    p = site["parcelle"]
    print(f"Parcelle {p['insee']} {p['section']} {p['numero']} ({p['commune']}) : "
          f"{p['surface_calculee_m2']} m² calculés, {p['contenance_cadastrale_m2']} m² au cadastre")
    for z in zones:
        print("Zone :", z)
    for c in cotes:
        extra = (f" -> {c['route']} (axe à {c['dist_route']} m ; emprise de la voie ≈ {c['emprise_voie_m']} m)"
                 if c["type"] == "voie" else "")
        print(f"  côté {c['id']:<14} {c['longueur']:>6} m{extra}")
    print("Bâtiments sur la parcelle :", sum(b["sur_parcelle"] for b in bats))
    print("Dénivelé entre sommets :", site["denivele_m"], "m")
    for k, v in autres.items():
        print("  ", k, ":", v)


if __name__ == "__main__":
    main()
