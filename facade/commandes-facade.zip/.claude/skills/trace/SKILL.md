---
name: trace
description: Trame et proportions : les axes des travées, les niveaux et les rapports.
argument-hint: "[photo de la façade]"
disable-model-invocation: true
---

Fais le dessin de la trame et des proportions de cette façade : l'élévation au trait en gris clair, et par-dessus, en rouge, les axes de chaque travée et les lignes des niveaux, en bleu les cotes (largeur des travées, hauteur de chaque étage, hauteur et largeur d'une baie type par niveau). Calcule vraiment les rapports hauteur sur largeur des baies de chaque étage et écris-les à côté (par exemple 2,1), et montre en un trait la décroissance des hauteurs d'étage du bas vers le haut si elle existe. Une petite légende des couleurs. Vidéo : les axes tombent, puis les niveaux, puis les cotes et les rapports s'écrivent.

Photo donnée : $ARGUMENTS (s'il n'y a rien, prends la photo de façade du dossier courant).

Commence toujours comme ça :
1. Ouvre la photo et regarde-la vraiment : nombre de travées et de niveaux, baies, balcons, garde-corps, corniches, bandeaux, toiture et lucarnes, rez-de-chaussée.
2. Si `facade.json` existe déjà, réutilise-le. Sinon : si les verticales convergent, redresse la photo (repère les 4 coins de la façade, homographie avec numpy et Pillow) et enregistre `facade-redressee.jpg`. Relève ensuite, sur l'image redressée, en pixels puis en mètres : les axes des travées, les niveaux (planchers, appuis, linteaux), chaque baie, chaque balcon et garde-corps, les corniches et bandeaux, la toiture et ses lucarnes, les boutiques du rez-de-chaussée. Sans cote sur la photo, choisis une mesure de référence plausible (hauteur d'une baie ou d'un étage) et écris qu'elle est supposée. Écris `facade.json` avec ce relevé et ce que tu n'as pas pu lire.
3. Vérifie ta lecture avant de dessiner : superpose ton relevé en traits rouges fins sur la photo redressée (`controle.png`), regarde-le et corrige `facade.json` tant que les baies et les niveaux ne tombent pas sur la photo.

Dessine ensuite en code, avec un script Python (matplotlib, numpy, Pillow ; installe ce qui manque avec pip, et ffmpeg sert à la vidéo). Aucun générateur d'images : tout se calcule depuis `facade.json`.

Ce que tu rends, dans le dossier courant :
- `trace.png` : le dessin final, 1080 × 1920 en portrait, sans marge perdue. Cadre la façade pour qu'elle occupe au moins 85 % de la largeur et se lise sur un téléphone ; la place libre au-dessus et en dessous sert au ciel, au trottoir ou à la légende, jamais à du vide. Trait net, niveau d'un rendu d'école d'architecture ou d'agence, jamais un graphique de tableur. Pas de titre géant : un petit cartouche discret (nom du dessin, échelle graphique).
- `trace.mp4` : 3 s, 1080 × 1920, 30 i/s, H.264, yuv420p, où le dessin se construit sous les yeux et se termine sur l'image finale tenue les 20 dernières images. La première image n'est jamais vide.

Ouvre le PNG pour le regarder, et corrige s'il y a du texte coupé ou qui se chevauche. Termine en disant en quelques lignes ce que le dessin montre, ce que tu as lu sur la photo et ce que tu as supposé parce qu'elle ne le dit pas. N'invente rien sans le dire.
