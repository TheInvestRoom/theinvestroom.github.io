---
name: pleins
description: Les pleins et les vides de la façade.
argument-hint: "[photo de la façade]"
disable-model-invocation: true
---

Fais le dessin des pleins et des vides de la façade principale : la façade redressée en noir pour le mur et blanc pour chaque ouverture (baies, vitrines, lucarnes), la trame des travées en traits fins rouges cotée, et à droite de chaque niveau une barre qui donne sa part d'ouverture. Les surfaces viennent de `facade.json` (dimension de chaque baie multipliée par leur nombre), pas d'une estimation à l'œil. En grand : la part d'ouverture de toute la façade en pour cent, et celle du rez-de-chaussée comparée à celle des étages.

Photo donnée : $ARGUMENTS (s'il n'y a rien, prends la photo de façade du dossier courant).

Commence toujours comme ça :
1. Ouvre la photo et regarde-la vraiment : l'immeuble entier, du trottoir au faîtage, ses façades visibles (une ou deux si c'est un angle), le nombre de niveaux (rez-de-chaussée, entresol, étages, combles), les travées de fenêtres, les balcons filants ou isolés, les corniches et bandeaux, la toiture (zinc, ardoise, lucarnes, souches de cheminée), les devantures et auvents du rez-de-chaussée, les matériaux.
2. Si `facade.json` existe déjà, réutilise-le tel quel et ne le refais pas. Sinon, relève la façade principale (la plus large visible) par la perspective : redresse-la (homographie sur les quatre coins de la façade), compte les travées et les niveaux, puis déduis en mètres la largeur de la façade, la hauteur de chaque niveau, la hauteur à l'égout et au faîtage, la largeur et la hauteur des baies, la position des balcons. Prends des dimensions plausibles quand la photo ne les donne pas (3,0 à 3,3 m pour un étage courant, 4 à 5 m pour un rez-de-chaussée avec entresol, 1,1 à 1,3 m de largeur de fenêtre) et écris qu'elles sont supposées. Si tu reconnais le lieu, dis-le en l'écrivant comme une hypothèse. Écris `facade.json` avec ce relevé et ce que tu n'as pas pu lire.
3. Vérifie ta lecture avant de dessiner : reprojette ton relevé en traits rouges fins sur la photo (`controle.png`), regarde-le et corrige `facade.json` tant que les niveaux, les travées et l'égout ne tombent pas sur la photo.

Dessine ensuite en code, avec un script Python (matplotlib, numpy, Pillow, OpenCV si utile ; installe ce qui manque avec pip, et ffmpeg sert à la vidéo). Aucun générateur d'images : tout se calcule depuis `facade.json` et les pixels de la photo.

Ce que tu rends, dans le dossier courant :
- `pleins.png` : le dessin final, 1080 × 1920 en portrait, sans marge perdue. Le dessin occupe au moins 85 % de la largeur et se lit sur un téléphone : traits assez épais, textes d'au moins 26 px, couleurs franches. La place libre sert à la légende, jamais à du vide. Niveau d'un rendu d'école d'architecture ou d'agence, jamais un graphique de tableur. Pas de titre géant : un petit cartouche discret (nom du dessin, échelle graphique).
- `pleins.mp4` : 3 s, 1080 × 1920, 30 i/s, H.264, yuv420p, où le dessin se construit sous les yeux (le mur se remplit en noir, les baies se découpent travée par travée, puis les barres de chaque niveau poussent et le chiffre total arrive) et se termine sur l'image finale tenue les 20 dernières images. La première image n'est jamais vide.

Ouvre le PNG pour le regarder, et corrige s'il y a du texte coupé ou qui se chevauche, ou un dessin trop petit. Termine en disant en quelques lignes ce que le dessin montre, ce que tu as lu sur la photo et ce que tu as supposé parce qu'elle ne le dit pas. N'invente rien sans le dire.
