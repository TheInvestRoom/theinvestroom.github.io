# diagrammes-parti

Tu décris ton parti en quelques phrases ; Claude dessine la séquence de diagrammes de concept : le volume de
départ, puis un geste par image (creuser, soulever, décaler, gradins, pente, biseau, cour, passage), même vue,
même échelle, la couleur sur ce qui change et une flèche de geste.

Sorties : `planche.svg` (modifiable dans Illustrator ou Inkscape), `sequence.png` et `geste-NN.png`
(1080 × 1920), `parti.mp4` (les gestes qui s'enchaînent), `animation.html` (plein écran pour un jury).

## Installer

**Claude Code** : copie le dossier `diagrammes-parti` dans `~/.claude/skills/` (pour toi) ou dans
`.claude/skills/` à la racine de ton projet. Puis tape :

```
/diagrammes-parti "Médiathèque sur une parcelle d'angle de 42 × 30 m, trois niveaux. On creuse l'angle sud-est
pour un parvis tourné vers la place, on évide un patio au centre, la toiture descend en gradins vers la place."
```

Tu peux aussi le demander en phrase normale (« fais-moi les diagrammes de parti de… ») : Claude charge le skill
tout seul.

**Claude.ai** (avec l'exécution de code activée) : compresse le dossier `diagrammes-parti` en `.zip`, puis
Paramètres → Capacités → Skills → importer le zip. Demande ensuite tes diagrammes dans une conversation.

## Ce qu'il faut sur la machine

- Python 3 (rien d'autre pour le SVG et le HTML) ;
- Pillow pour les PNG : `pip install pillow` ;
- ffmpeg pour la vidéo.

S'il en manque un, le script le dit et produit le reste.

## À savoir

- Formes orthogonales sur une trame, plus des pentes et des coupes en biais : pas de courbes ni de volumes tournés.
- Les dimensions que tu ne donnes pas sont supposées, et Claude te dit lesquelles.
- C'est un diagramme qui explique une forme, pas une étude de faisabilité.
- Garde le `projet.json` : c'est lui qu'on modifie pour tester une variante.
