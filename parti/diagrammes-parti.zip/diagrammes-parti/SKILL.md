---
name: diagrammes-parti
description: Dessine les diagrammes de concept (parti) d'un projet d'architecture en séquence, à la manière des diagrammes BIG — volume de départ, puis un geste par vignette (creuser, soulever, décaler, tailler en pente, gradins, biseau, cour, passage, toit), en axonométrie, avec la seule couleur sur ce qui change et une flèche de geste. Part d'une description en mots (quelques phrases, des dimensions approximatives), pas d'un modèle 3D. Sort une planche SVG modifiable, des images 1080x1920, une vidéo MP4 et une page HTML animée. À utiliser quand quelqu'un décrit son parti, son concept ou l'évolution de sa forme et veut des diagrammes de parti, de massing ou de concept, une séquence « de la boîte au projet », ou prépare une planche de rendu, un jury ou une soutenance.
argument-hint: "\"<ton parti en quelques phrases, avec des dimensions approximatives>\""
---

# Diagrammes de parti en séquence

Description reçue : $ARGUMENTS (si elle est vide, demande le parti en trois ou quatre phrases : le site, le
volume de départ, les gestes et leur raison).

## L'idée qui fait marcher ce skill

Ne dessine pas les diagrammes à main levée en SVG. Un modèle de langage place mal des sommets en
perspective : faces qui passent devant ce qu'elles cachent, échelles qui changent d'une vignette à l'autre,
point de vue qui dérive. Il raisonne bien, en revanche, sur des **volumes et des verbes** : « on part d'un
bloc de 36 × 24 m sur trois niveaux, on creuse l'angle sud-est au rez ». Donc tu traduis le parti en une
suite d'**opérations** sur des boîtes (un fichier JSON), et le moteur `scripts/parti.py` calcule la
géométrie, les faces cachées, l'échelle commune, les couleurs, les flèches et les sorties. Ton travail est
celui d'un architecte qui prépare ses diagrammes, pas celui d'un dessinateur : trouver les gestes, leur
ordre, leurs dimensions et leur nom.

Format des opérations, avec un exemple complet : `references/operations.md`. À lire avant d'écrire le JSON.

## 1. Lire le parti et trouver les gestes

Un diagramme de parti raconte **pourquoi** la forme est ce qu'elle est. Chaque vignette = un geste = une
raison (le site, le programme, la lumière, la vue, l'usage). Cherche dans la description les verbes et les
raisons, pas seulement les formes :

| La description dit… | Geste | Opération |
|---|---|---|
| « un bloc qui remplit la parcelle », « le gabarit » | volume de départ | `volume` |
| « on ouvre un parvis à l'angle », « un porche », « une loggia » | creuser | `creuser` |
| « le bâtiment se soulève », « sur pilotis », « libérer le sol » | soulever | `soulever` + `poteaux` |
| « l'étage glisse vers la vue », « en porte-à-faux », « décalé » | décaler | `decaler` |
| « une cour », « un patio », « un puits de lumière » | évider | `creuser` (toute la hauteur) |
| « un passage traversant », « une faille » | percer | `creuser` (au rez, d'une façade à l'autre) |
| « le toit descend vers le jardin », « la toiture devient une pente » | incliner | `pente` |
| « en gradins », « des terrasses qui descendent » | terrasser | `gradins` |
| « on biseaute l'angle », « la façade suit la rue en biais » | tailler | `couper` |
| « un toit à deux pans » | couvrir | `toit` |
| « un second volume », « on ajoute une tour » | ajouter | `volume` |

**Pourquoi un geste par vignette.** L'œil compare une vignette à la précédente. S'il y a deux changements, il
ne sait pas lequel porte l'intention, et la séquence devient une suite d'états au lieu d'un raisonnement.
Exception : un geste qui se fait en deux opérations (soulever + poser des poteaux) reste une seule vignette.

**Combien de gestes.** Le plus souvent 4 à 6 vignettes, volume de départ compris. En dessous de 3 il n'y a pas
de récit ; au-delà de 7, le geste fondateur se perd dans les détails. Si la description en contient plus,
regroupe les petits gestes ou garde-les pour un second diagramme, et dis-le.

**L'ordre.** Du plus grand au plus fin : enveloppe → gestes qui répondent au site (vue, rue, soleil) →
gestes qui répondent au programme (cour, passage) → toiture et finitions. Un geste qui dépend d'un autre vient
après lui (on ne décale pas un étage qui n'existe pas encore).

**Le texte nomme l'intention, pas l'opération.** Titre court (1 à 3 mots) et sous-titre d'une ligne : « Ouvrir
sur la place » / « l'angle se creuse sur deux niveaux », pas « Soustraction 9 × 9 m ». Le dessin montre déjà
l'opération ; le texte dit ce qu'on gagne. Exception admise : le premier titre peut décrire le volume brut
(« Le gabarit », « Une boîte »). Vise un sous-titre de 40 caractères au plus : au-delà il passe sur deux
lignes dans la séquence, puis il est coupé ; sur un diagramme, une phrase longue n'est pas lue.

## 2. Les dimensions et la trame

Le moteur découpe le volume en cellules sur une **trame** (`module` : pas en plan, pas en hauteur). Tout ce que
tu décris est arrondi à cette trame (une boîte prend les cellules dont le centre est dedans).

- **Choisis un pas en plan qui divise les cotes importantes.** Un retrait de 1,5 m disparaît avec un pas de 3 m ;
  un pilotis fin ou une fenêtre en bandeau demande un pas de 1 m. Plus le pas est fin, plus le calcul est
  long ; un pas de 1 m tient encore pour un bâtiment de quelques milliers de m².
- **Le pas en hauteur suit la hauteur d'étage** quand les gestes se font par niveaux (3 à 4 m selon le
  programme, à prendre dans la description). Prends une fraction d'étage s'il faut un geste plus fin
  (bandeau, acrotère, rez plus haut).
- **Dimensions absentes** : prends une hypothèse plausible pour le programme et **écris-la** à l'utilisateur
  (« j'ai supposé 3,5 m par niveau »). Aucun chiffre ne doit sortir de nulle part sans être signalé.
- Repère : `x` vers l'est, `y` vers le nord, `z` vers le haut, en mètres ; une boîte s'écrit
  `[x, y, z, largeur selon x, profondeur selon y, hauteur]`, depuis son coin sud-ouest bas. Place l'origine au
  coin sud-ouest de la parcelle : les coordonnées restent positives et lisibles.

## 3. Le point de vue : un seul, celui qui montre les gestes

Toutes les vignettes ont la même vue et la même échelle : c'est ce qui permet de lire le changement d'une
image à l'autre. Une vignette recadrée ou tournée oblige l'œil à se réorienter et casse la comparaison.

La vue est le coin d'où l'on regarde : `sud-est` (par défaut), `sud-ouest`, `nord-est`, `nord-ouest`, ou
`auto`. On voit les deux façades de ce coin et le toit. **Choisis le coin d'où les gestes importants se voient** :
un parvis creusé à l'angle sud-est est invisible depuis le nord-ouest. Le script mesure, pour chaque geste et
chaque vue, la part du dessin qui est en couleur, et le note dans `controle.txt` ; `"vue": "auto"` prend la vue
où le geste le moins visible l'est le plus. Garde la main si un geste compte plus que les autres : c'est lui qui
doit se voir.

**Un geste caché depuis toutes les vues** (un rez en retrait sous une boîte soulevée, une salle sous un toit) :
l'axonométrie ne peut pas le montrer tel quel, ce n'est pas un défaut du moteur. Éclate la vignette
(`"eclater"` : la partie qui couvre est soulevée pour cette image seulement, comme dans une axonométrie
éclatée), ou présente ce geste avant celui qui le cache.

## 4. Le style, et pourquoi il est réglé ainsi

Le moteur applique ces règles ; ne les combats pas dans le JSON.

- **Une seule couleur, sur ce qui change à cette étape.** Le reste est en trois valeurs de gris selon
  l'orientation des faces (toit clair, façades plus sombres). La couleur dit « regarde ici » ; si deux choses
  sont en couleur, rien n'est désigné. La première vignette est grise : rien n'a encore changé.
- **Ce qu'on retire reste visible en fantôme** (voile coloré, contour en tirets), et un volume creusé est
  montré **sorti de son trou** dans la direction où il s'ouvre : on voit à la fois le vide et ce qui l'a créé.
  Un volume déplacé laisse son ancienne place en fantôme.
- **Une flèche de geste** par vignette, calculée depuis l'opération (vers le haut pour soulever, le long de la
  pente, du trou vers le volume extrait). Remplace-la (`"fleche"`) seulement si elle raconte mal le geste ;
  supprime-la (`"fleche": false`) si le geste se lit sans.
- **Le contexte en trait fin et blanc** (`contexte`, `parcelle`) : juste assez pour comprendre pourquoi le geste
  existe (la rue, la place, le voisin haut). Un contexte détaillé vole l'attention au projet.
- **On ne trace que les arêtes utiles** : le bâtiment se lit comme un bloc, pas comme une pile de cellules.
- **Une annotation au sol** (`vue`) pour la raison extérieure du geste : « place », « parc », « Seine ». Une ou
  deux par séquence, là où le geste y répond.

## 5. Produire

```
python scripts/parti.py projet.json --sortie diagrammes/
```

Python 3 standard pour le SVG et le HTML ; **Pillow** (`pip install pillow`) pour les PNG ; **ffmpeg** pour la
vidéo. S'il en manque un, le script le dit et produit le reste. Sorties :

- `planche.svg` : toute la séquence, même vue, même échelle, prête à ouvrir dans Illustrator ou Inkscape ;
- `sequence.png` (1080 × 1920) : la séquence en portrait ;
- `geste-NN.png` (1080 × 1920) : chaque geste en grand, avec son numéro et son intention ;
- `parti.mp4` : les gestes qui s'enchaînent (le volume arrive, sort de son trou ou glisse, puis la flèche se trace) ;
- `animation.html` : la même chose en plein écran pour un jury (flèches du clavier, espace = pause ;
  `?etape=3` fige une étape) ;
- `etapes/etape-NN.svg` : chaque vignette seule, pour la composer soi-même sur une planche ;
- `controle.txt` : ce que chaque opération a réellement touché.

## 6. Vérifier avant de montrer

Le moteur ne se trompe pas en géométrie ; il exécute fidèlement un JSON qui peut, lui, être faux. Deux
contrôles, dans cet ordre :

1. **Lis `controle.txt`.** Chaque ligne `ATTENTION` est une opération qui n'a pas fait ce que tu croyais :
   une boîte qui ne touche aucune cellule (coordonnées hors du volume, ou boîte plus petite que la trame), une
   pente qui ne coupe rien (hauteurs au-dessus du volume), un volume déplacé qui arrive sur un autre (fusion),
   un geste qui se voit à peine depuis la vue choisie (moins de 2 % du dessin en couleur, seuil d'essai) ou
   depuis aucune vue. Ce contrôle compte la couleur : il sous-estime un vide étroit (un passage se lit par
   l'absence de matière) ; dans ce cas, c'est l'image qui tranche. Compare aussi la hauteur et l'emprise
   affichées à la description.
2. **Regarde les PNG** (ou une capture du SVG). Pour chaque vignette : le geste se voit-il depuis cette vue ?
   La flèche montre-t-elle le bon sens ? Le titre dit-il une intention ? Un geste qui ne se voit pas se corrige
   en changeant de vue ou en agrandissant le geste (une cour de 3 m dans un bloc de 60 m est un détail, pas
   un geste).

Corrige le JSON et relance tant qu'une vignette ne raconte pas son geste. Garde le JSON : c'est lui qu'on modifie
pour la variante suivante (« et si la cour était décalée vers le nord ? »).

## 7. Ce que tu dis à la fin

En quelques lignes : la séquence (numéro, intention), les dimensions que tu as **supposées**, les gestes de
la description que tu as simplifiés ou laissés de côté et pourquoi, et où sont les fichiers. Ne présente pas un
diagramme comme un projet vérifié : c'est une explication de la forme, pas une étude de faisabilité.

## Limites (à dire si la description en dépend)

- Formes orthogonales sur une trame, plus des plans inclinés (`pente`, `toit`) et des coupes verticales en biais
  (`couper`). Pas de courbes, pas de volume tourné à 45° (approcher par `couper`), pas de torsion.
- Une `pente` monte ou descend selon un axe (est-ouest ou nord-sud), pas en diagonale.
- Pas de matériaux, d'ombres portées ni de personnages : c'est un diagramme, pas un rendu.
- Vue axonométrique isométrique uniquement (pas de perspective).
