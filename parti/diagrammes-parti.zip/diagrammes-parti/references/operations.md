# Format du fichier projet (JSON) et opérations

Repère : `x` vers l'est, `y` vers le nord, `z` vers le haut, en mètres. Une **boîte** s'écrit
`[x, y, z, largeur selon x, profondeur selon y, hauteur]` à partir de son coin sud-ouest bas. Une boîte
d'opération prend les **cellules de la trame dont le centre est dedans** : pour viser un étage entier, donne
toute sa hauteur ; pour viser une façade, donne une boîte qui la déborde un peu plutôt qu'une boîte qui
s'arrête pile sur la limite (un centre exactement sur le bord ne compte pas).

## Le projet

```json
{
  "titre": "Maison des jeunes, rue des Tanneurs",
  "module": [3, 3.5],
  "vue": "sud-est",
  "parcelle": [[0,0],[24,0],[24,60],[0,60]],
  "contexte": [ {"box": [-14, 0, 0, 12, 60, 18]} ],
  "etapes": [ … ]
}
```

| Clé | Rôle | Pourquoi / quand ça casse |
|---|---|---|
| `module` | `[pas en plan, pas en hauteur]` | Tout est arrondi à cette trame. Un geste plus petit que le pas disparaît (le contrôle le signale). |
| `vue` | `sud-est`, `sud-ouest`, `nord-est`, `nord-ouest`, `auto` | Coin d'où l'on regarde ; on voit ses deux façades et le toit. Un geste sur les façades opposées est caché. `auto` prend la vue où le geste le moins visible l'est le plus (demande Pillow). |
| `parcelle` | polygone au sol `[[x,y], …]` | Assoit le bâtiment ; trait fin en tirets. Facultatif mais aide beaucoup à lire les retraits. |
| `contexte` | boîtes blanches au trait fin | Voisins, mur mitoyen, tour voisine : seulement ce qui explique un geste. |
| `colonnes` | nombre de colonnes de `planche.svg` | Par défaut 2 jusqu'à 4 étapes, 3 au-delà. |
| `duree_etape_video` | secondes par geste dans `parti.mp4` | Par défaut entre 0,8 et 1,6 s selon le nombre de gestes (vidéo d'environ 6 s). |
| `duree_etape` | secondes par geste dans `animation.html` | Par défaut 2,4 s, le temps de lire le titre. |

## Une étape

```json
{ "titre": "Ouvrir sur la place", "texte": "l'angle se creuse sur deux niveaux",
  "ops": [ … ], "fleche": {"de": [30,3,5], "vers": [40,-6,5]}, "accent": true }
```

- `titre` : 1 à 3 mots, une intention. `texte` : une ligne, ce qu'on gagne ou comment.
- `ops` : une ou plusieurs opérations, appliquées dans l'ordre. Toutes les cellules touchées par l'étape sont
  en couleur.
- `fleche` : facultatif. `false` pour aucune flèche ; `{"de": [x,y,z], "vers": [x,y,z]}` pour la remplacer.
- `accent` : facultatif. Par défaut, la première étape est grise et les suivantes colorent ce qui change.
- `eclater` : facultatif. `{"box": [x, y, z, l, p, h], "de": 5}` soulève de `de` m les cellules de la boîte,
  **pour cette vignette seulement** (le modèle ne change pas pour les étapes suivantes). Sert quand le geste est
  caché par ce qui est au-dessus : un rez en retrait sous un volume soulevé, un patio couvert, une salle sous
  un toit. Le contrôle le propose quand un geste ne se voit depuis aucune vue.

Ce qui change à l'étape est coloré de deux façons : les volumes ajoutés ou déplacés en entier, et les
**surfaces mises à nu** par un retrait (parois d'une cour, sol d'un parvis, dessus des gradins).

## Les opérations

### `volume` : ajouter une boîte
`{"op": "volume", "box": [0, 0, 0, 36, 24, 10.5]}`
Le volume de départ, ou un volume ajouté (une tour, une aile). Dans l'animation, il arrive d'en haut.

### `creuser` : retirer une boîte
`{"op": "creuser", "box": [27, 0, 0, 9, 9, 7]}`
Parvis, porche, loggia, cour (toute la hauteur), passage traversant (au rez, d'une façade à l'autre).
Le volume retiré est montré **sorti de son trou** du côté où il s'ouvre (le haut s'il est à ciel ouvert, sinon
la façade libre), avec une flèche. `"extraire": false` le laisse en fantôme à sa place (utile si le volume sorti
sortirait du cadre ou masquerait un autre geste).
Casse quand : la boîte ne touche rien (coordonnées hors du bâtiment) ; la boîte est plus petite que le pas.

### `soulever` : monter une partie
`{"op": "soulever", "box": [0, 0, 0, 21, 19, 3.5], "de": 3.5}`
Libérer le sol, faire passer la rue dessous. `de` est la hauteur (arrondie au pas en hauteur). L'ancienne place
reste en fantôme. Ajoute des `poteaux` dans la même étape si le volume ne tient pas visiblement.

### `decaler` : glisser une partie
`{"op": "decaler", "box": [0, 0, 7, 36, 24, 3.5], "de": [6, 0, 0]}`
Porte-à-faux vers une vue, étages qui glissent les uns sur les autres. `de` = `[dx, dy, dz]` en mètres,
arrondi à la trame. Casse quand le volume déplacé arrive sur un autre (le contrôle dit « fusion »).

### `poteaux` : des pilotis
`{"op": "poteaux", "points": [[1,1],[10,1],[20,1]], "a_z": 3.5, "section": 0.4, "de_z": 0}`
Poteaux carrés fins sous un volume soulevé ou un porte-à-faux. Ils ne remplissent que les cellules vides.

### `pente` : tailler un plan incliné
`{"op": "pente", "box": [0, 12, 0, 36, 12, 10.5], "sens": "nord", "hauts": [10.5, 3.5]}`
Coupe tout ce qui est au-dessus d'un plan qui va de la hauteur `hauts[0]` (côté de départ) à `hauts[1]` (côté
d'arrivée), dans la direction `sens` (`est`, `ouest`, `nord`, `sud`, ou `+x`, `-x`, `+y`, `-y`). Toiture qui
descend vers un jardin, rampe habitée, toit accessible. Les cellules coupées sont en couleur : c'est la nouvelle
surface. Casse quand les deux hauteurs sont au-dessus du volume (rien n'est coupé) ; une pente qui descend vers
l'arrière (par rapport à la vue) se voit mal.

### `gradins` : terrasser en marches
`{"op": "gradins", "box": [0, 0, 0, 36, 24, 14], "sens": "sud", "marche": [6, 3.5]}`
Chaque marche fait `marche[0]` m de profondeur dans le `sens` donné et descend de `marche[1]` m. La première
marche garde toute la hauteur de la boîte (`"premiere_marche_pleine": false` pour commencer plus bas).
Terrasses-jardins, gradins tournés vers le soleil, logements en cascade. Le `sens` est celui où l'on descend.

### `couper` : un biais vertical
`{"op": "couper", "ligne": [[24, 0], [36, 10]], "retirer": "droite", "box": [0, 0, 0, 36, 24, 14]}`
Coupe verticale selon une ligne en plan. `retirer` : `gauche` ou `droite`, vu en marchant de la première vers
la seconde extrémité de la ligne. `box` limite la coupe à une partie (sinon tout le bâtiment). Façade qui suit
une rue en biais, angle biseauté pour ouvrir un parvis.

### `toit` : un toit à deux pans
`{"op": "toit", "box": [0, 0, 10.5, 36, 12, 0], "faitage": "x", "hauteur": 4}`
Ajoute un toit au-dessus de la boîte (sa hauteur dans `box` n'est pas utilisée), faîtage parallèle à `x` ou à
`y`, haut de `hauteur` m. La pente se déduit de la largeur ; avec une trame grossière le toit est en marches :
prends un pas en hauteur plus fin si le toit est un geste important.

### `vue` : une annotation au sol
`{"op": "vue", "de": [30, -4], "vers": [42, -14], "texte": "place"}`
Flèche fine au sol vers ce qui motive le geste, avec un mot. Une ou deux par séquence.

### `etiquette` : nommer une partie
`{"op": "etiquette", "pos": [18, 12, 10.5], "texte": "salle de lecture"}`
Petit trait de rappel et un nom. À utiliser avec retenue : le titre de la vignette fait déjà ce travail.

## Exemple complet (une maison des jeunes sur une parcelle en lanière)

Description : « Parcelle de 24 × 60 m entre une rue au sud et un jardin public au nord, mur mitoyen haut à
l'ouest. On part d'un bloc de quatre niveaux sur toute la parcelle. On perce un passage traversant au rez pour
relier la rue au jardin. On fait descendre le bâtiment en gradins vers le jardin pour que chaque niveau ait sa
terrasse. Le dernier niveau glisse vers le jardin en porte-à-faux, pour la salle commune. »

La vue est prise du nord-est parce que les gestes regardent le jardin (au nord) : depuis le sud, les gradins
seraient cachés derrière le bloc ; le belvédère, posé sur le toit, se voit de partout.

```json
{
  "titre": "Maison des jeunes, rue des Tanneurs",
  "module": [3, 3.5],
  "vue": "nord-est",
  "parcelle": [[0,0],[24,0],[24,60],[0,60]],
  "contexte": [ {"box": [-12, 0, 0, 12, 60, 17.5]} ],
  "etapes": [
    {"titre": "Le gabarit", "texte": "quatre niveaux sur la parcelle",
     "ops": [{"op": "volume", "box": [0, 6, 0, 24, 48, 14]}]},
    {"titre": "Relier rue et jardin", "texte": "un passage traverse le rez",
     "eclater": {"box": [0, 6, 3.5, 24, 48, 10.5], "de": 7},
     "ops": [{"op": "creuser", "box": [9, 5, 0, 6, 50, 3.5], "extraire": false},
             {"op": "vue", "de": [30, 50], "vers": [30, 64], "texte": "jardin"}]},
    {"titre": "Descendre vers le jardin", "texte": "une terrasse par niveau",
     "ops": [{"op": "gradins", "box": [0, 18, 0, 24, 36, 14], "sens": "nord", "marche": [9, 3.5],
              "premiere_marche_pleine": false}]},
    {"titre": "Signaler l'entrée", "texte": "un belvédère côté rue",
     "ops": [{"op": "volume", "box": [6, 6, 14, 12, 9, 7]}]}
  ]
}
```

Lecture du contrôle attendue : étape 2, des cellules retirées (si 0, le passage ne touche pas le bâtiment) ; sans
`eclater`, le contrôle dit que le passage ne se voit depuis aucune vue (les étages le couvrent) ; avec `eclater`,
il l'estime encore à 1 % mais l'image montre clairement le vide entre les deux bandes du rez : un vide étroit se
lit par son absence plus que par sa couleur, c'est l'image qui tranche ;
étape 3, des cellules retirées en marches ; étape 4, un volume ajouté, hauteur maximale 21 m.
