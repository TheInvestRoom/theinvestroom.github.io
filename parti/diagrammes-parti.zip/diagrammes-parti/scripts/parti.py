#!/usr/bin/env python3
"""
parti.py : diagrammes de parti en séquence (axonométrie isométrique), à partir d'un fichier JSON
qui décrit le projet comme une suite d'OPÉRATIONS sur des volumes.

Python 3.8+ standard, aucune dépendance.

    python parti.py projet.json --sortie dossier/

Écrit dans le dossier :
    planche.svg        toutes les étapes côte à côte, même vue, même échelle
    animation.html     les étapes enchaînées en plein écran (soutenance, vidéo)
    etapes/etape-NN.svg   une vignette par étape
    controle.txt       ce que chaque opération a réellement touché (à relire)

Principe du moteur : le volume est découpé en cellules sur une trame (module en plan, module en
hauteur). Chaque cellule est un petit polyèdre convexe (une boîte, éventuellement coupée par des
plans pour les pentes et les biais). On dessine les cellules de la plus lointaine à la plus proche
(ordre lexicographique sur la trame, exact pour des cellules alignées), et on ne trace que les
arêtes qui séparent deux faces de plans ou de couleurs différents : le bâtiment se lit comme un
seul bloc, sans la trame.
"""
import argparse
import json
import math
import os
import sys

EPS = 1e-6

# ----------------------------------------------------------------------------- style
STYLE = {
    "accent": (236, 92, 38),       # la seule couleur : ce qui change à cette étape
    "trait": (29, 29, 27),         # arêtes
    "fond": (255, 255, 255),
    "gris_haut": 248, "gris_bas": 168,  # valeurs de gris des faces (toit -> face sombre)
    "police": "Helvetica Neue, Helvetica, Arial, sans-serif",
}


def hexa(c):
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(round(v)))) for v in c)


def melange(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


# ----------------------------------------------------------------------------- géométrie
def sub(a, b): return (a[0] - b[0], a[1] - b[1], a[2] - b[2])
def add(a, b): return (a[0] + b[0], a[1] + b[1], a[2] + b[2])
def mul(a, s): return (a[0] * s, a[1] * s, a[2] * s)
def dot(a, b): return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
def cross(a, b): return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def norm(a):
    l = math.sqrt(dot(a, a))
    return (a[0] / l, a[1] / l, a[2] / l) if l > EPS else (0.0, 0.0, 0.0)


def boite_faces(x0, y0, z0, x1, y1, z1):
    """Six faces d'une boîte, sommets dans l'ordre, normale sortante."""
    P = lambda x, y, z: (x, y, z)
    return [
        ([P(x0, y0, z1), P(x1, y0, z1), P(x1, y1, z1), P(x0, y1, z1)], (0, 0, 1)),
        ([P(x0, y0, z0), P(x0, y1, z0), P(x1, y1, z0), P(x1, y0, z0)], (0, 0, -1)),
        ([P(x1, y0, z0), P(x1, y1, z0), P(x1, y1, z1), P(x1, y0, z1)], (1, 0, 0)),
        ([P(x0, y0, z0), P(x0, y0, z1), P(x0, y1, z1), P(x0, y1, z0)], (-1, 0, 0)),
        ([P(x0, y1, z0), P(x0, y1, z1), P(x1, y1, z1), P(x1, y1, z0)], (0, 1, 0)),
        ([P(x0, y0, z0), P(x1, y0, z0), P(x1, y0, z1), P(x0, y0, z1)], (0, -1, 0)),
    ]


def couper_poly(faces, plan):
    """Garde la partie du polyèdre convexe où n.p <= d. plan = (n, d)."""
    n, d = plan
    nouvelles, sur_plan = [], []
    for pts, nf in faces:
        out = []
        k = len(pts)
        for i in range(k):
            a, b = pts[i], pts[(i + 1) % k]
            da, db = dot(n, a) - d, dot(n, b) - d
            if da <= EPS:
                out.append(a)
                if abs(da) <= EPS:
                    sur_plan.append(a)
            if (da < -EPS and db > EPS) or (da > EPS and db < -EPS):
                t = da / (da - db)
                p = add(a, mul(sub(b, a), t))
                out.append(p)
                sur_plan.append(p)
        if len(out) >= 3 and aire(out) > 1e-7:
            nouvelles.append((out, nf))
    if not nouvelles:
        return []
    # face de coupe
    uniq = []
    for p in sur_plan:
        if all(dot(sub(p, q), sub(p, q)) > 1e-10 for q in uniq):
            uniq.append(p)
    if len(uniq) >= 3:
        nn = norm(n)
        c = mul(sum_pts(uniq), 1.0 / len(uniq))
        u = norm(sub(uniq[0], c))
        v = cross(nn, u)
        uniq.sort(key=lambda p: math.atan2(dot(sub(p, c), v), dot(sub(p, c), u)))
        if aire(uniq) > 1e-7:
            nouvelles.append((uniq, nn))
    return nouvelles


def sum_pts(pts):
    s = (0.0, 0.0, 0.0)
    for p in pts:
        s = add(s, p)
    return s


def aire(pts):
    s = (0.0, 0.0, 0.0)
    for i in range(len(pts)):
        s = add(s, cross(pts[i], pts[(i + 1) % len(pts)]))
    return 0.5 * math.sqrt(dot(s, s))


# ----------------------------------------------------------------------------- modèle
class Modele:
    """Cellules sur une trame. cle (i, j, k) -> tuple de plans de coupe (vide = boîte pleine)."""

    def __init__(self, m, hm):
        self.m, self.hm = m, hm
        self.cel = {}
        self.ctx = {}

    def boite_cellule(self, c):
        i, j, k = c
        return (i * self.m, j * self.m, k * self.hm, (i + 1) * self.m, (j + 1) * self.m, (k + 1) * self.hm)

    def poly(self, c, plans):
        faces = boite_faces(*self.boite_cellule(c))
        for p in plans:
            faces = couper_poly(faces, p)
            if not faces:
                break
        return faces

    def cellules_dans(self, b, source=None):
        """Cellules dont le centre est dans la boîte b = [x, y, z, w, p, h]."""
        x, y, z, w, p, h = b
        x0, x1 = sorted((x, x + w)); y0, y1 = sorted((y, y + p)); z0, z1 = sorted((z, z + h))
        res = []
        i0, i1 = int(math.floor(x0 / self.m)) - 1, int(math.ceil(x1 / self.m)) + 1
        j0, j1 = int(math.floor(y0 / self.m)) - 1, int(math.ceil(y1 / self.m)) + 1
        k0, k1 = int(math.floor(z0 / self.hm)) - 1, int(math.ceil(z1 / self.hm)) + 1
        for i in range(i0, i1 + 1):
            cx = (i + 0.5) * self.m
            if not (x0 < cx < x1):
                continue
            for j in range(j0, j1 + 1):
                cy = (j + 0.5) * self.m
                if not (y0 < cy < y1):
                    continue
                for k in range(k0, k1 + 1):
                    cz = (k + 0.5) * self.hm
                    if z0 < cz < z1:
                        if source is None or (i, j, k) in source:
                            res.append((i, j, k))
        return res


def plan_norm(n, d):
    l = math.sqrt(dot(n, n))
    return ((n[0] / l, n[1] / l, n[2] / l), d / l)


SENS = {"+x": (1, 0), "-x": (-1, 0), "+y": (0, 1), "-y": (0, -1),
        "est": (1, 0), "ouest": (-1, 0), "nord": (0, 1), "sud": (0, -1)}


DIRS6 = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]


def marquer_faces_nues(mod, retires, etat_etape):
    """Les faces que le geste met à nu (parois d'une cour, sol d'un parvis, contremarches des gradins)
    prennent la couleur : c'est la surface que le geste a créée, donc ce que l'œil doit voir."""
    fa = etat_etape.setdefault("faces_accent", set())
    for c in retires:
        for d in DIRS6:
            v = (c[0] + d[0], c[1] + d[1], c[2] + d[2])
            if v in mod.cel:
                fa.add((v, (-d[0], -d[1], -d[2])))


def appliquer(mod, op, etat_etape, ctrl):
    """Applique une opération. etat_etape : dict avec 'accent' (set), 'fantome' (list), 'fleches' (list)."""
    t = op.get("op")
    acc, fant, fl = etat_etape["accent"], etat_etape["fantome"], etat_etape["fleches"]
    m, hm = mod.m, mod.hm

    def centre_boite(b):
        return (b[0] + b[3] / 2.0, b[1] + b[4] / 2.0, b[2] + b[5] / 2.0)

    if t in ("volume", "ajouter"):
        cs = mod.cellules_dans(op["box"])
        for c in cs:
            mod.cel[c] = ()
            acc.add(c)
        ctrl.append("%s : %d cellules ajoutées" % (t, len(cs)))
        if not cs:
            ctrl.append("  ATTENTION : boîte plus petite que la trame, rien n'a été ajouté")
        b = op["box"]
        etat_etape.setdefault("depart", (0, 0, 1.5 * max(b[5], hm)))  # le volume arrive d'en haut

    elif t == "contexte":
        cs = mod.cellules_dans(op["box"])
        for c in cs:
            mod.ctx[c] = ()
        ctrl.append("contexte : %d cellules" % len(cs))

    elif t in ("creuser", "evider", "soustraire"):
        cs = mod.cellules_dans(op["box"], mod.cel)
        retire = [(c, mod.cel.pop(c)) for c in cs]
        marquer_faces_nues(mod, cs, etat_etape)
        ctrl.append("%s : %d cellules retirées" % (t, len(cs)))
        if not cs:
            ctrl.append("  ATTENTION : la boîte ne touche aucune cellule du bâtiment")
        if cs and op.get("extraire", True):
            # le volume retiré est montré « sorti » de son trou, dans la direction où il s'ouvre :
            # le trou reste lisible et le geste se comprend (on extrait).
            occ = set(mod.cel)
            choix = (0, 0, 1)
            for dv in [(0, 0, 1), (1, 0, 0), (0, 1, 0), (-1, 0, 0), (0, -1, 0)]:
                voisins = [(c[0] + dv[0], c[1] + dv[1], c[2] + dv[2]) for c in cs]
                if not any(v in occ for v in voisins):
                    choix = dv
                    break
            ext = [max(c[q] for c in cs) - min(c[q] for c in cs) + 1 for q in range(3)]
            q = [abs(v) for v in choix].index(1)
            if q == 2:
                # en axonométrie, le dessus d'un trou de w x p s'étale verticalement sur (w + p)/2 :
                # il faut soulever d'au moins ça pour que le volume sorti ne recouvre pas son trou.
                ecart_m = 0.5 * (ext[0] + ext[1]) * m * 0.85
                pas = ext[2] + max(1, int(math.ceil(ecart_m / hm)))
            else:
                pas = ext[q] + max(2, int(round(min(ext[0], ext[1]) * 0.5)))
            dc = (choix[0] * pas, choix[1] * pas, choix[2] * pas)
            reel = (dc[0] * m, dc[1] * m, dc[2] * hm)
            for c, plans in retire:
                c2 = (c[0] + dc[0], c[1] + dc[1], c[2] + dc[2])
                fant.append((c2, tuple((n, d + dot(n, reel)) for (n, d) in plans)))
            b = op["box"]
            c0 = centre_boite(b)
            if op.get("fleche", True) is not False:
                demi = (abs(b[3]) / 2.0, abs(b[4]) / 2.0, abs(b[5]) / 2.0)
                a = add(c0, (choix[0] * demi[0] * 0.2, choix[1] * demi[1] * 0.2, choix[2] * demi[2] * 0.2))
                bout = add(c0, (reel[0] - choix[0] * demi[0] * 1.15, reel[1] - choix[1] * demi[1] * 1.15,
                                reel[2] - choix[2] * demi[2] * 1.15))
                fl.append((a, bout))
            etat_etape["depart_fantome"] = mul(reel, -1)
            return
        # passage traversant (ouvert sur deux façades opposées) : pas de fantôme, le trou se lit seul ;
        # un voile coloré dans l'ouverture la ferait passer pour un volume plein.
        occ0 = set(mod.cel)
        traversant = False
        for ax in ((1, 0, 0), (0, 1, 0)):
            ouv = [not any((c[0] + sg * ax[0], c[1] + sg * ax[1], c[2]) in occ0 for c in cs) for sg in (1, -1)]
            if all(ouv) and cs:
                haut = any((c[0], c[1], c[2] + 1) in occ0 for c in cs)
                traversant = traversant or haut
        if not traversant:
            for c, plans in retire:
                fant.append((c, plans))
        if cs and op.get("fleche", True) is not False:
            # volume laissé en place : la flèche vient de DEHORS et finit sur l'ouverture visible.
            # Une flèche tracée depuis l'intérieur passerait par-dessus la façade et cacherait le trou.
            occ = set(mod.cel)
            va, vb = etat_etape.get("vue", (1, -1))
            ouverts = []
            for dv in [(0, 0, 1), (va, 0, 0), (0, vb, 0), (-va, 0, 0), (0, -vb, 0)]:
                voisins = [(c[0] + dv[0], c[1] + dv[1], c[2] + dv[2]) for c in cs]
                if not any(v in occ for v in voisins):
                    ouverts.append(dv)
            choix = ouverts[0] if ouverts else (0, 0, 1)
            xs = [mod.boite_cellule(c) for c in cs]
            x0, x1 = min(p[0] for p in xs), max(p[3] for p in xs)
            y0, y1 = min(p[1] for p in xs), max(p[4] for p in xs)
            z0, z1 = min(p[2] for p in xs), max(p[5] for p in xs)
            cx, cy, cz = (x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2
            face = {(0, 0, 1): (cx, cy, z1), (1, 0, 0): (x1, cy, cz), (-1, 0, 0): (x0, cy, cz),
                    (0, 1, 0): (cx, y1, cz), (0, -1, 0): (cx, y0, cz)}[choix]
            tous = [mod.boite_cellule(c) for c in mod.cel] or xs
            taille_bat = max(max(p[3] for p in tous) - min(p[0] for p in tous),
                             max(p[4] for p in tous) - min(p[1] for p in tous))
            lg = max(max(m, hm) * 2.5, 0.22 * taille_bat)
            fl.append((add(face, mul(choix, lg + 0.4 * m)), add(face, mul(choix, 0.4 * m))))

    elif t in ("decaler", "soulever", "deplacer"):
        de = op.get("de", 0)
        if t == "soulever" and not isinstance(de, list):
            de = [0, 0, de]
        di, dj, dk = int(round(de[0] / m)), int(round(de[1] / m)), int(round(de[2] / hm))
        reel = (di * m, dj * m, dk * hm)
        if any(abs(reel[q] - de[q]) > 1e-6 for q in range(3)):
            ctrl.append("  NOTE : déplacement arrondi à la trame : %s -> %s m" % (de, list(reel)))
        cs = mod.cellules_dans(op["box"], mod.cel)
        bouge = {c: mod.cel.pop(c) for c in cs}
        nouv = {}
        for c, plans in bouge.items():
            c2 = (c[0] + di, c[1] + dj, c[2] + dk)
            plans2 = tuple((n, d + dot(n, reel)) for (n, d) in plans)
            nouv[c2] = plans2
        ecrase = [c for c in nouv if c in mod.cel]
        for c2, plans2 in nouv.items():
            mod.cel[c2] = plans2
            acc.add(c2)
        for c, plans in bouge.items():
            if c not in mod.cel:
                fant.append((c, plans))
        ctrl.append("%s : %d cellules déplacées de %s m" % (t, len(cs), list(reel)))
        if ecrase:
            ctrl.append("  ATTENTION : %d cellules arrivent sur des cellules existantes (fusion)" % len(ecrase))
        if not cs:
            ctrl.append("  ATTENTION : la boîte ne touche aucune cellule du bâtiment")
        if cs:
            pts = [mod.boite_cellule(c) for c in cs]
            cx = sum((p[0] + p[3]) / 2 for p in pts) / len(pts)
            cy = sum((p[1] + p[4]) / 2 for p in pts) / len(pts)
            ztop = max(p[5] for p in pts)
            a = (cx, cy, ztop + 0.3 * hm)
            if dk and not (di or dj):
                zb = min(p[2] for p in pts)
                a = (cx + 0, cy, zb)  # flèche verticale sous le volume soulevé
                bx = op["box"]
                # flèche posée à côté du volume, depuis son ancien pied ; au moins 25 % de la taille en plan,
                # sinon une levée de 3 m sous un bâtiment de 20 m donne une flèche qu'on ne voit pas
                taille = max(abs(bx[3]), abs(bx[4]))
                a = (bx[0] + bx[3] + m * 0.9, bx[1] + bx[4] / 2.0, zb - reel[2])
                fl.append((a, (a[0], a[1], a[2] + max(reel[2], 0.25 * taille))))
            else:
                # une flèche aussi courte que le déplacement (souvent 1 ou 2 trames) ne se voit pas :
                # elle prend au moins 40 % de la taille de la partie déplacée, centrée sur le mouvement
                taille = max(max(p[3] for p in pts) - min(p[0] for p in pts),
                             max(p[4] for p in pts) - min(p[1] for p in pts))
                Lr = math.sqrt(dot(reel, reel))
                Lf = max(Lr, 0.4 * taille)
                u = mul(reel, 1.0 / Lr) if Lr > 0 else (1, 0, 0)
                mil = add(a, mul(reel, 0.5))
                fl.append((add(mil, mul(u, -Lf / 2)), add(mil, mul(u, Lf / 2))))
            etat_etape["depart"] = mul(reel, -1)

    elif t in ("pente", "incliner"):
        b = op["box"]
        sx, sy = SENS[op.get("sens", "+x")]
        h0, h1 = op["hauts"]
        if sx:
            debut = b[0] if sx > 0 else b[0] + b[3]
            L = abs(b[3])
        else:
            debut = b[1] if sy > 0 else b[1] + b[4]
            L = abs(b[4])
        s = (h1 - h0) / L
        # z <= h0 + s * sgn * (coord - debut)
        n = (-s * sx, -s * sy, 1.0)
        d = h0 - s * (sx * debut if sx else sy * debut)
        P = plan_norm(n, d)
        Pinv = ((-P[0][0], -P[0][1], -P[0][2]), -P[1])
        cs = mod.cellules_dans(b, mod.cel)
        nb_suppr = nb_coupe = 0
        for c in cs:
            plans = mod.cel[c]
            reste = mod.poly(c, plans + (P,))
            enleve = mod.poly(c, plans + (Pinv,))
            if not reste:
                fant.append((c, mod.cel.pop(c)))
                nb_suppr += 1
            elif enleve and vol_poly(enleve) > 1e-4 * mod.m * mod.m * mod.hm:
                mod.cel[c] = plans + (P,)
                etat_etape.setdefault("faces_accent", set()).add((c, P[0]))
                fant.append((c, plans + (Pinv,)))
                nb_coupe += 1
        retires_p = [c for c, _ in fant if c not in mod.cel]
        marquer_faces_nues(mod, retires_p, etat_etape)
        ctrl.append("pente : %d cellules retirées, %d coupées (de %.1f m à %.1f m vers %s)" % (
            nb_suppr, nb_coupe, h0, h1, op.get("sens", "+x")))
        if nb_coupe == 0 and nb_suppr == 0:
            ctrl.append("  ATTENTION : la pente ne coupe rien (hauteurs au-dessus du volume ?)")
        # flèche le long de la pente, posée sur la surface
        if sx:
            ya = b[1] + b[4] / 2.0
            xa, xb = debut + sx * 0.15 * L, debut + sx * 0.85 * L
            za = h0 + s * 0.15 * L + 0.15 * hm
            zb = h0 + s * 0.85 * L + 0.15 * hm
            fl.append(((xa, ya, za), (xb, ya, zb)))
        else:
            xa_ = b[0] + b[3] / 2.0
            ya, yb = debut + sy * 0.15 * L, debut + sy * 0.85 * L
            za = h0 + s * 0.15 * L + 0.15 * hm
            zb = h0 + s * 0.85 * L + 0.15 * hm
            fl.append(((xa_, ya, za), (xa_, yb, zb)))

    elif t in ("gradins", "terrasser"):
        b = op["box"]
        sx, sy = SENS[op.get("sens", "+x")]
        run, rise = op.get("marche", [m, hm])
        haut = b[2] + b[5]
        debut = (b[0] if sx > 0 else b[0] + b[3]) if sx else (b[1] if sy > 0 else b[1] + b[4])
        cs = mod.cellules_dans(b, mod.cel)
        n = 0
        for c in cs:
            u = ((c[0] + 0.5) * m - debut) * sx if sx else ((c[1] + 0.5) * m - debut) * sy
            pas = int(math.floor(u / run)) + (0 if op.get("premiere_marche_pleine", True) else 1)
            limite = haut - pas * rise
            if (c[2] + 0.5) * hm > limite:
                fant.append((c, mod.cel.pop(c)))
                n += 1
        marquer_faces_nues(mod, [c for c, _ in fant], etat_etape)
        ctrl.append("gradins : %d cellules retirées (marche %s m / %s m vers %s)" % (n, run, rise, op.get("sens", "+x")))
        if n == 0:
            ctrl.append("  ATTENTION : aucun gradin créé (marche trop large ou hauteur trop faible ?)")
        L = abs(b[3]) if sx else abs(b[4])
        if sx:
            yy = b[1] + b[4] / 2.0
            a = (debut + sx * 0.1 * L, yy, haut + 0.4 * hm)
            z2 = max(b[2], haut - (L * 0.8 / run) * rise) + 0.4 * hm
            fl.append((a, (debut + sx * 0.9 * L, yy, z2)))
        else:
            xx = b[0] + b[3] / 2.0
            a = (xx, debut + sy * 0.1 * L, haut + 0.4 * hm)
            z2 = max(b[2], haut - (L * 0.8 / run) * rise) + 0.4 * hm
            fl.append((a, (xx, debut + sy * 0.9 * L, z2)))

    elif t in ("couper", "biseauter"):
        (xa, ya), (xb, yb) = op["ligne"]
        # normale horizontale à gauche de la ligne A->B
        dx, dy = xb - xa, yb - ya
        nl = (-dy, dx, 0.0)  # normale vers la gauche de A->B
        retirer = op.get("retirer", "gauche")
        # on garde n.p <= n.A : le côté retiré est celui vers lequel pointe n
        n = nl if retirer == "gauche" else (dy, -dx, 0.0)
        P = plan_norm(n, dot(n, (xa, ya, 0)))
        Pinv = ((-P[0][0], -P[0][1], -P[0][2]), -P[1])
        source = mod.cellules_dans(op["box"], mod.cel) if "box" in op else list(mod.cel)
        nb_s = nb_c = 0
        for c in source:
            plans = mod.cel[c]
            reste = mod.poly(c, plans + (P,))
            enleve = mod.poly(c, plans + (Pinv,))
            if not reste:
                fant.append((c, mod.cel.pop(c)))
                nb_s += 1
            elif enleve and vol_poly(enleve) > 1e-4 * mod.m * mod.m * mod.hm:
                mod.cel[c] = plans + (P,)
                etat_etape.setdefault("faces_accent", set()).add((c, P[0]))
                fant.append((c, plans + (Pinv,)))
                nb_c += 1
        marquer_faces_nues(mod, [c for c, _ in fant if c not in mod.cel], etat_etape)
        ctrl.append("couper : %d cellules retirées, %d coupées" % (nb_s, nb_c))
        if nb_s + nb_c == 0:
            ctrl.append("  ATTENTION : la ligne de coupe ne touche pas le volume")
        mx, my = (xa + xb) / 2.0, (ya + yb) / 2.0
        nn = norm((n[0], n[1], 0.0))  # vers le côté retiré
        zt = max([(c[2] + 1) * hm for c in mod.cel] or [hm]) + 0.3 * hm
        a = (mx - nn[0] * 0.5 * m, my - nn[1] * 0.5 * m, zt)
        fl.append((a, (a[0] + nn[0] * 2.5 * m, a[1] + nn[1] * 2.5 * m, zt)))

    elif t == "toit":
        b = op["box"]
        H = op["hauteur"]
        axe = op.get("faitage", "x")
        z0 = b[2]
        box = [b[0], b[1], z0, b[3], b[4], H]
        cs = mod.cellules_dans(box)
        if axe == "x":
            yc, demi = b[1] + b[4] / 2.0, b[4] / 2.0
            s = H / demi
            P1 = plan_norm((0, -s, 1), z0 + H - s * yc)   # z <= z0+H - s*(y-yc)
            P2 = plan_norm((0, s, 1), z0 + H + s * yc)    # z <= z0+H + s*(y-yc)
        else:
            xc, demi = b[0] + b[3] / 2.0, b[3] / 2.0
            s = H / demi
            P1 = plan_norm((-s, 0, 1), z0 + H - s * xc)
            P2 = plan_norm((s, 0, 1), z0 + H + s * xc)
        n = 0
        for c in cs:
            if mod.poly(c, (P1, P2)):
                mod.cel[c] = (P1, P2)
                acc.add(c)
                n += 1
        ctrl.append("toit : %d cellules (faîtage parallèle à %s, %.1f m)" % (n, axe, H))
        etat_etape.setdefault("depart", (0, 0, 1.2 * H))

    elif t in ("poteaux", "pilotis"):
        # poteaux fins de section 'section' m, de z0 à z1, aux points donnés (plan)
        sec = float(op.get("section", 0.4))
        z0, z1 = op.get("de_z", 0.0), op["a_z"]
        n = 0
        for (px, py) in op["points"]:
            r = sec / 2.0
            plans = (plan_norm((1, 0, 0), px + r), plan_norm((-1, 0, 0), -(px - r)),
                     plan_norm((0, 1, 0), py + r), plan_norm((0, -1, 0), -(py - r)))
            i, j = int(math.floor(px / m)), int(math.floor(py / m))
            for k in range(int(math.floor(z0 / hm)), int(math.ceil(z1 / hm))):
                c = (i, j, k)
                if c in mod.cel:
                    continue
                pz = plans + ((plan_norm((0, 0, 1), z1)),) if (k + 1) * hm > z1 + 1e-6 else plans
                mod.cel[c] = pz
                acc.add(c)
                n += 1
        ctrl.append("poteaux : %d poteaux posés (section %.2f m)" % (len(op["points"]), sec))
        if n == 0:
            ctrl.append("  ATTENTION : aucun poteau posé (cellules déjà pleines ?)")
        etat_etape.setdefault("depart", (0, 0, 0))

    elif t in ("vue", "annotation"):
        etat_etape["annotations"].append(op)
    elif t == "etiquette":
        etat_etape["etiquettes"].append(op)
    else:
        ctrl.append("  ERREUR : opération inconnue '%s'" % t)


def vol_poly(faces):
    # volume par divergence (polyèdre convexe)
    if not faces:
        return 0.0
    allp = [p for f, _ in faces for p in f]
    c = mul(sum_pts(allp), 1.0 / len(allp))
    v = 0.0
    for pts, n in faces:
        for i in range(1, len(pts) - 1):
            a, b, cc = sub(pts[0], c), sub(pts[i], c), sub(pts[i + 1], c)
            v += abs(dot(a, cross(b, cc))) / 6.0
    return v


# ----------------------------------------------------------------------------- vue et dessin
VUES = {"sud-est": (1, -1), "sud-ouest": (-1, -1), "nord-est": (1, 1), "nord-ouest": (-1, 1)}
# en dessous de cette part du dessin en couleur, un geste est jugé « caché » (seuil d'essai : 2 %,
# à ajuster ; un passage étroit dans un grand bloc peut être juste au-dessus et rester peu lisible)
SEUIL_VISIBLE = 0.02
C30, S30 = math.cos(math.radians(30)), math.sin(math.radians(30))


class Vue:
    def __init__(self, nom):
        self.a, self.b = VUES.get(nom, (1, -1))

    def proj(self, p):
        x, y, z = self.a * p[0], self.b * p[1], p[2]
        return ((x - y) * C30, (x + y) * S30 - z)

    def visible(self, n):
        return self.a * n[0] + self.b * n[1] + n[2] > 1e-6

    def cle_ordre(self, c):
        return (self.a * c[0], self.b * c[1], c[2])

    def ton(self, n):
        """0 (sombre) .. 1 (clair) selon l'orientation de la face, pour la vue."""
        nx, ny = self.a * n[0], self.b * n[1]
        t = 0.60 + 0.40 * n[2] + 0.12 * nx - 0.10 * ny
        return max(0.0, min(1.0, t))


def couleur_face(mat, t):
    if mat == "base":
        g = STYLE["gris_bas"] + (STYLE["gris_haut"] - STYLE["gris_bas"]) * (t - 0.5) / 0.5
        return hexa((g, g, g - 2))
    if mat in ("accent", "nue"):
        a = STYLE["accent"]
        if t >= 0.72:
            return hexa(melange(a, (255, 255, 255), (t - 0.72) / 0.28 * 0.42))
        return hexa(melange(a, (0, 0, 0), (0.72 - t) / 0.22 * 0.22))
    if mat == "ctx":
        g = 252 - (1 - t) * 14
        return hexa((g, g, g))
    return "none"


def cle_pt(p):
    return (round(p[0], 4), round(p[1], 4), round(p[2], 4))


def cle_plan(n, pts):
    nn = norm(n)
    d = dot(nn, pts[0])
    return (round(nn[0], 3), round(nn[1], 3), round(nn[2], 3), round(d, 3))


def cle_n(n):
    return (round(n[0], 3) + 0.0, round(n[1], 3) + 0.0, round(n[2], 3) + 0.0)


def rendre_etape(mod, etape_info, vue):
    """Liste ordonnée (de loin à près) des faces et arêtes à dessiner, en coordonnées écran.

    Deux règles font la netteté du dessin :
    - une face posée sur la limite d'une cellule est supprimée si la face de la voisine, de l'autre côté,
      la recouvre (même aire) : il ne reste que la peau du volume, même le long d'un biais ou d'une pente ;
    - une arête n'est tracée que sur la portion où une seule des deux faces coplanaires qui l'entourent
      existe (on raisonne par segments le long de la ligne, pas par sommets identiques, sinon chaque
      jonction en T entre une cellule pleine et une cellule coupée laisse un trait parasite).
    """
    acc = etape_info["accent"]
    faces_acc = {(c, cle_n(n)) for (c, n) in etape_info.get("faces_accent", set())}
    elems = []

    items = []
    for c, plans in mod.cel.items():
        items.append((c, plans, "accent" if c in acc else "base"))
    for c, plans in mod.ctx.items():
        if c not in mod.cel:
            items.append((c, plans, "ctx"))
    for c, plans in etape_info["fantome"]:
        items.append((c, plans, "fantome"))

    solides = {c: plans for c, plans, mat in items if mat != "fantome"}
    fantomes = {c: plans for c, plans, mat in items if mat == "fantome"}
    cache_poly = {}

    def poly_de(c, plans):
        k = (c, plans)
        if k not in cache_poly:
            cache_poly[k] = mod.poly(c, plans)
        return cache_poly[k]

    def recouverte(c, pts, n, ref):
        """La face (sur la limite de c, normale n) est-elle recouverte par la cellule voisine de ref ?"""
        v = (c[0] + int(round(n[0])), c[1] + int(round(n[1])), c[2] + int(round(n[2])))
        if v not in ref:
            return False
        if ref[v] == ():
            return True
        a0 = aire(pts)
        plan_v = -dot(n, pts[0])
        for q, m in poly_de(v, ref[v]):
            if abs(m[0] + n[0]) + abs(m[1] + n[1]) + abs(m[2] + n[2]) < 1e-6 and abs(dot(m, q[0]) - plan_v) < 1e-6:
                return aire(q) >= a0 - 1e-6
        return False

    faces_par_item = []
    for c, plans, mat in items:
        vis = []
        for pts, n in poly_de(c, plans):
            if not vue.visible(n):
                continue
            if est_face_bord(n, pts, mod, c):
                if mat == "fantome":
                    if recouverte(c, pts, n, solides) or recouverte(c, pts, n, fantomes):
                        continue
                elif recouverte(c, pts, n, solides):
                    continue
            mf = mat
            if mat == "base" and (c, cle_n(n)) in faces_acc:
                mf = "nue"
            vis.append((pts, n, mf))
        faces_par_item.append(vis)

    # arêtes : couverture par côté, ligne par ligne
    groupes = {}
    def cle_ligne(a, b, n, mf):
        d = norm(sub(b, a))
        for comp in d:
            if abs(comp) > 1e-6:
                if comp < 0:
                    d = mul(d, -1)
                break
        p0 = sub(a, mul(d, dot(a, d)))
        mfk = "accent" if mf in ("accent", "nue") else mf
        return (cle_n(d), (round(p0[0], 3), round(p0[1], 3), round(p0[2], 3)), cle_plan(n, [a]), mfk), d

    aretes = []  # (idx_item, a, b, cle, t0, t1, cote)
    for idx, vis in enumerate(faces_par_item):
        for pts, n, mf in vis:
            cx = mul(sum_pts(pts), 1.0 / len(pts))
            for i in range(len(pts)):
                a, b = pts[i], pts[(i + 1) % len(pts)]
                if dot(sub(b, a), sub(b, a)) < 1e-10:
                    continue
                k, d = cle_ligne(a, b, n, mf)
                t0, t1 = sorted((dot(a, d), dot(b, d)))
                perp = cross(norm(n), d)
                cote = 1 if dot(sub(cx, a), perp) > 0 else -1
                aretes.append((idx, a, b, k, t0, t1, cote, mf))
                groupes.setdefault(k, []).append((t0, t1, cote))

    def soustraire(t0, t1, intervalles):
        morceaux = [(t0, t1)]
        for u0, u1 in intervalles:
            nouv = []
            for a0, a1 in morceaux:
                if u1 <= a0 + 1e-6 or u0 >= a1 - 1e-6:
                    nouv.append((a0, a1))
                    continue
                if u0 > a0 + 1e-6:
                    nouv.append((a0, u0))
                if u1 < a1 - 1e-6:
                    nouv.append((u1, a1))
            morceaux = nouv
        return morceaux

    traits_par_item = {}
    for idx, a, b, k, t0, t1, cote, mf in aretes:
        opp = [(u0, u1) for (u0, u1, cs) in groupes[k] if cs != cote]
        d = k[0]
        base_pt = sub(a, mul(d, dot(a, d)))
        for m0, m1 in soustraire(t0, t1, opp):
            if m1 - m0 < 1e-4:
                continue
            p, q = add(base_pt, mul(d, m0)), add(base_pt, mul(d, m1))
            traits_par_item.setdefault(idx, []).append((p, q))

    ordre = sorted(range(len(items)), key=lambda i: (vue.cle_ordre(items[i][0]),
                                                      {"ctx": 0, "base": 1, "accent": 1, "fantome": 2}[items[i][2]]))
    for idx in ordre:
        c, plans, mat = items[idx]
        for pts, n, mf in faces_par_item[idx]:
            elems.append(("face", mf, [vue.proj(p) for p in pts], vue.ton(n)))
        trait_mat = "fantome" if mat == "fantome" else ("ctx" if mat == "ctx" else ("accent" if mat == "accent" else "base"))
        for p, q in traits_par_item.get(idx, []):
            elems.append(("arete", trait_mat, [vue.proj(p), vue.proj(q)], None))
    return elems


def est_face_bord(n, pts, mod, c):
    if abs(abs(n[0]) + abs(n[1]) + abs(n[2]) - 1) > 1e-6 or max(abs(n[0]), abs(n[1]), abs(n[2])) < 1 - 1e-6:
        return False
    x0, y0, z0, x1, y1, z1 = mod.boite_cellule(c)
    v = dot(n, pts[0])
    lim = {(1, 0, 0): x1, (-1, 0, 0): -x0, (0, 1, 0): y1, (0, -1, 0): -y0, (0, 0, 1): z1, (0, 0, -1): -z0}
    key = (int(round(n[0])), int(round(n[1])), int(round(n[2])))
    return key in lim and abs(v - lim[key]) < 1e-6


# ----------------------------------------------------------------------------- SVG
def f(v):
    return ("%.2f" % v).rstrip("0").rstrip(".")


def pts_svg(pts):
    return " ".join("%s,%s" % (f(x), f(y)) for x, y in pts)


def svg_elements(elems, ech, depart_ecran=None):
    """Polygones et segments, échelle ech (px par mètre). Retourne une chaîne SVG."""
    trait = hexa(STYLE["trait"])
    acc = hexa(STYLE["accent"])
    out = []
    for typ, mat, pts, ton in elems:
        P = [(x * ech, y * ech) for x, y in pts]
        if typ == "face":
            if mat == "fantome":
                out.append('<polygon class="gh" points="%s" fill="%s" fill-opacity="0.10" stroke="none"/>' % (pts_svg(P), acc))
            else:
                col = couleur_face(mat, ton)
                cls = ' class="acc"' if mat == "accent" else (' class="nue"' if mat == "nue" else "")
                out.append('<polygon%s points="%s" fill="%s" stroke="%s" stroke-width="1.1" stroke-linejoin="round"/>' % (cls, pts_svg(P), col, col))
        else:
            if mat == "fantome":
                out.append('<line class="gh" x1="%s" y1="%s" x2="%s" y2="%s" stroke="%s" stroke-width="1.3" stroke-dasharray="5 4" stroke-linecap="round"/>' % (
                    f(P[0][0]), f(P[0][1]), f(P[1][0]), f(P[1][1]), acc))
            elif mat == "ctx":
                out.append('<line x1="%s" y1="%s" x2="%s" y2="%s" stroke="#a9a9a6" stroke-width="0.8" stroke-linecap="round"/>' % (
                    f(P[0][0]), f(P[0][1]), f(P[1][0]), f(P[1][1])))
            else:
                cls = ' class="acc"' if mat == "accent" else ""
                out.append('<line%s x1="%s" y1="%s" x2="%s" y2="%s" stroke="%s" stroke-width="1.5" stroke-linecap="round"/>' % (
                    cls, f(P[0][0]), f(P[0][1]), f(P[1][0]), f(P[1][1]), trait))
    return "\n".join(out)


def svg_fleche(a, b, ech, vue, cls="arw"):
    A, B = vue.proj(a), vue.proj(b)
    A, B = (A[0] * ech, A[1] * ech), (B[0] * ech, B[1] * ech)
    dx, dy = B[0] - A[0], B[1] - A[1]
    L = math.hypot(dx, dy)
    if L < 4:
        return ""
    ux, uy = dx / L, dy / L
    tete = min(22.0, L * 0.45)
    larg = tete * 0.55
    base = (B[0] - ux * tete, B[1] - uy * tete)
    p1 = (base[0] - uy * larg, base[1] + ux * larg)
    p2 = (base[0] + uy * larg, base[1] - ux * larg)
    acc = hexa(STYLE["accent"])
    return ('<g class="%s"><path d="M%s %s L%s %s" pathLength="1" stroke="#fff" stroke-width="9" stroke-linecap="round" fill="none"/>'
            '<path d="M%s %s L%s %s" pathLength="1" stroke="%s" stroke-width="4.5" stroke-linecap="round" fill="none"/>'
            '<polygon points="%s" fill="%s" stroke="#fff" stroke-width="2" stroke-linejoin="round"/></g>') % (
        cls, f(A[0]), f(A[1]), f(base[0]), f(base[1]), f(A[0]), f(A[1]), f(base[0]), f(base[1]), acc,
        pts_svg([B, p1, p2]), acc)


def svg_annotation(op, ech, vue, taille):
    (xa, ya), (xb, yb) = op["de"], op["vers"]
    z = op.get("z", 0.0)
    s = svg_fleche((xa, ya, z), (xb, yb, z), ech, vue, cls="ann")
    B = vue.proj((xb, yb, z))
    txt = op.get("texte", "")
    if txt:
        s += ('<text class="ann" x="%s" y="%s" font-family="%s" font-size="%s" font-weight="600" fill="%s" '
              'stroke="#fff" stroke-width="4" paint-order="stroke" text-anchor="middle">%s</text>') % (
            f(B[0] * ech), f(B[1] * ech + taille * 1.6), STYLE["police"], f(taille), hexa(STYLE["trait"]), esc(txt))
    return s


def svg_etiquette(op, ech, vue, taille):
    P = vue.proj(tuple(op["pos"]))
    x, y = P[0] * ech, P[1] * ech
    return ('<g class="ann"><line x1="%s" y1="%s" x2="%s" y2="%s" stroke="%s" stroke-width="1"/>'
            '<circle cx="%s" cy="%s" r="2.6" fill="%s"/>'
            '<text x="%s" y="%s" font-family="%s" font-size="%s" fill="%s" stroke="#fff" stroke-width="4" paint-order="stroke">%s</text></g>') % (
        f(x), f(y), f(x + 26), f(y - 26), hexa(STYLE["trait"]), f(x), f(y), hexa(STYLE["trait"]),
        f(x + 30), f(y - 30), STYLE["police"], f(taille), hexa(STYLE["trait"]), esc(op.get("texte", "")))


def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def svg_parcelle(pts, ech, vue):
    P = [vue.proj((x, y, 0)) for x, y in pts]
    P = [(x * ech, y * ech) for x, y in P]
    return '<polygon points="%s" fill="#f3f2ee" stroke="#8d8d89" stroke-width="1" stroke-dasharray="7 4"/>' % pts_svg(P)


def svg_sol(mod, vue, ech, marge_m):
    """Ombre portée très légère sous le bâtiment, pour l'asseoir sur le sol."""
    return ""


# ----------------------------------------------------------------------------- pipeline
def construire(projet):
    m, hm = projet.get("module", [3.0, 3.0])
    mod = Modele(float(m), float(hm))
    vue = Vue(projet.get("vue", "sud-est"))
    for cb in projet.get("contexte", []):
        b = cb["box"] if isinstance(cb, dict) else cb
        for c in mod.cellules_dans(b):
            mod.ctx[c] = ()
    etapes = []
    controle = []
    for n, et in enumerate(projet["etapes"], 1):
        info = {"accent": set(), "fantome": [], "fleches": [], "annotations": [], "etiquettes": [],
                "vue": (vue.a, vue.b)}
        ctrl = []
        for op in et.get("ops", []):
            appliquer(mod, op, info, ctrl)
        if et.get("accent", n > 1) is False:
            info["accent"] = set()
            info["faces_accent"] = set()
        if et.get("fleche") is False:
            info["fleches"] = []
        elif isinstance(et.get("fleche"), dict):
            info["fleches"] = [(tuple(et["fleche"]["de"]), tuple(et["fleche"]["vers"]))]
        rmod, rinfo = mod, info
        if et.get("eclater"):
            # vue éclatée pour cette vignette seulement : on soulève une partie pour montrer ce qu'elle
            # cache (un rez en retrait sous une boîte, une salle sous un toit). Le modèle ne change pas.
            ex = et["eclater"]
            dk = int(round(ex.get("de", 3 * mod.hm) / mod.hm))
            reel = (0.0, 0.0, dk * mod.hm)
            cs = set(mod.cellules_dans(ex["box"], mod.cel))
            rmod = Modele(mod.m, mod.hm)
            rmod.ctx = mod.ctx
            dep = lambda c: (c[0], c[1], c[2] + dk) if c in cs else c
            for c, plans in mod.cel.items():
                rmod.cel[dep(c)] = tuple((n, d + dot(n, reel)) for (n, d) in plans) if c in cs else plans
            rinfo = dict(info)
            rinfo["accent"] = {dep(c) for c in info["accent"]}
            rinfo["faces_accent"] = {(dep(c), n) for (c, n) in info.get("faces_accent", set())}
            ctrl.append("  NOTE : vignette éclatée, %d cellules soulevées de %.1f m pour l'image seulement" % (len(cs), reel[2]))
        elems = rendre_etape(rmod, rinfo, vue)
        nb = len(mod.cel)
        zmax = max([(c[2] + 1) * mod.hm for c in mod.cel] or [0])
        controle.append("Étape %d « %s » : %s" % (n, et.get("titre", ""), "; ".join(l for l in ctrl if not l.startswith("  ")) or "aucune opération"))
        controle.extend(ctrl_l for ctrl_l in ctrl if ctrl_l.startswith("  "))
        controle.append("  -> volume : %d cellules, hauteur max %.1f m, emprise approx. %.0f m²" % (
            nb, zmax, len({(c[0], c[1]) for c in mod.cel}) * mod.m * mod.m))
        etapes.append({"titre": et.get("titre", ""), "texte": et.get("texte", ""), "elems": elems, "info": info})
    return mod, vue, etapes, controle


def bornes(etapes, vue, projet):
    xs, ys = [], []
    for e in etapes:
        for typ, mat, pts, _ in e["elems"]:
            for x, y in pts:
                xs.append(x); ys.append(y)
        for a, b in e["info"]["fleches"]:
            for p in (a, b):
                x, y = vue.proj(p); xs.append(x); ys.append(y)
        for an in e["info"]["annotations"]:
            for q in (an["de"], an["vers"]):
                # place réservée autour de la pointe pour le mot de l'annotation
                for dx, dy in ((0, 0), (-5, -5), (5, 5), (5, -5), (-5, 5)):
                    x, y = vue.proj((q[0] + dx, q[1] + dy, an.get("z", 0))); xs.append(x); ys.append(y)
                x, y = vue.proj((an["vers"][0], an["vers"][1], an.get("z", 0))); ys.append(y + 6)
    for q in projet.get("parcelle", []):
        x, y = vue.proj((q[0], q[1], 0)); xs.append(x); ys.append(y)
    return min(xs), min(ys), max(xs), max(ys)


def contenu_vignette(e, vue, ech, projet, taille_txt):
    s = []
    if projet.get("parcelle"):
        s.append(svg_parcelle(projet["parcelle"], ech, vue))
    s.append(svg_elements(e["elems"], ech))
    for an in e["info"]["annotations"]:
        s.append(svg_annotation(an, ech, vue, taille_txt))
    for a, b in e["info"]["fleches"]:
        s.append(svg_fleche(a, b, ech, vue))
    for et in e["info"]["etiquettes"]:
        s.append(svg_etiquette(et, ech, vue, taille_txt * 0.9))
    return "\n".join(s)


def fleche_nord(x, y, vue, r=20):
    """Flèche du nord : un trait, une pointe, la lettre N au-delà de la pointe."""
    ax, ay = vue.proj((0, 1, 0))
    l = math.hypot(ax, ay)
    ux, uy = ax / l, ay / l
    tip = (x + ux * r, y + uy * r)
    tail = (x - ux * r, y - uy * r)
    base = (tip[0] - ux * 10, tip[1] - uy * 10)
    px, py = -uy * 6, ux * 6
    t = hexa(STYLE["trait"])
    return ('<g><line x1="%s" y1="%s" x2="%s" y2="%s" stroke="%s" stroke-width="2"/><polygon points="%s" fill="%s"/>'
            '<text x="%s" y="%s" font-family="%s" font-size="14" font-weight="700" text-anchor="middle" fill="%s">N</text></g>') % (
        f(tail[0]), f(tail[1]), f(base[0]), f(base[1]), t,
        pts_svg([tip, (base[0] + px, base[1] + py), (base[0] - px, base[1] - py)]), t,
        f(tip[0] + ux * 13), f(tip[1] + uy * 13 + 5), STYLE["police"], t)


def ecrire_planche(projet, vue, etapes, chemin):
    n = len(etapes)
    cols = projet.get("colonnes") or (2 if n <= 4 else 3)
    rows = int(math.ceil(n / float(cols)))
    x0, y0, x1, y1 = bornes(etapes, vue, projet)
    larg_v = 560.0
    ech = larg_v / max(x1 - x0, 1e-3)
    haut_v = (y1 - y0) * ech
    if haut_v > 520:
        ech *= 520 / haut_v
        haut_v = 520
    larg_reelle = (x1 - x0) * ech
    marge, legende, entete = 40.0, 92.0, 96.0
    W = cols * (larg_v + marge) + marge
    H = entete + rows * (haut_v + legende + marge) + 30
    acc = hexa(STYLE["accent"])
    out = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %s %s" width="%s" height="%s">' % (f(W), f(H), f(W), f(H)),
           '<rect width="100%" height="100%" fill="#ffffff"/>',
           '<text x="%s" y="58" font-family="%s" font-size="30" font-weight="700" fill="%s">%s</text>' % (
               f(marge), STYLE["police"], hexa(STYLE["trait"]), esc(projet.get("titre", "Diagrammes de parti"))),
           fleche_nord(W - marge - 20, 48, vue)]
    for idx, e in enumerate(etapes):
        r, c = divmod(idx, cols)
        ox = marge + c * (larg_v + marge) + (larg_v - larg_reelle) / 2.0 - x0 * ech
        oy = entete + r * (haut_v + legende + marge) - y0 * ech
        out.append('<g transform="translate(%s %s)">' % (f(ox), f(oy)))
        out.append(contenu_vignette(e, vue, ech, projet, 14))
        out.append('</g>')
        tx = marge + c * (larg_v + marge)
        ty = entete + r * (haut_v + legende + marge) + haut_v + 30
        out.append('<circle cx="%s" cy="%s" r="15" fill="%s"/>' % (f(tx + 15), f(ty - 6), acc))
        out.append('<text x="%s" y="%s" font-family="%s" font-size="16" font-weight="700" fill="#fff" text-anchor="middle">%d</text>' % (
            f(tx + 15), f(ty - 0.5), STYLE["police"], idx + 1))
        out.append('<text x="%s" y="%s" font-family="%s" font-size="22" font-weight="700" fill="%s">%s</text>' % (
            f(tx + 42), f(ty + 1), STYLE["police"], hexa(STYLE["trait"]), esc(e["titre"])))
        if e["texte"]:
            # largeur moyenne d'un caractère ≈ 0,5 × la taille de police (estimation, sans moteur de texte)
            maxc = int((larg_v - 50) / (15 * 0.5))
            mots, lig, cur = e["texte"].split(), [], ""
            for mo in mots:
                if len(cur) + len(mo) + 1 > maxc and cur:
                    lig.append(cur); cur = mo
                else:
                    cur = (cur + " " + mo).strip()
            lig.append(cur)
            for j, l in enumerate(lig[:2]):
                out.append('<text x="%s" y="%s" font-family="%s" font-size="15" fill="#6b6b68">%s</text>' % (
                    f(tx + 42), f(ty + 26 + 19 * j), STYLE["police"], esc(l)))
    out.append('</svg>')
    with open(chemin, "w", encoding="utf-8") as fh:
        fh.write("\n".join(out))
    return ech


def ecrire_vignettes(projet, vue, etapes, dossier):
    os.makedirs(dossier, exist_ok=True)
    x0, y0, x1, y1 = bornes(etapes, vue, projet)
    ech = 900.0 / max(x1 - x0, 1e-3)
    W, H = 1000.0, (y1 - y0) * ech + 100
    for idx, e in enumerate(etapes):
        s = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %s %s" width="%s" height="%s">' % (f(W), f(H), f(W), f(H)),
             '<rect width="100%" height="100%" fill="#ffffff"/>',
             '<g transform="translate(%s %s)">' % (f(50 - x0 * ech), f(50 - y0 * ech)),
             contenu_vignette(e, vue, ech, projet, 18), '</g></svg>']
        with open(os.path.join(dossier, "etape-%02d.svg" % (idx + 1)), "w", encoding="utf-8") as fh:
            fh.write("\n".join(s))


def ecrire_animation(projet, vue, etapes, chemin):
    x0, y0, x1, y1 = bornes(etapes, vue, projet)
    ech = 1000.0 / max(x1 - x0, 1e-3)
    W, H = 1000.0 + 120, (y1 - y0) * ech + 120
    acc = hexa(STYLE["accent"])
    svgs = []
    for idx, e in enumerate(etapes):
        dep = e["info"].get("depart")
        if dep:
            d = vue.proj(dep)
            dx, dy = d[0] * ech, d[1] * ech
        else:
            dx, dy = 0.0, 0.0
        svgs.append(('<svg class="step" data-n="%d" style="--dx:%spx;--dy:%spx" viewBox="0 0 %s %s" preserveAspectRatio="xMidYMid meet">'
                     '<g transform="translate(%s %s)">%s</g></svg>') % (
            idx, f(dx), f(dy), f(W), f(H), f(60 - x0 * ech), f(60 - y0 * ech), contenu_vignette(e, vue, ech, projet, 20)))
    titres = json.dumps([{"t": e["titre"], "s": e["texte"]} for e in etapes], ensure_ascii=False)
    duree = float(projet.get("duree_etape", 2.4))
    html = HTML_ANIM.replace("__TITRE__", esc(projet.get("titre", "Diagrammes de parti"))) \
        .replace("__SVGS__", "\n".join(svgs)).replace("__TITRES__", titres) \
        .replace("__ACC__", acc).replace("__DUREE__", str(duree)).replace("__POLICE__", STYLE["police"])
    with open(chemin, "w", encoding="utf-8") as fh:
        fh.write(html)


HTML_ANIM = r"""<!DOCTYPE html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITRE__</title>
<style>
html,body{margin:0;height:100%;background:#fff;font-family:__POLICE__;color:#1d1d1b;overflow:hidden}
#scene{position:absolute;left:4%;right:4%;top:10%;bottom:20%}
.step{position:absolute;inset:0;width:100%;height:100%;opacity:0;transition:opacity .45s ease}
.step.on{opacity:1}
.step .acc{opacity:0}
.step.on .acc{animation:accin .95s cubic-bezier(.2,.85,.25,1) .25s both}
.step .nue{opacity:0}
.step.on .nue{animation:fade .6s ease .35s forwards}
.step .gh{opacity:0}
.step.on .gh{animation:ghin 1.1s ease .1s both}
.step .arw path{stroke-dasharray:1;stroke-dashoffset:1}
.step .arw polygon{opacity:0}
.step.on .arw path{animation:draw .7s ease-out 1.0s forwards}
.step.on .arw polygon{animation:fade .2s linear 1.6s forwards}
.step .ann{opacity:0}
.step.on .ann{animation:fade .5s ease 1.2s forwards}
.step .ann path{stroke-dasharray:none}
@keyframes accin{from{transform:translate(var(--dx),var(--dy));opacity:0}to{transform:none;opacity:1}}
@keyframes ghin{0%{opacity:0}25%{opacity:1}100%{opacity:1}}
@keyframes draw{to{stroke-dashoffset:0}}
@keyframes fade{to{opacity:1}}
#leg{position:absolute;left:6%;right:6%;bottom:6%;display:flex;align-items:center;gap:22px}
#num{flex:none;width:64px;height:64px;border-radius:50%;background:__ACC__;color:#fff;font-weight:700;font-size:32px;
display:flex;align-items:center;justify-content:center}
#t{font-size:44px;font-weight:700;line-height:1.05}
#s{font-size:24px;color:#6b6b68;margin-top:6px}
#tete{position:absolute;left:6%;top:4%;font-size:22px;color:#6b6b68;letter-spacing:.02em}
#prog{position:absolute;left:6%;right:6%;top:calc(4% + 36px);display:flex;gap:6px}
#prog i{flex:1;height:4px;background:#e6e5e1;border-radius:2px}
#prog i.on{background:__ACC__}
#ctl{position:absolute;right:2%;top:2%;font-size:13px;color:#999}
#ctl button{font:inherit;border:1px solid #ddd;background:#fff;border-radius:6px;padding:4px 8px;cursor:pointer}
body.capture #ctl{display:none}
</style></head><body>
<div id="tete">__TITRE__</div><div id="prog"></div>
<div id="scene">
__SVGS__
</div>
<div id="leg"><div id="num">1</div><div><div id="t"></div><div id="s"></div></div></div>
<div id="ctl"><button id="pp">pause</button> <button id="prev">&lt;</button> <button id="next">&gt;</button></div>
<script>
const T=__TITRES__, D=__DUREE__*1000;
const steps=[...document.querySelectorAll('.step')];
const prog=document.getElementById('prog');
T.forEach(()=>prog.appendChild(document.createElement('i')));
let i=0, timer=null, playing=true;
const q=new URLSearchParams(location.search);
if(q.has('capture')) document.body.classList.add('capture');
function show(k){
  i=(k+steps.length)%steps.length;
  steps.forEach((s,j)=>{s.classList.remove('on'); if(j===i){void s.offsetWidth; s.classList.add('on');}});
  document.getElementById('num').textContent=i+1;
  document.getElementById('t').textContent=T[i].t;
  document.getElementById('s').textContent=T[i].s||'';
  [...prog.children].forEach((b,j)=>b.classList.toggle('on',j<=i));
}
function loop(){ clearTimeout(timer); if(playing) timer=setTimeout(()=>{show(i+1);loop();},D); }
document.getElementById('pp').onclick=()=>{playing=!playing;document.getElementById('pp').textContent=playing?'pause':'lecture';loop();};
document.getElementById('next').onclick=()=>{show(i+1);loop();};
document.getElementById('prev').onclick=()=>{show(i-1);loop();};
document.addEventListener('keydown',e=>{if(e.key==='ArrowRight'){show(i+1);loop();} if(e.key==='ArrowLeft'){show(i-1);loop();} if(e.key===' '){document.getElementById('pp').click();}});
// ?etape=N : affiche une étape figée (captures)
if(q.has('etape')){playing=false; show(parseInt(q.get('etape'))-1);} else {show(0); loop();}
</script></body></html>
"""


def main():
    ap = argparse.ArgumentParser(description="Diagrammes de parti en séquence (axonométrie).")
    ap.add_argument("projet", help="fichier JSON du projet")
    ap.add_argument("--sortie", default="diagrammes", help="dossier de sortie")
    ap.add_argument("--sans-png", action="store_true", help="seulement SVG et HTML (pas besoin de Pillow)")
    ap.add_argument("--sans-video", action="store_true", help="pas de MP4")
    a = ap.parse_args()
    with open(a.projet, encoding="utf-8") as fh:
        projet = json.load(fh)
    os.makedirs(a.sortie, exist_ok=True)
    rp = None
    if not a.sans_png:
        try:
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            import rendu_png as rp
        except ImportError as ex:
            print("PNG, vidéo et contrôle de visibilité non faits (%s) : installe Pillow avec  pip install pillow" % ex)
    lignes_vis = []
    if rp is not None:
        vis = rp.visibilite(projet)
        if projet.get("vue", "sud-est") == "auto":
            projet["vue"] = rp.choisir_vue(vis)
            lignes_vis.append("Vue choisie automatiquement : %s" % projet["vue"])
        lignes_vis.append("Visibilité des gestes (part colorée du bâtiment dessiné), par vue :")
        for nom, parts in vis.items():
            marque = "  <- vue utilisée" if nom == projet.get("vue", "sud-est") else ""
            lignes_vis.append("  %-10s " % nom + "  ".join(
                ("ét.%d %3d %%" % (i + 1, round(100 * x))) if x is not None else ("ét.%d   -  " % (i + 1))
                for i, x in enumerate(parts)) + marque)
        for i, x in enumerate(vis.get(projet.get("vue", "sud-est"), [])):
            if x is not None and x < SEUIL_VISIBLE:
                meilleures = sorted(((vis[v][i] or 0, v) for v in vis), reverse=True)
                if meilleures[0][0] < SEUIL_VISIBLE:
                    lignes_vis.append("  ATTENTION : le geste de l'étape %d ne se voit depuis aucune vue : un autre volume "
                                      "le cache. Éclate la vignette (\"eclater\" : soulever ce qui le couvre), ou change "
                                      "l'ordre des gestes, ou agrandis le geste." % (i + 1))
                    continue
                lignes_vis.append("  ATTENTION : le geste de l'étape %d se voit à peine depuis %s (%d %%) ; "
                                  "vue où il se voit le mieux : %s (%d %%). Change de vue ou agrandis le geste." % (
                                      i + 1, projet.get("vue", "sud-est"), round(100 * x), meilleures[0][1],
                                      round(100 * meilleures[0][0])))
    mod, vue, etapes, controle = construire(projet)
    controle += [""] + lignes_vis if lignes_vis else []
    ecrire_planche(projet, vue, etapes, os.path.join(a.sortie, "planche.svg"))
    ecrire_vignettes(projet, vue, etapes, os.path.join(a.sortie, "etapes"))
    ecrire_animation(projet, vue, etapes, os.path.join(a.sortie, "animation.html"))
    txt = "\n".join(controle)
    with open(os.path.join(a.sortie, "controle.txt"), "w", encoding="utf-8") as fh:
        fh.write(txt + "\n")
    sys.stdout.reconfigure(encoding="utf-8") if hasattr(sys.stdout, "reconfigure") else None
    print(txt)
    print("\nÉcrit dans %s : planche.svg, animation.html, etapes/, controle.txt" % a.sortie)
    if rp is not None:
        for msg in rp.tout(projet, vue, etapes, a.sortie, faire_video=not a.sans_video):
            print("Écrit : " + msg)


if __name__ == "__main__":
    main()
