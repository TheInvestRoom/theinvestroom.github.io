"""
rendu_png.py : images 1080 x 1920 et vidéo MP4 des diagrammes de parti.
Appelé par parti.py. Demande Pillow (pip install pillow) ; la vidéo demande ffmpeg.

Sorties :
    sequence.png        toutes les étapes en portrait, même échelle
    geste-NN.png        chaque geste en grand, avec son numéro et son intention
    parti.mp4           les gestes qui s'enchaînent (30 i/s, H.264, yuv420p)
"""
import math
import os
import shutil
import subprocess
import tempfile

from PIL import Image, ImageDraw, ImageFont

import parti as P

W, H = 1080, 1920
SS = 2  # suréchantillonnage (traits nets après réduction)

POLICES = {
    True: ["arialbd.ttf", "Arial Bold.ttf", "DejaVuSans-Bold.ttf", "LiberationSans-Bold.ttf", "Helvetica-Bold.ttf"],
    False: ["arial.ttf", "Arial.ttf", "DejaVuSans.ttf", "LiberationSans-Regular.ttf", "Helvetica.ttf"],
}
_cache = {}


def police(taille, gras=False):
    k = (taille, gras)
    if k in _cache:
        return _cache[k]
    for nom in POLICES[gras]:
        for base in ("", "C:/Windows/Fonts/", "/usr/share/fonts/truetype/dejavu/", "/Library/Fonts/",
                     "/usr/share/fonts/truetype/liberation/", "/System/Library/Fonts/Supplemental/"):
            try:
                f = ImageFont.truetype(base + nom, taille)
                _cache[k] = f
                return f
            except OSError:
                continue
    f = ImageFont.load_default(size=taille) if hasattr(ImageFont, "load_default") else None
    _cache[k] = f
    return f


def rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


ACC = P.STYLE["accent"]
TRAIT = P.STYLE["trait"]


def ease(t):
    t = max(0.0, min(1.0, t))
    return 1 - (1 - t) ** 3


def ligne_pointillee(d, a, b, couleur, larg, tiret, vide):
    L = math.hypot(b[0] - a[0], b[1] - a[1])
    if L < 1e-6:
        return
    ux, uy = (b[0] - a[0]) / L, (b[1] - a[1]) / L
    s = 0.0
    while s < L:
        e = min(L, s + tiret)
        d.line([(a[0] + ux * s, a[1] + uy * s), (a[0] + ux * e, a[1] + uy * e)], fill=couleur, width=larg)
        s = e + vide


def fleche(d, A, B, k, prog=1.0, couleur=ACC):
    """Flèche de geste : tracée de A vers B ; prog < 1 pour l'animation."""
    if prog <= 0:
        return
    Bp = (A[0] + (B[0] - A[0]) * prog, A[1] + (B[1] - A[1]) * prog)
    dx, dy = Bp[0] - A[0], Bp[1] - A[1]
    L = math.hypot(dx, dy)
    if L < 3 * k:
        return
    ux, uy = dx / L, dy / L
    tete = min(30 * k, L * 0.45)
    larg = tete * 0.58
    base = (Bp[0] - ux * tete, Bp[1] - uy * tete)
    d.line([A, base], fill=(255, 255, 255), width=int(13 * k))
    d.line([A, base], fill=couleur, width=int(6.5 * k))
    pts = [Bp, (base[0] - uy * larg, base[1] + ux * larg), (base[0] + uy * larg, base[1] - ux * larg)]
    d.polygon(pts, fill=couleur, outline=(255, 255, 255), width=int(3 * k))
    for p in (A,):
        r = 3.2 * k
        d.ellipse([p[0] - r, p[1] - r, p[0] + r, p[1] + r], fill=couleur)


def dessiner_scene(img, e, projet, vue, ech, ox, oy, k, anim=None):
    """Dessine une étape. anim = dict(p_acc, p_gh, p_arw, dep_acc(x,y), dep_gh(x,y)) en px écran."""
    d = ImageDraw.Draw(img, "RGBA")
    T = lambda x, y: ((x * ech + ox) * k, (y * ech + oy) * k)
    a = anim or {}
    oa = a.get("dep_acc", (0, 0))
    og = a.get("dep_gh", (0, 0))
    pa, pg = a.get("p_acc", 1.0), a.get("p_gh", 1.0)
    alpha_gh = a.get("alpha_gh", 1.0)
    dax, day = oa[0] * (1 - ease(pa)) * k, oa[1] * (1 - ease(pa)) * k
    dgx, dgy = og[0] * (1 - ease(pg)) * k, og[1] * (1 - ease(pg)) * k

    if projet.get("parcelle"):
        pts = [T(*vue.proj((x, y, 0))) for x, y in projet["parcelle"]]
        d.polygon(pts, fill=(243, 242, 238))
        for i in range(len(pts)):
            ligne_pointillee(d, pts[i], pts[(i + 1) % len(pts)], (141, 141, 137), max(1, int(1.2 * k)), 9 * k, 5 * k)

    masque_gh = None
    aretes_gh = []
    for typ, mat, pts, ton in e["elems"]:
        Q = [T(x, y) for x, y in pts]
        if mat == "accent":
            Q = [(x + dax, y + day) for x, y in Q]
        elif mat == "fantome":
            Q = [(x + dgx, y + dgy) for x, y in Q]
        if typ == "face":
            if mat == "fantome" and a.get("p_solide", 1.0) < 1.0:
                # au début du geste, le volume retiré est encore plein : il se dissout ensuite en voile
                al = int(255 * (1 - ease(a.get("p_solide", 1.0))))
                if al > 3:
                    col = rgb(P.couleur_face("base", ton))
                    d.polygon(Q, fill=col + (al,))
            if mat == "fantome":
                # le fantôme est rempli d'un seul masque : des faces translucides superposées
                # feraient des stries à chaque jointure de cellule
                if masque_gh is None:
                    masque_gh = Image.new("L", img.size, 0)
                    dm = ImageDraw.Draw(masque_gh)
                dm.polygon(Q, fill=255)
            elif mat == "nue" and a.get("p_nue", 1.0) < 1.0:
                # surface mise à nu : passe du gris à la couleur pendant le geste
                t = ease(a.get("p_nue", 1.0))
                g = rgb(P.couleur_face("base", ton)); cc = rgb(P.couleur_face("nue", ton))
                col = tuple(int(g[i] + (cc[i] - g[i]) * t) for i in range(3))
                d.polygon(Q, fill=col, outline=col, width=max(1, int(0.8 * k)))
            else:
                col = rgb(P.couleur_face(mat, ton))
                d.polygon(Q, fill=col, outline=col, width=max(1, int(0.8 * k)))
        else:
            if mat == "fantome":
                aretes_gh.append(Q)
            elif mat == "ctx":
                d.line(Q, fill=(169, 169, 166), width=max(1, int(1.1 * k)))
            else:
                d.line(Q, fill=TRAIT, width=max(1, int(2.0 * k)))

    alpha_gh = alpha_gh * ease(a.get("p_solide", 1.0)) if "p_solide" in a else alpha_gh
    if masque_gh is not None and alpha_gh > 0.02:
        voile = Image.new("RGB", img.size, ACC)
        img.paste(voile, (0, 0), masque_gh.point(lambda v: int(v * 0.16 * alpha_gh)))
        d = ImageDraw.Draw(img, "RGBA")
    if alpha_gh > 0.05:
        for Q in aretes_gh:
            ligne_pointillee(d, Q[0], Q[1], ACC + (int(255 * alpha_gh),), max(1, int(1.8 * k)), 8 * k, 6 * k)

    for an in e["info"]["annotations"]:
        z = an.get("z", 0.0)
        A = T(*vue.proj((an["de"][0], an["de"][1], z)))
        B = T(*vue.proj((an["vers"][0], an["vers"][1], z)))
        fleche(d, A, B, k * 0.85, a.get("p_arw", 1.0), couleur=TRAIT)
        if an.get("texte") and a.get("p_arw", 1.0) > 0.6:
            f = police(int(30 * k), True)
            d.text((B[0], B[1] + 26 * k), an["texte"], font=f, fill=TRAIT, anchor="mt",
                   stroke_width=int(5 * k), stroke_fill=(255, 255, 255))
    for (A3, B3) in e["info"]["fleches"]:
        fleche(d, T(*vue.proj(A3)), T(*vue.proj(B3)), k, a.get("p_arw", 1.0))
    for et in e["info"]["etiquettes"]:
        if a.get("p_arw", 1.0) < 0.6:
            continue
        x, y = T(*vue.proj(tuple(et["pos"])))
        d.line([(x, y), (x + 34 * k, y - 34 * k)], fill=TRAIT, width=max(1, int(1.5 * k)))
        r = 4 * k
        d.ellipse([x - r, y - r, x + r, y + r], fill=TRAIT)
        d.text((x + 40 * k, y - 40 * k), et.get("texte", ""), font=police(int(28 * k)), fill=TRAIT, anchor="ls",
               stroke_width=int(5 * k), stroke_fill=(255, 255, 255))


def lignes(texte, f, largeur, maxi=2):
    mots, out, cur = texte.split(), [], ""
    for m in mots:
        essai = (cur + " " + m).strip()
        if f.getlength(essai) <= largeur or not cur:
            cur = essai
        else:
            out.append(cur)
            cur = m
    if cur:
        out.append(cur)
    if len(out) > maxi:
        out = out[:maxi]
        while f.getlength(out[-1] + " …") > largeur and " " in out[-1]:
            out[-1] = out[-1].rsplit(" ", 1)[0]
        out[-1] += " …"
    return out


def cadrage(bx, zone):
    """Échelle et origine pour faire tenir les bornes bx dans zone (x0, y0, x1, y1), centré."""
    x0, y0, x1, y1 = bx
    zx0, zy0, zx1, zy1 = zone
    ech = min((zx1 - zx0) / max(x1 - x0, 1e-6), (zy1 - zy0) / max(y1 - y0, 1e-6))
    ox = zx0 + ((zx1 - zx0) - (x1 - x0) * ech) / 2 - x0 * ech
    oy = zy0 + ((zy1 - zy0) - (y1 - y0) * ech) / 2 - y0 * ech
    return ech, ox, oy


def nord(d, x, y, vue, k, r=28):
    """Trait, pointe, et N au-delà de la pointe : lisible quelle que soit la vue."""
    ax, ay = vue.proj((0, 1, 0))
    l = math.hypot(ax, ay)
    ux, uy = ax / l, ay / l
    tip = (x + ux * r, y + uy * r)
    tail = (x - ux * r, y - uy * r)
    base = (tip[0] - ux * 14, tip[1] - uy * 14)
    px, py = -uy * 8, ux * 8
    K = lambda p: (p[0] * k, p[1] * k)
    d.line([K(tail), K(base)], fill=TRAIT, width=int(3 * k))
    d.polygon([K(tip), K((base[0] + px, base[1] + py)), K((base[0] - px, base[1] - py))], fill=TRAIT)
    d.text(K((tip[0] + ux * 20, tip[1] + uy * 20)), "N", font=police(int(24 * k), True), fill=TRAIT, anchor="mm")


def entete(d, projet, vue, k, n, i):
    d.text((60 * k, 92 * k), projet.get("titre", ""), font=police(int(32 * k), True), fill=(110, 110, 106), anchor="ls")
    nord(d, W - 90, 80, vue, k)
    if n and i is not None:
        larg = (W - 120 - (n - 1) * 10) / n
        for j in range(n):
            x0 = 60 + j * (larg + 10)
            d.rounded_rectangle([x0 * k, 128 * k, (x0 + larg) * k, 134 * k], radius=3 * k,
                                fill=ACC if j <= i else (230, 229, 225))


def legende(d, e, i, k, y=1640):
    y = int(y)
    r = 46
    d.ellipse([60 * k, (y - r) * k, (60 + 2 * r) * k, (y + r) * k], fill=ACC)
    d.text(((60 + r) * k, y * k), str(i + 1), font=police(int(46 * k), True), fill=(255, 255, 255), anchor="mm")
    x = 60 + 2 * r + 30
    titre = e["titre"]
    taille = 66
    f = police(int(taille * k), True)
    while f.getlength(titre) > (W - x - 50) * k and taille > 36:
        taille -= 4
        f = police(int(taille * k), True)
    d.text((x * k, (y + 8) * k), titre, font=f, fill=TRAIT, anchor="ls")
    if e["texte"]:
        ft = police(int(36 * k))
        for j, l in enumerate(lignes(e["texte"], ft, (W - x - 50) * k)):
            d.text((x * k, (y + 62 + 44 * j) * k), l, font=ft, fill=(107, 107, 104), anchor="ls")


def zone_geste(bx):
    """Dessin + légende forment un bloc centré verticalement : un dessin large ne laisse pas
    un trou blanc entre lui et sa légende."""
    larg = W - 2 * 50
    ech = larg / max(bx[2] - bx[0], 1e-6)
    h_dessin = (bx[3] - bx[1]) * ech
    h_max = H - 180 - 60 - 230
    if h_dessin > h_max:
        h_dessin = h_max
    bloc = h_dessin + 230
    y0 = 180 + (H - 180 - 60 - bloc) / 2.0
    return (50, y0, W - 50, y0 + h_dessin), y0 + h_dessin + 110


def image_geste(projet, vue, etapes, i, bx, anim=None, k=SS):
    img = Image.new("RGB", (W * k, H * k), (255, 255, 255))
    zone, y_leg = zone_geste(bx)
    ech, ox, oy = cadrage(bx, zone)
    dessiner_scene(img, etapes[i], projet, vue, ech, ox, oy, k, anim)
    d = ImageDraw.Draw(img, "RGBA")
    entete(d, projet, vue, k, len(etapes), i)
    legende(d, etapes[i], i, k, y_leg)
    return img.resize((W, H), Image.LANCZOS) if k != 1 else img


def image_sequence(projet, vue, etapes, bx, k=SS):
    """Toutes les étapes en portrait. Le nombre de colonnes est celui qui donne le plus grand dessin ;
    la légende est collée sous chaque dessin (sinon elle flotte loin de ce qu'elle nomme)."""
    n = len(etapes)
    bw, bh = bx[2] - bx[0], bx[3] - bx[1]
    haut_dispo = H - 170 - 50
    meilleur = None
    for cols in (1, 2, 3):
        rows = int(math.ceil(n / float(cols)))
        cw = (W - 80 - (cols - 1) * 30) / cols
        ch = haut_dispo / rows - 125
        e = min(cw / bw, ch / bh)
        if meilleur is None or e > meilleur[0] * 1.02:
            meilleur = (e, cols, rows, cw)
    ech, cols, rows, cell_w = meilleur
    h_dessin = bh * ech
    cell_h = h_dessin + 125
    marge_v = (haut_dispo - rows * cell_h) / (rows + 1)
    img = Image.new("RGB", (W * k, H * k), (255, 255, 255))
    d = ImageDraw.Draw(img, "RGBA")
    entete(d, projet, vue, k, 0, None)
    for i, e in enumerate(etapes):
        r, c = divmod(i, cols)
        x0 = 40 + c * (cell_w + 30)
        y0 = 170 + marge_v + r * (cell_h + marge_v)
        zone = (x0, y0, x0 + cell_w, y0 + h_dessin)
        ech_, ox, oy = cadrage(bx, zone)
        dessiner_scene(img, e, projet, vue, ech_, ox, oy, k)
        d = ImageDraw.Draw(img, "RGBA")
        yl = y0 + h_dessin + 42
        rr = 22
        d.ellipse([x0 * k, (yl - rr) * k, (x0 + 2 * rr) * k, (yl + rr) * k], fill=ACC)
        d.text(((x0 + rr) * k, yl * k), str(i + 1), font=police(int(24 * k), True), fill=(255, 255, 255), anchor="mm")
        f = police(int(32 * k), True)
        t = e["titre"]
        while f.getlength(t) > (cell_w - 60) * k and len(t) > 3:
            t = t[:-2] + "…"
        d.text(((x0 + 2 * rr + 14) * k, (yl + 11) * k), t, font=f, fill=TRAIT, anchor="ls")
        if e["texte"]:
            ft = police(int(22 * k))
            for j, l in enumerate(lignes(e["texte"], ft, (cell_w - 60) * k)):
                d.text(((x0 + 2 * rr + 14) * k, (yl + 40 + 27 * j) * k), l, font=ft, fill=(107, 107, 104), anchor="ls")
    return img.resize((W, H), Image.LANCZOS)


def depart_ecran(vue, dep, ech):
    if not dep:
        return (0.0, 0.0)
    x, y = vue.proj(dep)
    return (x * ech, y * ech)


def video(projet, vue, etapes, bx, chemin, dossier_tmp, fps=30, par_etape=None, tenue=20):
    """Chaque geste : le volume touché arrive (ou sort de son trou), puis la flèche se trace."""
    n = len(etapes)
    if par_etape is None:
        par_etape = max(0.8, min(1.6, 5.5 / n))
    nf = int(round(par_etape * fps))
    ech, _, _ = cadrage(bx, zone_geste(bx)[0])
    frames = 0
    for i, e in enumerate(etapes):
        dep_acc = depart_ecran(vue, e["info"].get("depart"), ech)
        dep_gh = depart_ecran(vue, e["info"].get("depart_fantome"), ech)
        for fi in range(nf):
            p = fi / float(nf - 1)
            if i == 0:
                anim = None  # la première image n'est jamais vide
            else:
                anim = {"p_acc": (p - 0.0) / 0.55, "p_gh": (p - 0.15) / 0.55, "dep_acc": dep_acc, "dep_gh": dep_gh,
                        "p_arw": (p - 0.5) / 0.3, "p_nue": (p - 0.25) / 0.35, "p_solide": (p - 0.05) / 0.45,
                        "alpha_gh": 1.0}
            img = image_geste(projet, vue, etapes, i, bx, anim, k=SS)
            img.save(os.path.join(dossier_tmp, "f%05d.png" % frames))
            frames += 1
    # image finale tenue
    last = os.path.join(dossier_tmp, "f%05d.png" % (frames - 1))
    for _ in range(tenue):
        shutil.copy(last, os.path.join(dossier_tmp, "f%05d.png" % frames))
        frames += 1
    ff = shutil.which("ffmpeg")
    if not ff:
        return "ffmpeg introuvable : les images de la vidéo sont dans %s" % dossier_tmp
    cmd = [ff, "-y", "-loglevel", "error", "-framerate", str(fps), "-i", os.path.join(dossier_tmp, "f%05d.png"),
           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", "-movflags", "+faststart", chemin]
    subprocess.run(cmd, check=True)
    return "%s : %d images, %.1f s" % (os.path.basename(chemin), frames, frames / float(fps))


def tout(projet, vue, etapes, sortie, faire_video=True):
    bx = P.bornes(etapes, vue, projet)
    # marge pour les flèches et étiquettes
    pad = 0.04 * max(bx[2] - bx[0], bx[3] - bx[1])
    bx = (bx[0] - pad, bx[1] - pad, bx[2] + pad, bx[3] + pad)
    msgs = []
    image_sequence(projet, vue, etapes, bx).save(os.path.join(sortie, "sequence.png"))
    msgs.append("sequence.png")
    for i in range(len(etapes)):
        image_geste(projet, vue, etapes, i, bx).save(os.path.join(sortie, "geste-%02d.png" % (i + 1)))
    msgs.append("geste-01..%02d.png" % len(etapes))
    if faire_video:
        tmp = tempfile.mkdtemp(prefix="parti_")
        try:
            msgs.append(video(projet, vue, etapes, bx, os.path.join(sortie, "parti.mp4"), tmp,
                              par_etape=projet.get("duree_etape_video")))
        finally:
            if shutil.which("ffmpeg"):
                shutil.rmtree(tmp, ignore_errors=True)
    return msgs


def visibilite(projet, taille=320):
    """Part du dessin occupée par ce qui change (couleur), pour chaque étape et chacune des 4 vues.
    Sert à repérer un geste caché (un rez en retrait sous une boîte soulevée, une pente qui descend
    vers l'arrière) et à choisir la vue qui montre le mieux toute la séquence."""
    res = {}
    for nom in P.VUES:
        pr = dict(projet)
        pr["vue"] = nom
        mod, vue, etapes, _ = P.construire(pr)
        bx = P.bornes(etapes, vue, pr)
        ech, ox, oy = cadrage(bx, (4, 4, taille - 4, taille - 4))
        parts = []
        for i, e in enumerate(etapes):
            img = Image.new("RGB", (taille, taille), (255, 255, 255))
            d = ImageDraw.Draw(img)
            for typ, mat, pts, ton in e["elems"]:
                if typ != "face" or mat in ("ctx", "fantome"):
                    continue
                Q = [(x * ech + ox, y * ech + oy) for x, y in pts]
                d.polygon(Q, fill=(255, 0, 0) if mat in ("accent", "nue") else (128, 128, 128))
            h = img.getcolors(taille * taille) or []
            rouge = sum(n for n, c in h if c == (255, 0, 0))
            bat = sum(n for n, c in h if c in ((255, 0, 0), (128, 128, 128)))
            change = bool(e["info"]["accent"] or e["info"].get("faces_accent"))
            parts.append(rouge / float(bat) if (bat and change) else None)
        res[nom] = parts
    return res


def choisir_vue(vis, seuil=0.02, assez=0.15):
    """D'abord la vue où le moins de gestes passent sous le seuil ; puis la plus grande visibilité
    totale, chaque geste plafonné à 15 % (au-delà, il se voit de toute façon : un geste énorme ne doit
    pas faire oublier un petit geste caché). Un geste caché partout ne départage pas les vues."""
    def score(v):
        xs = [x for x in vis[v] if x is not None]
        return (-sum(1 for i, x in enumerate(vis[v]) if x is not None and x < seuil
                     and max((vis[w][i] or 0) for w in vis) >= seuil),
                sum(min(x, assez) for x in xs))
    return max(vis, key=score)
