---
name: dossier-permis
description: Les pièces graphiques du permis rangées sur une planche, avec la liste du bordereau.
argument-hint: "[nom du projet]"
disable-model-invocation: true
---

Nom du projet : $ARGUMENTS

Assemble les pièces PNG du dossier courant (`pcmi1.png`, `pcmi2.png`, `pcmi3.png`, `pcmi5.png`, celles qui existent) sur une seule planche de rendu, sans les redessiner ni les déformer. Grille stricte, marges égales, chaque pièce avec son code (PCMI1…) et son intitulé. En bas, la liste des huit pièces obligatoires du bordereau du CERFA 13406 (PCMI1 plan de situation, PCMI2 plan de masse, PCMI3 plan en coupe, PCMI4 notice, PCMI5 façades et toitures, PCMI6 document graphique d'insertion, PCMI7 photo de l'environnement proche, PCMI8 photo du paysage lointain), avec une coche pour celles qui sont sur la planche et une case vide pour celles qui restent à faire. Rends `dossier.png` en 1080 × 1350 et `dossier.pdf` (A3). Termine en disant quelles pièces sont entrées dans la planche et lesquelles restent à faire.
