---
name: pcmi1
description: PCMI1, plan de situation du terrain dans la commune, sur le Plan IGN.
argument-hint: "[adresse ou référence cadastrale]"
disable-model-invocation: true
---

Terrain : $ARGUMENTS (une adresse, ou une référence cadastrale de 14 caractères comme 69191000AH0349).

Commence toujours comme ça :
1. Si `permis/site.json` n'existe pas, lance `python outils/donnees_permis.py "<adresse>"` (ou `python outils/donnees_permis.py --parcelle <référence>`). Il télécharge une seule fois les données publiques de l'IGN dans `permis/` : la parcelle du cadastre en mètres (x vers l'est, y vers le nord), ses côtés (sur voie ou séparatifs, longueurs), les voisins, les bâtiments BD TOPO, les routes, la zone du PLU, une grille d'altitudes RGE ALTI au pas de 2 m (`alti.json`) et des fonds Plan IGN et photo aérienne (`fonds.json` donne les mètres par pixel et le contour de la parcelle déjà en pixels). S'il existe, réutilise-le.
2. Lis `permis/site.json` : vérifie que la parcelle trouvée est bien celle demandée (commune, section, numéro, contenance), sinon arrête-toi et dis-le.

Dessine ensuite en code, avec un script Python (matplotlib, numpy, shapely, Pillow ; installe ce qui manque avec pip ; ffmpeg sert à la vidéo). Aucun générateur d'images : tout se calcule depuis `permis/` et `projet.txt`.

Fais la pièce PCMI1 du permis de construire : le plan de situation du terrain dans la commune (article R. 431-7 a du code de l'urbanisme). Deux vues l'une au-dessus de l'autre, de même largeur : en haut la commune (`fond_commune.png`), en bas le quartier (`fond_quartier.png`), recadrées autour du terrain, le Plan IGN un peu adouci pour que le terrain ressorte. Sur les deux, la parcelle en contour rouge vif épais avec un aplat rouge translucide, et sur la vue commune un cercle rouge autour, assez grand pour se voir sur un téléphone. Une échelle graphique exacte sur chaque vue, calculée depuis `metres_par_pixel`, et l'échelle approchée au 1/… pour la feuille A4. Le nord. Le nom de la commune, et sur la vue quartier le nom de la voie qui dessert le terrain (lu dans `site.json`). Reporte sur la vue quartier le point et l'angle de prise de vue de la photo lointaine PCMI8 (un petit cône numéroté 8, placé sur la voie, tourné vers le terrain).

Ce que tu rends, dans le dossier courant :
- `pcmi1.png` : 1080 × 1350 en portrait, fond blanc papier, à fond perdu, trait noir net de plusieurs épaisseurs, au plus 3 couleurs sobres. Le niveau d'un dossier de permis rendu par une agence d'architecture, jamais un graphique de tableur. Un cartouche propre en bas : « PCMI1 · Plan de situation », la commune, la référence cadastrale, l'échelle, le nord, la date, « Données © IGN · Licence Ouverte 2.0 ».
- `pcmi1.pdf` : la même pièce sur une feuille A4 portrait, à l'échelle écrite dans le cartouche (vérifie-la avec une cote connue).
- `pcmi1.mp4` : 3 s, 1080 × 1350, 30 i/s, H.264, yuv420p, où le dessin se construit sous les yeux (la vue commune apparaît, le cercle rouge se resserre sur le terrain, puis la vue quartier se déroule et la parcelle se trace), et se termine sur l'image finale tenue les 20 dernières images. La première image n'est jamais vide.

Ouvre le PNG pour le regarder, et corrige tout texte coupé, qui se chevauche ou trop petit pour se lire sur un téléphone. Termine en disant en quelques lignes ce que la pièce montre, les chiffres que tu as calculés et ce que tu as supposé. N'invente rien sans le dire.
