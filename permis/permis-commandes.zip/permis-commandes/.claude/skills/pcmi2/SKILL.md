---
name: pcmi2
description: PCMI2, plan de masse coté dans les trois dimensions, avec la maison de projet.txt.
argument-hint: "[adresse ou référence cadastrale]"
disable-model-invocation: true
---

Terrain : $ARGUMENTS (une adresse, ou une référence cadastrale de 14 caractères comme 69191000AH0349).

Commence toujours comme ça :
1. Si `permis/site.json` n'existe pas, lance `python outils/donnees_permis.py "<adresse>"` (ou `python outils/donnees_permis.py --parcelle <référence>`). Il télécharge une seule fois les données publiques de l'IGN dans `permis/` : la parcelle du cadastre en mètres (x vers l'est, y vers le nord), ses côtés (sur voie ou séparatifs, longueurs), les voisins, les bâtiments BD TOPO, les routes, la zone du PLU, une grille d'altitudes RGE ALTI au pas de 2 m (`alti.json`) et des fonds Plan IGN et photo aérienne (`fonds.json` donne les mètres par pixel et le contour de la parcelle déjà en pixels). S'il existe, réutilise-le.
2. Lis `permis/site.json` : vérifie que la parcelle trouvée est bien celle demandée (commune, section, numéro, contenance), sinon arrête-toi et dis-le.
3. Lis `projet.txt` : c'est le projet de maison (dimensions, implantation, hauteurs, toiture, ouvertures). S'il manque, arrête-toi et demande-le. N'invente aucune dimension : ce qui n'y est pas, tu le supposes et tu le dis.

Dessine ensuite en code, avec un script Python (matplotlib, numpy, shapely, Pillow ; installe ce qui manque avec pip ; ffmpeg sert à la vidéo). Aucun générateur d'images : tout se calcule depuis `permis/` et `projet.txt`.

Fais la pièce PCMI2 du permis de construire : le plan de masse de la construction à édifier, coté dans les trois dimensions (article R. 431-9 du code de l'urbanisme). Au 1/200, orienté nord en haut, la parcelle entière et 5 m autour :
- les limites de la parcelle en trait fort, chaque côté coté en mètres (longueur lue dans `site.json`), la limite sur voie distinguée des limites séparatives, la voie nommée, les bâtiments voisins en gris clair ;
- la maison de `projet.txt` implantée comme il le dit, en aplat avec le faîtage en trait mixte ; ses dimensions en plan cotées, et les distances de la maison aux limites qu'il donne, cotées en mètres ;
- les hauteurs : égout et faîtage par rapport au terrain naturel, et l'altitude NGF du terrain naturel aux quatre angles de la maison, interpolée dans `alti.json` (cotes altimétriques comme « TN 269,84 ») ; quelques courbes de niveau tous les 0,50 m en trait très fin ;
- l'accès, les places de stationnement, la terrasse, les arbres conservés et à planter, comme le dit `projet.txt` ;
- le trait de coupe A-A de la pièce PCMI3 (perpendiculaire à la voie, passant par la maison), et le point et l'angle de prise de vue de la photo PCMI7 (petit cône numéroté 7) ;
- en petit dans le cartouche : surface du terrain, emprise au sol de la maison, et la zone du PLU lue dans `site.json`.

Ce que tu rends, dans le dossier courant :
- `pcmi2.png` : 1080 × 1350 en portrait, fond blanc papier, à fond perdu, trait noir net de plusieurs épaisseurs, au plus 3 couleurs sobres. Le niveau d'un dossier de permis rendu par une agence d'architecture, jamais un graphique de tableur. Un cartouche propre en bas : « PCMI2 · Plan de masse », la commune, la référence cadastrale, l'échelle, le nord, la date, « Données © IGN · Licence Ouverte 2.0 ».
- `pcmi2.pdf` : la même pièce sur une feuille A3 paysage ou portrait, au 1/200, à l'échelle écrite dans le cartouche (vérifie-la avec une cote connue).
- `pcmi2.mp4` : 3 s, 1080 × 1350, 30 i/s, H.264, yuv420p, où le dessin se construit sous les yeux (la parcelle se trace côté par côté, la maison se pose, puis les cotes et les altitudes s'écrivent), et se termine sur l'image finale tenue les 20 dernières images. La première image n'est jamais vide.

Ouvre le PNG pour le regarder, et corrige tout texte coupé, qui se chevauche ou trop petit pour se lire sur un téléphone. Termine en disant en quelques lignes ce que la pièce montre, les chiffres que tu as calculés et ce que tu as supposé. N'invente rien sans le dire.
