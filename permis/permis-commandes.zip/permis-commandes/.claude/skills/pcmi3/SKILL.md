---
name: pcmi3
description: PCMI3, coupe du terrain naturel (RGE ALTI) et de la maison, terrain avant et après.
argument-hint: "[adresse ou référence cadastrale]"
disable-model-invocation: true
---

Terrain : $ARGUMENTS (une adresse, ou une référence cadastrale de 14 caractères comme 69191000AH0349).

Commence toujours comme ça :
1. Si `permis/site.json` n'existe pas, lance `python outils/donnees_permis.py "<adresse>"` (ou `python outils/donnees_permis.py --parcelle <référence>`). Il télécharge une seule fois les données publiques de l'IGN dans `permis/` : la parcelle du cadastre en mètres (x vers l'est, y vers le nord), ses côtés (sur voie ou séparatifs, longueurs), les voisins, les bâtiments BD TOPO, les routes, la zone du PLU, une grille d'altitudes RGE ALTI au pas de 2 m (`alti.json`) et des fonds Plan IGN et photo aérienne (`fonds.json` donne les mètres par pixel et le contour de la parcelle déjà en pixels). S'il existe, réutilise-le.
2. Lis `permis/site.json` : vérifie que la parcelle trouvée est bien celle demandée (commune, section, numéro, contenance), sinon arrête-toi et dis-le.
3. Lis `projet.txt` : c'est le projet de maison (dimensions, implantation, hauteurs, toiture, ouvertures). S'il manque, arrête-toi et demande-le. N'invente aucune dimension : ce qui n'y est pas, tu le supposes et tu le dis.

Dessine ensuite en code, avec un script Python (matplotlib, numpy, shapely, Pillow ; installe ce qui manque avec pip ; ffmpeg sert à la vidéo). Aucun générateur d'images : tout se calcule depuis `permis/` et `projet.txt`.

Fais la pièce PCMI3 du permis de construire : le plan en coupe du terrain et de la construction (article R. 431-10 b du code de l'urbanisme), selon la coupe A-A : une ligne perpendiculaire à la voie, qui traverse la maison de `projet.txt` en son milieu, d'une limite de la parcelle à l'autre et un peu au-delà. Le profil du terrain naturel se lit dans `alti.json` (interpolation bilinéaire, un point tous les 0,50 m) ; dessine-le en trait plein épais, et le terrain après travaux en tirets là où il change (plateforme de la maison, accès). La maison coupée : sol du rez-de-chaussée, plancher d'étage, murs en poché noir, toiture à sa pente, avec les cotes de niveau en mètres NGF (rez-de-chaussée, égout, faîtage) et les hauteurs par rapport au terrain naturel, comme dans `projet.txt`. Les limites de la parcelle et la voie marquées et nommées sous le profil. L'échelle verticale est la même que l'échelle horizontale : n'exagère pas le relief. Écris le dénivelé du terrain le long de la coupe.

Ce que tu rends, dans le dossier courant :
- `pcmi3.png` : 1080 × 1350 en portrait, fond blanc papier, à fond perdu, trait noir net de plusieurs épaisseurs, au plus 3 couleurs sobres. Le niveau d'un dossier de permis rendu par une agence d'architecture, jamais un graphique de tableur. Un cartouche propre en bas : « PCMI3 · Plan en coupe du terrain et de la construction », la commune, la référence cadastrale, l'échelle, le nord, la date, « Données © IGN · Licence Ouverte 2.0 ».
- `pcmi3.pdf` : la même pièce sur une feuille A3 paysage, au 1/100, à l'échelle écrite dans le cartouche (vérifie-la avec une cote connue).
- `pcmi3.mp4` : 3 s, 1080 × 1350, 30 i/s, H.264, yuv420p, où le dessin se construit sous les yeux (le profil du terrain se trace de gauche à droite, puis la maison monte du sol au faîtage et les cotes s'écrivent), et se termine sur l'image finale tenue les 20 dernières images. La première image n'est jamais vide.

Ouvre le PNG pour le regarder, et corrige tout texte coupé, qui se chevauche ou trop petit pour se lire sur un téléphone. Termine en disant en quelques lignes ce que la pièce montre, les chiffres que tu as calculés et ce que tu as supposé. N'invente rien sans le dire.
