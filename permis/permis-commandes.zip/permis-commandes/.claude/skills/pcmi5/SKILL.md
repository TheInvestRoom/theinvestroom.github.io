---
name: pcmi5
description: PCMI5, les quatre façades et la toiture de la maison de projet.txt.
argument-hint: "[adresse ou référence cadastrale]"
disable-model-invocation: true
---

Terrain : $ARGUMENTS (une adresse, ou une référence cadastrale de 14 caractères comme 69191000AH0349).

Commence toujours comme ça :
1. Si `permis/site.json` n'existe pas, lance `python outils/donnees_permis.py "<adresse>"` (ou `python outils/donnees_permis.py --parcelle <référence>`). Il télécharge une seule fois les données publiques de l'IGN dans `permis/` : la parcelle du cadastre en mètres (x vers l'est, y vers le nord), ses côtés (sur voie ou séparatifs, longueurs), les voisins, les bâtiments BD TOPO, les routes, la zone du PLU, une grille d'altitudes RGE ALTI au pas de 2 m (`alti.json`) et des fonds Plan IGN et photo aérienne (`fonds.json` donne les mètres par pixel et le contour de la parcelle déjà en pixels). S'il existe, réutilise-le.
2. Lis `permis/site.json` : vérifie que la parcelle trouvée est bien celle demandée (commune, section, numéro, contenance), sinon arrête-toi et dis-le.
3. Lis `projet.txt` : c'est le projet de maison (dimensions, implantation, hauteurs, toiture, ouvertures). S'il manque, arrête-toi et demande-le. N'invente aucune dimension : ce qui n'y est pas, tu le supposes et tu le dis.

Dessine ensuite en code, avec un script Python (matplotlib, numpy, shapely, Pillow ; installe ce qui manque avec pip ; ffmpeg sert à la vidéo). Aucun générateur d'images : tout se calcule depuis `permis/` et `projet.txt`.

Fais la pièce PCMI5 du permis de construire : le plan des façades et des toitures (article R. 431-10 a du code de l'urbanisme) de la maison de `projet.txt`. Les quatre façades au 1/100, nommées par leur orientation réelle (la façade sur la voie, la façade jardin et les deux pignons), avec le terrain naturel à leur pied tiré de `alti.json`, les ouvertures que décrit `projet.txt` à leur place et à leurs dimensions, les matériaux et couleurs écrits en petit à côté (enduit, tuiles, menuiseries), la hauteur à l'égout et au faîtage cotée. En plus, une petite vue en plan de la toiture (pans, faîtage, pente). Les façades doivent tenir dans le cadre portrait sans être minuscules : deux par ligne si besoin.

Ce que tu rends, dans le dossier courant :
- `pcmi5.png` : 1080 × 1350 en portrait, fond blanc papier, à fond perdu, trait noir net de plusieurs épaisseurs, au plus 3 couleurs sobres. Le niveau d'un dossier de permis rendu par une agence d'architecture, jamais un graphique de tableur. Un cartouche propre en bas : « PCMI5 · Plan des façades et des toitures », la commune, la référence cadastrale, l'échelle, le nord, la date, « Données © IGN · Licence Ouverte 2.0 ».
- `pcmi5.pdf` : la même pièce sur une feuille A3 paysage, au 1/100, à l'échelle écrite dans le cartouche (vérifie-la avec une cote connue).
- `pcmi5.mp4` : 3 s, 1080 × 1350, 30 i/s, H.264, yuv420p, où le dessin se construit sous les yeux (les façades se dessinent l'une après l'autre, les ouvertures se découpent, puis la toiture se pose), et se termine sur l'image finale tenue les 20 dernières images. La première image n'est jamais vide.

Ouvre le PNG pour le regarder, et corrige tout texte coupé, qui se chevauche ou trop petit pour se lire sur un téléphone. Termine en disant en quelques lignes ce que la pièce montre, les chiffres que tu as calculés et ce que tu as supposé. N'invente rien sans le dire.
