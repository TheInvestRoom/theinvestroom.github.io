"""Données publiques d'un terrain pour préparer les pièces graphiques d'un permis de construire.

Usage :
    python outils/donnees_permis.py "12 rue X 69450 Saint-Cyr-au-Mont-d'Or"
    python outils/donnees_permis.py --parcelle 69191000AT0121      (référence cadastrale complète, 14 caractères)
Écrit dans ./permis/ (réutilisé s'il existe, --refaire pour tout recharger) :
  site.json        parcelle cadastrale (polygone en mètres, Lambert 93 recentré : x vers l'est, y vers le nord),
                   côtés (sur voie ou séparatifs, longueur), parcelles voisines, bâtiments BD TOPO (hauteur),
                   routes (nom), zone du PLU (Géoportail de l'urbanisme), altitudes des sommets
  alti.json        grille d'altitudes RGE ALTI (NGF, m) au pas de 2 m sur la parcelle et 25 m autour
  fond_commune.png, fond_quartier.png : Plan IGN (Géoplateforme) autour du terrain, pour le plan de situation
  fond_ortho.png   photo aérienne IGN autour du terrain
  fonds.json       pour chaque fond : taille en pixels, mètres par pixel, et le contour de la parcelle déjà
                   converti en pixels de l'image (« parcelle_px »), le centre du terrain en pixels (« centre_px »)
Sources : cadastre (Parcellaire Express IGN), BD TOPO, Plan IGN v2 et BD ORTHO (Géoplateforme, Licence Ouverte 2.0),
RGE ALTI, Géoportail de l'urbanisme. Bibliothèque standard + Pillow (pip install pillow).
"""
import argparse
import io
import json
import math
import statistics
import subprocess
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path

ICI = Path(__file__).resolve().parent
UA = {"User-Agent": "pieces-permis/1.0"}
WMTS = ("https://data.geopf.fr/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER={layer}&STYLE=normal"
        "&TILEMATRIXSET=PM&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT={fmt}")


def lire(url, binaire=False, essais=4):
    for i in range(essais):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=90) as r:
                b = r.read()
                return b if binaire else json.loads(b.decode("utf-8"))
        except Exception:
            if i == essais - 1:
                raise
            time.sleep(2 ** (i + 1))


def lonlat_px(lon, lat, z):
    n = 256 * 2 ** z
    x = (lon + 180) / 360 * n
    y = (1 - math.log(math.tan(math.radians(lat)) + 1 / math.cos(math.radians(lat))) / math.pi) / 2 * n
    return x, y


def mosaique(lon, lat, z, w, h, layer, fmt, sortie, ring):
    from PIL import Image
    cx, cy = lonlat_px(lon, lat, z)
    x0, y0 = cx - w / 2, cy - h / 2
    img = Image.new("RGB", (w, h), "white")
    for tx in range(int(x0 // 256), int((x0 + w) // 256) + 1):
        for ty in range(int(y0 // 256), int((y0 + h) // 256) + 1):
            b = lire(WMTS.format(layer=layer, z=z, x=tx, y=ty, fmt=urllib.parse.quote(fmt, safe="")), binaire=True)
            img.paste(Image.open(io.BytesIO(b)).convert("RGB"), (int(tx * 256 - x0), int(ty * 256 - y0)))
    img.save(sortie)
    m_px = 156543.03392 * math.cos(math.radians(lat)) / 2 ** z
    px = []
    for p in ring:
        X, Y = lonlat_px(p[0], p[1], z)
        px.append([round(X - x0, 1), round(Y - y0, 1)])
    return {"fichier": sortie.name, "taille_px": [w, h], "zoom": z, "metres_par_pixel": round(m_px, 4),
            "centre_px": [w / 2, h / 2], "parcelle_px": px, "source": layer}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("adresse", nargs="?")
    ap.add_argument("--parcelle")
    ap.add_argument("--refaire", action="store_true")
    a = ap.parse_args()
    out = Path("permis")
    if (out / "site.json").exists() and not a.refaire:
        print("permis/ existe déjà : réutilisé (--refaire pour recharger)")
        return
    out.mkdir(exist_ok=True)
    cmd = [sys.executable, str(ICI / "parcelle.py"), "--sortie", str(out / "site.json"), "--marge", "60"]
    if a.parcelle:
        p = a.parcelle.strip().replace(" ", "")
        cmd += ["--insee", p[:5], "--section", p[8:10], "--numero", p[10:]]
    elif a.adresse:
        cmd += ["--adresse", a.adresse]
    else:
        sys.exit("Donne une adresse ou --parcelle.")
    subprocess.run(cmd, check=True)
    site = json.loads((out / "site.json").read_text(encoding="utf-8"))
    idu = site["parcelle"]["idu"]
    d = lire("https://apicarto.ign.fr/api/cadastre/parcelle?" + urllib.parse.urlencode(
        {"code_insee": idu[:5], "section": idu[8:10], "numero": idu[10:]}))
    g = d["features"][0]["geometry"]
    ring = g["coordinates"][0] if g["type"] == "Polygon" else g["coordinates"][0][0]
    lon = sum(p[0] for p in ring) / len(ring)
    lat = sum(p[1] for p in ring) / len(ring)
    site["parcelle"]["centre_lonlat"] = [round(lon, 7), round(lat, 7)]
    site["parcelle"]["polygone_lonlat"] = [[round(p[0], 7), round(p[1], 7)] for p in ring]
    (out / "site.json").write_text(json.dumps(site, ensure_ascii=False, indent=1), encoding="utf-8")
    fonds = {
        "commune": mosaique(lon, lat, 14, 1400, 2400, "GEOGRAPHICALGRIDSYSTEMS.PLANIGNV2", "image/png",
                            out / "fond_commune.png", ring),
        "quartier": mosaique(lon, lat, 16, 1400, 2400, "GEOGRAPHICALGRIDSYSTEMS.PLANIGNV2", "image/png",
                             out / "fond_quartier.png", ring),
        "ortho": mosaique(lon, lat, 19, 1400, 2400, "ORTHOIMAGERY.ORTHOPHOTOS", "image/jpeg",
                          out / "fond_ortho.png", ring),
        "credit": "© IGN Plan IGN v2 · BD ORTHO · Parcellaire Express · Licence Ouverte 2.0",
    }
    (out / "fonds.json").write_text(json.dumps(fonds, ensure_ascii=False, indent=1), encoding="utf-8")

    # grille d'altitudes au pas de 2 m, dans le repère local de site.json
    P = site["parcelle"]["polygone"]
    xs = [p[0] for p in P]
    ys = [p[1] for p in P]
    x0, x1, y0, y1 = min(xs) - 25, max(xs) + 25, min(ys) - 25, max(ys) + 25
    pas = 2.0
    nx, ny = int((x1 - x0) / pas) + 1, int((y1 - y0) / pas) + 1
    # local → lon/lat : translation + échelle autour du centre (écart de quelques cm sur 100 m)
    mx, my = statistics.mean(xs), statistics.mean(ys)
    kx = 1 / (111320 * math.cos(math.radians(lat)))
    ky = 1 / 111320
    pts = [(x0 + i * pas, y0 + j * pas) for j in range(ny) for i in range(nx)]
    ll = [(lon + (x - mx) * kx, lat + (y - my) * ky) for x, y in pts]
    z = []
    for k in range(0, len(ll), 150):
        part = ll[k:k + 150]
        r = lire("https://data.geopf.fr/altimetrie/1.0/calcul/alti/rest/elevation.json?" + urllib.parse.urlencode({
            "lon": "|".join(f"{p[0]:.7f}" for p in part), "lat": "|".join(f"{p[1]:.7f}" for p in part),
            "resource": "ign_rge_alti_wld", "zonly": "true"}, safe="|"))
        z += r["elevations"]
    (out / "alti.json").write_text(json.dumps({
        "x0": x0, "y0": y0, "pas_m": pas, "nx": nx, "ny": ny,
        "repere": "même repère que site.json (m) ; z[j][i] = altitude au point (x0 + i·pas, y0 + j·pas)",
        "source": "IGN RGE ALTI (NGF-IGN69)", "z": [z[j * nx:(j + 1) * nx] for j in range(ny)]}), encoding="utf-8")
    zz = [v for v in z if v > -100]
    print(f"Parcelle {idu} · fonds IGN et {len(z)} altitudes ({min(zz):.1f} à {max(zz):.1f} m NGF) écrits dans permis/")


if __name__ == "__main__":
    main()
