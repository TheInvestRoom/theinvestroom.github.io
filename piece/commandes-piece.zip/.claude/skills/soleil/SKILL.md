---
name: soleil
description: La tache de soleil au sol, heure par heure.
argument-hint: "[photo de la pièce]"
disable-model-invocation: true
---

Fais l'étude d'ensoleillement de la pièce en plan : à partir des fenêtres de `piece.json`, calcule la tache de soleil au sol pour chaque heure de la journée, du lever au coucher, le 21 mars, avec un vrai calcul de la position du soleil (azimut et hauteur, formules astronomiques avec numpy, latitude de Paris 48,85° N) et une orientation des fenêtres à écrire comme supposée (déduis-la de la lumière sur la photo). Une couleur par heure, du jaune clair le matin à l'orange le soir, l'heure écrite dans chaque tache, les meubles au trait fin. En marge, une petite ligne qui dit combien d'heures la pièce reçoit le soleil direct. Ajoute en petit les mêmes taches le 21 décembre et le 21 juin pour comparer.

Photo donnée : $ARGUMENTS (s'il n'y a rien, prends la photo de la pièce du dossier courant).

Commence toujours comme ça :
1. Ouvre la photo et regarde-la vraiment : forme de la pièce, murs visibles, fenêtres, porte, radiateurs, sol, plafond, meubles, d'où vient la lumière.
2. Si `piece.json` existe déjà, réutilise-le. Sinon, relève la pièce par la perspective : repère le point de fuite et les lignes du sol, du plafond et des murs, puis déduis en mètres la largeur, la profondeur et la hauteur sous plafond, la position et la taille de chaque fenêtre, de la porte, des radiateurs et de chaque meuble. Prends une mesure de référence plausible (assise d'une chaise à 0,45 m, plateau d'un bureau à 0,74 m, porte de 2,04 m) et écris qu'elle est supposée. Pour le mur derrière l'appareil photo, qu'on ne voit pas, écris-le inconnu et dessine-le en tireté. Écris `piece.json` avec ce relevé et ce que tu n'as pas pu lire.
3. Vérifie ta lecture avant de dessiner : reprojette ton relevé en traits rouges fins sur la photo (`controle.png`), regarde-le et corrige `piece.json` tant que les fenêtres, la porte et les meubles ne tombent pas sur la photo.

Dessine ensuite en code, avec un script Python (matplotlib, numpy, Pillow ; installe ce qui manque avec pip, et ffmpeg sert à la vidéo). Aucun générateur d'images : tout se calcule depuis `piece.json`.

Ce que tu rends, dans le dossier courant :
- `soleil.png` : le dessin final, 1080 × 1920 en portrait, sans marge perdue. Le dessin occupe au moins 85 % de la largeur et se lit sur un téléphone : traits assez épais, textes d'au moins 26 px, couleurs franches. La place libre sert à la légende, jamais à du vide. Niveau d'un rendu d'école d'architecture ou d'agence, jamais un graphique de tableur. Pas de titre géant : un petit cartouche discret (nom du dessin, échelle graphique, nord si utile).
- `soleil.mp4` : 3 s, 1080 × 1920, 30 i/s, H.264, yuv420p, où le dessin se construit sous les yeux (la tache de soleil glisse sur le sol heure après heure et laisse sa trace colorée) et se termine sur l'image finale tenue les 20 dernières images. La première image n'est jamais vide.

Ouvre le PNG pour le regarder, et corrige s'il y a du texte coupé ou qui se chevauche, ou un dessin trop petit. Termine en disant en quelques lignes ce que le dessin montre, ce que tu as lu sur la photo et ce que tu as supposé parce qu'elle ne le dit pas. N'invente rien sans le dire.
