# Fiche d'épisode — La skill de la semaine : `capacite-parcelle`

Mot à commenter : **PARCELLE**. Ressource envoyée : le dossier du skill (SKILL.md, 3 références, 4 scripts, README
d'installation), plus la page 3D de l'exemple de Palaiseau à ouvrir dans le navigateur.

## Ce qui est montré : un vrai résultat, sorti en session neuve

Parcelle **Palaiseau AE 0443**, zone UR1 (1 240 m², terrain libre, une façade de 26,5 m sur une impasse). Une session
Claude neuve, qui n'avait que le skill et la référence cadastrale, a trouvé la parcelle, téléchargé le règlement de
418 pages, lu 7 règles avec leur page, et sorti exactement les chiffres de ma vérification à la main (`test/journal-test.md`) :

- le pourcentage d'emprise donne **434 m²** au sol ;
- les retraits (5 m de la rue, 8 m des voisins avec fenêtres, 12 m du fond) n'en laissent que **314 m²** ;
- un volume R+1 qui tient sous les hauteurs (7 m à l'égout dans les 25 premiers mètres, 3,5 m au-delà) fait
  **10 × 20 m**, soit **200 m² au sol et environ 400 m² de plancher brut**.

Images : `test/sortie-session-neuve-A/01_parcelle.png` … `06_a_verifier.png`, vidéo `capacite.mp4` (11 s).

## En quoi c'est plus que R40

R40 (« ton règlement de PLU devient un volume coté ») lisait un extrait de 9 pages sur un **terrain fictif** de
20 × 25 m et dessinait un SVG. Ici :
1. la **vraie parcelle** sort du cadastre (forme irrégulière réelle, voisins, bâtiments avec leur hauteur) ;
2. Claude trouve **seul** la zone et le règlement complet (418 pages) sur le Géoportail de l'urbanisme ;
3. les règles s'appliquent **côté par côté** : il reconnaît la rue, les latérales et le fond ;
4. les règles qui dépendent de la hauteur deviennent des **plans inclinés** (prospect H/2), les variantes « avec ou
   sans fenêtres » et « 12 m d'une limite au choix » sont calculées (il essaie les trois options et garde le fond) ;
5. une **3D cliquable** avec un calque par règle et sa citation, six images et une vidéo ;
6. une dernière image honnête : **ce que Claude n'a pas pu trancher** (servitudes, pente, pignons, gare à 500 m).
Les nuances du garde-fou sur R40 sont traitées dans le skill lui-même : « le règlement de la zone UR1 » et non « ton
PLU » ; « enveloppe maximale théorique » et « volume indicatif » et non « ce que tu peux construire » ; la hauteur
« en tout point » et le piège des pignons sont écrits dans `references/lire-un-reglement.md`.

## Originalité (vérifié le 2 novembre 2026)

- **AlpacaLabsLLC/skills-for-architects** a `zoning-envelope` et `zoning-analysis-nyc` : **New York seulement**.
- **ign-apicarto-mcp-server** (GitHub, julienkalamon) donne à Claude l'accès aux données de l'API Carto, zonage
  compris : c'est un **accès aux données**, pas une étude de capacité (ni lecture du règlement, ni enveloppe, ni 3D).
- Outils français **payants** (Kel Foncier, Urbanease…) : études foncières en ligne, pas un skill qu'on possède.
- **Aucun skill ni prompt public français** trouvé qui va de la référence cadastrale à l'enveloppe 3D avec les
  règles citées (recherches web sur GitHub, skills.sh et le web francophone). Notre R40 reste le seul précédent,
  sur un terrain fictif.

## Passage au crible des principes 1 à 6

1. **Objet → résultat, pour qui.** Objet : *un terrain* (une adresse, une référence cadastrale) ; résultat : *son
   étude de capacité en 3D* ; pour : *l'archi, l'étudiant en projet, celui qui achète un terrain*. Le résultat est
   plus désirable que l'objet : on passe d'une référence illisible à un volume et un chiffre de m².
2. **Promesse en nom.** « l'étude de capacité », « le volume », « 434 m² → 200 m² » : tout se montre du doigt.
3. **Le spectateur au centre.** « Tu donnes une adresse… » ; jamais « mon skill » avant la fin.
4. **Pas une annonce.** Rien ne « vient de sortir » ; c'est un gain utilisable ce soir.
5. **L'accroche est venue tout de suite** (ci-dessous) : bon signe pour le sujet.
6. **Portes.** Mots inconnus d'un archi de 30 ans : aucun (« PLU », « cadastre », « retrait », « emprise » sont son
   vocabulaire). « Skill » arrive après la promesse, avec l'image du résultat. Pour un public plus large (acheteur de
   terrain), « étude de capacité » serait étroit : la phrase 2 le traduit en image.

**Question précise à 2 s :** « il fait vraiment ça sur n'importe quelle parcelle, avec le vrai PLU ? » → réponse à
l'image dès 3 s (cadastre, puis règlement).
**Phrase 2 :** coût d'avant (cadastre + 418 pages + retraits à la main), dit en images.
**Promesse visible :** à 1 s (image 0) puis en entier vers 12 s.
**À qui on l'envoie :** au collègue d'agence qui fait les faisabilités (« on teste sur le terrain de lundi ? ») ; à
l'ami qui cherche un terrain.
**Pourquoi on commente :** il manque l'outil (le skill, les scripts) : on ne peut pas le refaire de tête.

## Version A — face caméra (35 s)

| Phrase dite (voix) | Ce qu'on voit |
|---|---|
| Image 0, avant la voix | `05_volume.png` plein cadre : le volume terracotta dans son enveloppe bleue, entre les maisons voisines |
| « Tu donnes une référence cadastrale à Claude, et il te sort l'étude de capacité du terrain, en 3D. » | la vidéo `capacite.mp4` de 8 à 11 s (le volume monte), puis le personnage |
| « Normalement, c'est le cadastre, un règlement de quatre cents pages, et chaque retrait tracé à la main. » | `01_parcelle.png` (la vraie parcelle), puis la couverture du PDF du règlement qui défile (capture réelle, 418 pages) |
| « Là, il trouve la parcelle, il lit le règlement de la zone, et il cite chaque règle avec sa page. » | fenêtre Claude Code (`/capacite-parcelle "91477 AE 0443"`), puis une règle citée dans la page 3D (citation + « page 139 ») |
| « Et regarde : le règlement te laisse 434 m² au sol… » | `03_emprise.png`, le chiffre 434 m² mis en avant |
| « …sauf que les retraits en mangent la moitié. » | `02_retraits.png` : les bandes de couleur qui grignotent la parcelle (vidéo 1,6-3,8 s) |
| « Il essaie même les trois façons de placer les 12 mètres, et garde la meilleure. » | page 3D : on éteint et rallume le calque « 12 m d'une limite au choix » |
| « Résultat : un volume R+1 de 10 sur 20, environ 400 m² de plancher. » | `05_volume.png` + cartouche « ≈ 400 m² » |
| « Et à la fin, il te liste ce qu'il n'a pas pu trancher : la pente, les pignons, la gare à 500 mètres. » | `06_a_verifier.png` |
| « Bienvenue dans la skill de la semaine. Commente PARCELLE et je t'envoie le skill. » | rotation lente de la page 3D, mot PARCELLE à l'écran |

Durée prévue : 33 à 37 s à 3,3 mots par seconde (environ 115 mots).

## Version B — gabarit F17 « commande » (muet, 22 s)

Sur le modèle de R36 : interface Claude Code, commande tapée, puis un résultat plein cadre toutes les 2 à 3 s avec le
compteur à l'écran.

| Temps | Image |
|---|---|
| 0-2 s | `05_volume.png` plein cadre (image 0), texte « Ton terrain → son étude de capacité » |
| 2-4 s | fenêtre Claude Code : `/capacite-parcelle "91477 AE 0443"` tapé lettre à lettre |
| 4-6 s | `01_parcelle.png` — 01/06 |
| 6-9 s | `02_retraits.png` — 02/06 (extrait vidéo 1,6-3,8 s : les bandes apparaissent une à une) |
| 9-11 s | `03_emprise.png` — 03/06 (« 434 m² permis, 314 m² hors retraits ») |
| 11-14 s | extrait vidéo 5-7,6 s (bascule plan → 3D, l'enveloppe monte) — 04/06 |
| 14-17 s | extrait vidéo 7,6-11 s (le volume monte) — 05/06, « ≈ 400 m² de plancher » |
| 17-19 s | `06_a_verifier.png` — 06/06 |
| 19-22 s | « Commente PARCELLE » sur la page 3D qui tourne |

## Ce que montre le Reel comme résultat réel

Tout ce qui est à l'écran vient de la session neuve : parcelle, citations, chiffres, images, vidéo. Rien n'est
généré par un modèle d'image : la 3D est calculée (Three.js) à partir des données publiques. Seuls la fenêtre Claude
Code et le défilement du PDF sont à capturer (gratuit). Aucune dépense de génération.

## Limites honnêtes (dans la ressource, pas à la voix)

- Étude de **premier niveau** : enveloppe maximale théorique et volume indicatif ; ni certificat d'urbanisme, ni
  géomètre, ni avis de l'instructeur ou de l'architecte des Bâtiments de France.
- Testé en session neuve sur **deux règlements** (Palaiseau 418 p. ; Gif-sur-Yvette 454 p. dont 197 scannées) : règles
  et chiffres conformes à ma vérification à la main dans les deux cas ; voir `test/journal-test.md`. Pas encore
  essayé : PLUi de grande ville, terrain d'angle, forte pente.
- Terrain dessiné **plat** ; plan de zonage graphique, OAP et servitudes de droit privé **non lus** ; un seul
  bâtiment rectangulaire dans le volume indicatif ; implantation **sur** limite non dessinée.
- Surface de plancher **brute** (au nu extérieur), plus forte que la surface de plancher réglementaire.
- Il faut Claude Code (ou Claude.ai avec exécution de code et accès web), Python, Chrome pour les images et ffmpeg
  pour la vidéo (environ 6 minutes de rendu).
- Données publiques de l'IGN et du Géoportail de l'urbanisme (Licence Ouverte) : à citer.

## À la voix : ce qu'on ne dit pas

« ce que tu as le droit de construire », « ton PLU » (on a lu la zone), « en dix minutes » (une seule mesure :
10,8 min vidéo comprise, sur la session A), « ça remplace un géomètre ».

Formulation juste possible si on veut un repère de temps : « sur mon test, une dizaine de minutes, vidéo comprise ».
