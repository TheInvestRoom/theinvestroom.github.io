# Étude de capacité indicative — parcelle 91477 AE 0443 (Palaiseau)

Zone **UR1** — PLU de Palaiseau, règlement (modification approuvée le 24 mars 2025), zone UR, secteur UR1  
Règlement : https://data.geopf.fr/annexes/gpu/documents/DU_91477/e6219e2b37cf79f6c55e983adfe5d336/91477_reglement_20250324.pdf  
Données récupérées le 2026-11-02T18:01 (cadastre IGN, BD TOPO, Géoportail de l'urbanisme).

> Étude de faisabilité de premier niveau, pour savoir si un terrain vaut une vraie étude. Elle ne remplace ni un certificat d'urbanisme, ni un géomètre, ni l'instruction en mairie.

## Chiffres

| | |
|---|---|
| Surface de la parcelle (calculée sur le plan cadastral) | 1 239,9 m² |
| Contenance indiquée au cadastre | 1 260 m² |
| Emprise au sol maximale permise par le pourcentage | 434 m² |
| Surface au sol hors retraits (lecture la plus favorable) | 637,1 m² |
| Surface au sol hors retraits (lecture du volume indicatif : latérales aveugles, vues sur rue et jardin) | 637,1 m² |
| Hauteur maximale à l'égout / acrotère | 7 m |
| Hauteur maximale au faîtage | 11,5 m |
| Pleine terre à garder au minimum | 496 m² |
| **Volume indicatif** | 20 × 20 m, 2 niveau(x), égout 6 m, faîtage 11,5 m |
| **Surface de plancher indicative (brute)** | **800 m²** |
| Places de stationnement si les 800 m² formaient **un seul logement** (majorant, voir S) | 14 |

La surface de plancher indiquée est **brute** (au nu extérieur des murs, tous niveaux pleins). La surface de plancher réglementaire sera plus faible : elle se mesure au nu intérieur et déduit trémies, parties de moins de 1,80 m de hauteur, stationnement, etc.

## Lecture des résultats

- **Ce qui bride vraiment, dans l'ordre :** (1) la **hauteur qui tombe à 3,5 m à l'égout au-delà de 25 m de la rue** : avec le recul de 5 m, il ne reste que 20 m de profondeur pour deux niveaux ; (2) le **retrait de 12 m d'une limite au choix**, pris au fond (le meilleur choix : 637 m² hors retraits contre 475-477 m² en le prenant sur une latérale) ; (3) les **retraits latéraux** : 3 m de chaque côté pour une façade aveugle de 6 m à l'égout, 8 m s'il y a des fenêtres (la façade tomberait alors d'environ 20 m à environ 10 m) ; (4) l'**emprise de 35 %**.
- **Emprise permise et place laissée par les retraits :** le pourcentage autorise 434 m² ; les retraits laissent 637 m² au sol, le pourcentage est donc plus contraignant que les retraits. Mais le volume indicatif à deux niveaux n'occupe que 400 m² (20 × 20 m), parce qu'il ne doit pas dépasser la bande de 25 m. Les ≈ 34 m² d'emprise restants pourraient être un rez-de-chaussée seul au-delà de 25 m (3,5 m à l'égout, 4 m à l'acrotère), ce qui ajouterait ≈ 34 m² de surface brute.
- **Volume indicatif :** 20 × 20 m, R+1, égout 6 m (2 × 3,0 m, hypothèse), faîtage dessiné à 11,50 m ; **surface de plancher brute indicative ≈ 800 m²**, combles non comptés. Le faîtage est dessiné parallèle à la rue : les pignons font alors face aux latérales, à 3 m, ce qui pose la question du prospect sur pignon (voir plus bas) ; un toit plat ou un faîtage perpendiculaire à la rue l'évite.
- **Stationnement :** 1 place par tranche consommée de 60 m² **par logement** (exemples du règlement : 40 m² → 1, 70 m² → 2, 120 m² → 3, soit ⌊SDP/60⌋ + 1). Programmes types : une maison de 150 m² → 3 places ; 4 logements de 80 m² → 4 × 2 + 2 (1 par tranche de 3 logements, arrondi supérieur) = 10 places. Le périmètre de 500 m autour d'une gare peut plafonner ce nombre à 1 place par logement (art. L151-36 du code de l'urbanisme).

## Règles appliquées (citées)

**V — Retrait de 5 m de la voie** (Zone UR, chap. 2, 1/C (UR1), p. 139)  
> Toute nouvelle construction devra être implantée en retrait de la voie existante ouverte à la circulation à la date d’approbation du présent règlement, avec une distance minimum de 5 mètres.

Lecture : Mesuré depuis la limite parcelle / impasse de la Cerisaie (alignement). Les garages et annexes de 10 m² ont des règles propres (voir à vérifier).

**H — Hauteur : 7 m à l'égout dans la bande de 25 m, 3,5 m au-delà** (Zone UR, chap. 2, 1/B, p. 138)  
> Dans la bande des 25 mètres comptée à partir de la limite de voirie : - 7 mètres à l’égout du toit ou l’acrotère pour les toitures terrasses, - 11,50 mètres au faîtage. Au-delà de la limite de 25 mètres comptée à partir de la limite de voirie : - 3,5 mètres à l’égout du toit ou 4 mètres à l’acrotère pour les toitures terrasses, - 7 mètres au faîtage

Lecture : Hauteur mesurée « à compter du terrain naturel existant avant travaux en tout point de la construction » (Définitions, p. 309). Au-delà de 25 m, l'enveloppe est dessinée à l'égout 3,5 m ; un toit-terrasse y aurait droit à 4 m d'acrotère.

**L8 — Latérales : 8 m si la façade a des vues** (Zone UR, chap. 2, 1/D (UR1), p. 142)  
> En cas d’implantation en retrait de la limite séparative, la distance doit être au moins égale à : - 8 mètres si la façade en vis-à-vis de la limite séparative comporte des ouvertures créant des vues

**L2 — Latérales : H/2 (min. 2,5 m) si façade sans vues** (Zone UR, chap. 2, 1/D (UR1), p. 143)  
> la moitié de la hauteur à l'égout du toit le plus haut, avec un minimum de 2,5 mètres si la façade en vis-à-vis de la limite séparative ne comporte pas d’ouvertures créant des vues au sens du présent règlement.

Lecture : Le texte vise l'égout « du toit le plus haut » de la construction : pour un volume d'une seule hauteur c'est la même chose que le calcul point par point ; pour un volume en gradins, c'est l'égout le plus haut qui fixe la distance. Les châssis fixes, verres translucides, pavés de verre et 2 baies de moins de 0,5 m² par façade ne sont pas des vues (Définitions, p. 311).

**F8 — Fond : 8 m si la façade a des vues** (Zone UR, chap. 2, 1/D (UR1), p. 142)  
> En cas d’implantation en retrait de la limite séparative, la distance doit être au moins égale à : - 8 mètres si la façade en vis-à-vis de la limite séparative comporte des ouvertures créant des vues

Lecture : La règle vise « la limite séparative » sans distinguer latérale et fond ; le lexique confirme : « En cas d’absence de règle spécifique sur les fonds de parcelle, ce sont les mêmes règles que pour les limites séparatives latérales qui s’appliquent » (p. 310).

**F2 — Fond : H/2 (min. 2,5 m) si façade sans vues** (Zone UR, chap. 2, 1/D (UR1), p. 143)  
> la moitié de la hauteur à l'égout du toit le plus haut, avec un minimum de 2,5 mètres si la façade en vis-à-vis de la limite séparative ne comporte pas d’ouvertures créant des vues au sens du présent règlement.

**R12 — 12 m de l'une des limites séparatives, au choix** (Zone UR, chap. 2, 1/D (UR1), p. 143)  
> Par ailleurs, les constructions principales doivent être implantées, en tout point de la construction, en retrait avec un minimum de 12 mètres de l’une des limites séparatives (au choix : latérale ou fond de parcelle).

Lecture : C'est la règle qui garantit un jardin. Le calcul essaie chaque latérale et le fond.

**E — Emprise au sol 35 %** (Zone UR, chap. 2, 1/A (UR1), p. 138)  
> L’emprise au sol maximale des constructions est fixée à 35 % de la superficie de l’unité foncière.

Lecture : Emprise = projection verticale, débords et surplombs inclus, terrasses de plus de 60 cm comprises (Définitions, p. 308). Calculée ici sur la surface du plan cadastral (1 239,9 m² → 434 m²) ; sur la contenance cadastrale (1 260 m²) ce serait 441 m².

**PT — Pleine terre 40 %** (Zone UR, chap. 2, 3, p. 150)  
> Dans la zone UR1, une part de 40 % minimum de la superficie de l’unité foncière doit être conservée en espace vert de pleine terre.

Lecture : « Vraie » pleine terre sur toute la profondeur (même page) : pas de sous-sol, d'allée, de terrasse ni de stationnement dessous (Définitions, p. 308-309).

**S — Stationnement : 1 place par tranche consommée de 60 m² de SDP** (Zone UR, chap. 2, 4/A, p. 151)  
> 1 place de stationnement par tranche consommée de 60 m² de surface de plancher (exemple : obligation de stationnement pour un logement de : 40 m² SDP = 1 place ; 70 m² SDP = 2 places ; 120 m² SDP = 3 places)

Lecture : Les exemples imposent floor(SDP/60) + 1 (40 → 1, 70 → 2, 120 → 3), et la règle s'applique logement par logement. Le nombre affiché vaut pour UN seul logement occupant toute la surface brute : c'est un majorant grossier. Programmes types : maison de 150 m² = 3 places ; 4 logements de 80 m² = 4 × 2 = 8 places + 2 places (1 par tranche de 3 logements, arrondi supérieur) = 10 places. 50 % des places exigées doivent être intégrées à la construction ; places commandées interdites dès 2 logements.

## Choix faits par le calcul

- R12 : options essayées : fond (fond_2) → 637.1 m² constructibles; laterale_1 → 477.2 m² constructibles; laterale_3 → 475.1 m² constructibles. Retenue pour l'enveloppe : **fond (fond_2)**.
- Volume indicatif : option **fond (fond_2)**.

## Hypothèses (à confirmer)

- `hauteur_etage_m` : 3.0
- `pente_toit_max_deg` : 45
- `batiments_existants` : aucun
- Hauteur d'étage de 3,0 m : hypothèse de dessin pour du logement, pas une règle du PLU. Avec 7 m à l'égout, elle donne 2 niveaux pleins (R+1) ; des combles sous le faîtage de 11,50 m sont possibles mais ne sont pas comptés dans la surface.
- Volume indicatif : façades latérales aveugles (H/2, minimum 2,5 m), fenêtres sur la rue et sur le jardin (8 m du fond s'il y a des vues). C'est la lecture d'un projet courant ; avec des vues sur les latérales, il faudrait 8 m de chaque côté et la façade passerait d'environ 20 m à environ 10 m.
- Le côté sur l'impasse de la Cerisaie est traité comme une voie ouverte à la circulation à la date d'approbation : non cadastrée, BD TOPO ne la marque pas comme privée, emprise d'environ 12 m entre la parcelle et celle d'en face.
- Les deux grands côtés (46 m) aboutissent à l'impasse : ce sont des limites latérales au sens du lexique (p. 310) ; le côté opposé (27 m, deux segments) est le fond.
- Terrain vide d'après la BD TOPO : aucun bâtiment existant n'est pris en compte. À confirmer sur place (un bâtiment récent peut manquer).
- Terrain dessiné plat ; en réalité il descend d'environ 1,7 m de la rue (≈ 97,0 m) vers le fond (≈ 95,3 m).
- Le secteur UR1 a été retenu sur la foi du Géoportail de l'urbanisme (libellé UR1) ; la zone UR n'a qu'un chapitre dans ce règlement (p. 134-161), le piège des chapitres homonymes ne se pose pas.

## Ce que Claude n'a pas pu trancher

- **Plan de zonage et servitudes non vus** — L'API ne remonte ni espace vert protégé, ni marge de reculement, ni bande constructible, ni emplacement réservé, ni servitude d'utilité publique sur cette parcelle ; une absence dans l'API ne prouve pas l'absence (toutes les servitudes ne sont pas numérisées). Ouvrir le plan de zonage et le plan des servitudes, et vérifier les OAP. (source : Géoportail de l'urbanisme)
- **Pente du terrain et hauteur « en tout point »** — La hauteur se mesure depuis le terrain naturel en tout point. Le terrain descend d'environ 1,7 m vers le fond : un bâtiment à plancher unique perdra de la hauteur côté rue (point haut) ou devra suivre la pente. Les affouillements et remblais de plus de 1 m sans lien direct avec la construction sont interdits. Un relevé topographique est nécessaire. (source : Définitions, p. 309 ; Dispositions générales, p. 12 et 18 ; RGE ALTI)
- **Impasse de la Cerisaie : statut et largeur** — Le retrait de 5 m et la bande de 25 m sont comptés depuis cette impasse, supposée publique et ouverte à la circulation. Si elle est privée, le retrait s'applique quand même (« voie existante ouverte à la circulation ») mais l'accès et la desserte relèvent du droit privé. Sa chaussée fait environ 4 m selon la BD TOPO : le chapitre 3 demande une bande roulante de 5 m pour les voies desservant plus de deux logements, ce qui peut limiter le nombre de logements si cette exigence est appliquée à la voie existante. (source : Zone UR, 1/C p. 139, chap. 3 p. 157 ; BD TOPO)
- **Pignons et faîtage** — Le prospect H/2 est calculé à l'égout ; un pignon qui fait face à une limite monte jusqu'au faîtage, et le lexique dit qu'« un pignon constitue une façade ». Un instructeur peut demander que la distance tienne compte de la hauteur du pignon : prévoir un faîtage parallèle aux latérales ou un toit plat. (source : Définitions, p. 309 ; Zone UR, 1/D, p. 143)
- **Lotissement ou division : règles lot par lot** — Le règlement déroge à l'article R151-21 : en cas de lotissement ou de division, toutes les règles (retraits, 35 %, 40 % de pleine terre, 12 m) s'appliquent à chaque lot. Diviser la parcelle réduit fortement ce que chaque lot peut porter. (source : Zone UR, chap. 2, p. 138)
- **Périmètre de 500 m (gare)** — Le Géoportail signale un « Perimetre 500 m » sur la parcelle, vraisemblablement autour d'une gare. Pour le logement, l'article L151-36 du code de l'urbanisme plafonne alors le stationnement exigible à 1 place par logement (0,5 pour le logement social, L151-35, rappelé p. 7), quelle que soit la règle de 1 place par 60 m² ; à confirmer avec la mairie (qualité de la desserte). (source : Géoportail de l'urbanisme (prescription surfacique) ; p. 6-7)
- **Implantation sur une limite latérale** — Dans la bande de 25 m, le règlement permet de s'implanter sur une des latérales, sur 10 m de long, plus un prolongement de 4 m au plus et de 4 m de haut. Le calcul ne dessine que des volumes en retrait : cette option gagnerait jusqu'à environ 3 m de largeur de façade sur 10 m de profondeur (≈ 30 m² au sol par niveau), dans la limite de l'emprise de 35 %. (source : Zone UR, 1/D, p. 141)
- **Stationnement et pleine terre** — 40 % de pleine terre (≈ 496 m²) + 35 % d'emprise (≈ 434 m²) laissent ≈ 310 m² pour accès, allées, terrasses et places extérieures. Pour plusieurs logements, 50 % des places doivent être dans la construction et les places commandées sont interdites ; un sous-sol sous le jardin n'est pas de la pleine terre. (source : Zone UR, p. 150-152)
- **Surface non bornée** — Le plan cadastral donne 1 239,9 m², la matrice 1 260 m² (écart 1,6 %). L'emprise (35 %) et la pleine terre (40 %) se calculent sur l'unité foncière réelle : seul un géomètre la fixe. Si le propriétaire possède une parcelle contiguë, l'unité foncière est plus grande. (source : Cadastre IGN)
- **Classement sonore (RN catégories 1 et 2)** — La parcelle est dans les secteurs affectés par le bruit d'une route nationale classée en catégories 1 et 2 : isolation acoustique renforcée des logements (coût), pas de réduction du volume. (source : Géoportail (information surfacique) ; Dispositions générales, p. 16)
- **Argiles** — Le règlement signale des secteurs argileux sur la commune : étude de sol (G1/G2) pour les fondations, sans effet sur le volume. (source : Dispositions générales, p. 6)

## Côtés de la parcelle (déduits du cadastre)

- laterale_1 : 46.11 m — voisin 91477000AE0442
- fond_2 : 27.04 m — voisin 91477000AE0382
- laterale_3 : 46.66 m — voisin 91477000AE0445
- voie_4 : 26.46 m — Impasse de la Cerisaie (axe à 3.8 m)
