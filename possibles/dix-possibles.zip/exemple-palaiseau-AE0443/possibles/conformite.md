# Conformité des dix possibles — Palaiseau, parcelle 91477000AE0443, zone UR1

Contrôle par calcul de polygones (shapely) sur les contours de `possibles.json`, dans le repère de `site.json`. Surface de l'unité foncière retenue : 1239,9 m² (plan cadastral). Les codes renvoient aux citations en bas de page.

## 01 · Maison en L — 1 logement(s), ≈ 219 m² de SDP brute

Une maison familiale : corps R+1 parallèle à la rue (garage double au rez-de-chaussée), aile basse vers le jardin qui abrite une terrasse au sud-est.

| Règle | Mesuré | Limite | |
|---|---|---|---|
| Volumes dans la parcelle | 0,0 m² hors parcelle | 0 m² | ✅ |
| V · Recul voie 5 m | 8,00 m | ≥ 5,00 m | ✅ |
| H · Hauteur 7 m / 3,5 m | A (≤ 25 m) : égout 6,0, faîtage 9,2 m | égout ≤ 7,0, faîtage ≤ 11,5 m | ✅ |
| H · Hauteur 7 m / 3,5 m | B (≤ 25 m) : égout 3,0, faîtage 5,5 m | égout ≤ 7,0, faîtage ≤ 11,5 m | ✅ |
| L8 · laterale_1 : façades avec vues (B+A) | 15,07 m | ≥ 8,00 m | ✅ |
| L2 · laterale_1 : façades sans vues (B+A) | 6,78 m | ≥ 3,00 m (H/2 = 6,0/2, min. 2,5) | ✅ |
| L2 · laterale_1 : tout point (B+A) | 6,78 m | ≥ 3,00 m | ✅ |
| F8 · fond_2 : façades avec vues (B+A) | 21,90 m | ≥ 8,00 m | ✅ |
| F2 · fond_2 : tout point (B+A) | 21,90 m | ≥ 3,00 m | ✅ |
| L2 · laterale_3 : façades sans vues (B+A) | 5,32 m | ≥ 3,00 m (H/2 = 6,0/2, min. 2,5) | ✅ |
| L2 · laterale_3 : tout point (B+A) | 5,32 m | ≥ 3,00 m | ✅ |
| Pignon B face à fond_2 (lecture prudente : faîtage/2) | 21,90 m | ≥ 8,00 m | ✅ |
| Pignon A face à laterale_1 (lecture prudente : faîtage/2) | 6,78 m | ≥ 4,58 m | ✅ |
| Pignon A face à laterale_3 (lecture prudente : faîtage/2) | 5,57 m | ≥ 4,58 m | ✅ |
| R12 · 12 m de fond_2 (choix du projet) | 21,90 m | ≥ 12,00 m | ✅ |
| Implantation sur limite | aucune | 1 latérale au plus, bande 25 m | ✅ |
| Distance entre constructions | 1 seule construction | sans objet | ✅ |
| E · Emprise 35 % | 159,0 m² (12,8 %) | ≤ 434,0 m² | ✅ |
| PT · Pleine terre 40 % | 1000,9 m² (80,7 %) | ≥ 495,9 m² | ✅ |
| S · places exigées / comptées | 4 comptées (2 ext. + 2 garage) | ≥ 4 exigées (4) | ✅ |
| S · places intégrées à la construction | 2 | ≥ 2 (50 %, arrondi inférieur) | ✅ |
| S · dimensions des places extérieures | 2,50 × 5,00 m | ≥ 2,50 × 5,00 m | ✅ |
| S · places commandées | autorisées (1 logement) | sans objet | ✅ |
| Accès : une seule entrée charretière | 1 | 1 | ✅ |
| Accès : largeur de la bande roulante | 5,0 m | ≥ 3,5 m (≤ 2 logements) | ✅ |

**Conforme à toutes les règles contrôlées.**

## 02 · Maison à patio — 1 logement(s), ≈ 207 m² de SDP brute

Maison de plain-pied à toit plat, quatre ailes autour d'un patio planté de 7 × 7 m ; elle déborde au-delà de la bande des 25 m, où la hauteur reste sous 4 m à l'acrotère.

| Règle | Mesuré | Limite | |
|---|---|---|---|
| Volumes dans la parcelle | 0,0 m² hors parcelle | 0 m² | ✅ |
| V · Recul voie 5 m | 5,10 m | ≥ 5,00 m | ✅ |
| H · Hauteur 7 m / 3,5 m | S (≤ 25 m) : acrotère 3,6 m | acrotère ≤ 7,0 m | ✅ |
| H · Hauteur 7 m / 3,5 m | N (> 25 m) : acrotère 3,6 m | acrotère ≤ 4,0 m | ✅ |
| H · Hauteur 7 m / 3,5 m | W (≤ 25 m) : acrotère 3,6 m | acrotère ≤ 7,0 m | ✅ |
| H · Hauteur 7 m / 3,5 m | E (≤ 25 m) : acrotère 3,6 m | acrotère ≤ 7,0 m | ✅ |
| H · Hauteur 7 m / 3,5 m | G (≤ 25 m) : acrotère 3,0 m | acrotère ≤ 7,0 m | ✅ |
| L8 · laterale_1 : façades avec vues (G+E+W+S+N) | 17,55 m | ≥ 8,00 m | ✅ |
| L2 · laterale_1 : façades sans vues (G+E+W+S+N) | 5,66 m | ≥ 2,50 m (H/2 = 3,6/2, min. 2,5) | ✅ |
| L2 · laterale_1 : tout point (G+E+W+S+N) | 5,66 m | ≥ 2,50 m | ✅ |
| F8 · fond_2 : façades avec vues (G+E+W+S+N) | 19,71 m | ≥ 8,00 m | ✅ |
| F2 · fond_2 : tout point (G+E+W+S+N) | 19,71 m | ≥ 2,50 m | ✅ |
| L8 · laterale_3 : façades avec vues (G+E+W+S+N) | 15,88 m | ≥ 8,00 m | ✅ |
| L2 · laterale_3 : façades sans vues (G+E+W+S+N) | 4,26 m | ≥ 2,50 m (H/2 = 3,6/2, min. 2,5) | ✅ |
| L2 · laterale_3 : tout point (G+E+W+S+N) | 4,26 m | ≥ 2,50 m | ✅ |
| R12 · 12 m de fond_2 (choix du projet) | 19,71 m | ≥ 12,00 m | ✅ |
| Implantation sur limite | aucune | 1 latérale au plus, bande 25 m | ✅ |
| Distance entre constructions | 1 seule construction | sans objet | ✅ |
| E · Emprise 35 % | 236,7 m² (19,1 %) | ≤ 434,0 m² | ✅ |
| PT · Pleine terre 40 % | 924,9 m² (74,6 %) | ≥ 495,9 m² | ✅ |
| S · places exigées / comptées | 4 comptées (2 ext. + 2 garage) | ≥ 4 exigées (4) | ✅ |
| S · places intégrées à la construction | 2 | ≥ 2 (50 %, arrondi inférieur) | ✅ |
| S · dimensions des places extérieures | 2,50 × 5,00 m | ≥ 2,50 × 5,00 m | ✅ |
| S · places commandées | autorisées (1 logement) | sans objet | ✅ |
| Accès : une seule entrée charretière | 1 | 1 | ✅ |
| Accès : largeur de la bande roulante | 5,5 m | ≥ 3,5 m (≤ 2 logements) | ✅ |

**Conforme à toutes les règles contrôlées.**

## 03 · Villa toit-terrasse — 1 logement(s), ≈ 237 m² de SDP brute

Villa contemporaine : un rez-de-chaussée large et bas, un étage posé en porte-à-faux côté rue (auvent d'entrée) et côté est ; toits plats.

| Règle | Mesuré | Limite | |
|---|---|---|---|
| Volumes dans la parcelle | 0,0 m² hors parcelle | 0 m² | ✅ |
| V · Recul voie 5 m | 7,00 m | ≥ 5,00 m | ✅ |
| H · Hauteur 7 m / 3,5 m | G (≤ 25 m) : acrotère 3,3 m | acrotère ≤ 7,0 m | ✅ |
| H · Hauteur 7 m / 3,5 m | U (≤ 25 m) : acrotère 6,5 m | acrotère ≤ 7,0 m | ✅ |
| L2 · laterale_1 : façades sans vues (U+G) | 6,74 m | ≥ 3,25 m (H/2 = 6,5/2, min. 2,5) | ✅ |
| L2 · laterale_1 : tout point (U+G) | 6,74 m | ≥ 3,25 m | ✅ |
| F8 · fond_2 : façades avec vues (U+G) | 24,24 m | ≥ 8,00 m | ✅ |
| F2 · fond_2 : tout point (U+G) | 24,24 m | ≥ 3,25 m | ✅ |
| L8 · laterale_3 : façades avec vues (U+G) | 8,75 m | ≥ 8,00 m | ✅ |
| L2 · laterale_3 : façades sans vues (U+G) | 4,39 m | ≥ 3,25 m (H/2 = 6,5/2, min. 2,5) | ✅ |
| L2 · laterale_3 : tout point (U+G) | 4,39 m | ≥ 3,25 m | ✅ |
| R12 · 12 m de fond_2 (choix du projet) | 24,24 m | ≥ 12,00 m | ✅ |
| Implantation sur limite | aucune | 1 latérale au plus, bande 25 m | ✅ |
| Distance entre constructions | 1 seule construction | sans objet | ✅ |
| E · Emprise 35 % | 210,0 m² (16,9 %) | ≤ 434,0 m² | ✅ |
| PT · Pleine terre 40 % | 928,9 m² (74,9 %) | ≥ 495,9 m² | ✅ |
| S · places exigées / comptées | 4 comptées (2 ext. + 2 garage) | ≥ 4 exigées (4) | ✅ |
| S · places intégrées à la construction | 2 | ≥ 2 (50 %, arrondi inférieur) | ✅ |
| S · dimensions des places extérieures | 2,50 × 5,00 m | ≥ 2,50 × 5,00 m | ✅ |
| S · places commandées | autorisées (1 logement) | sans objet | ✅ |
| Accès : une seule entrée charretière | 1 | 1 | ✅ |
| Accès : largeur de la bande roulante | 5,5 m | ≥ 3,5 m (≤ 2 logements) | ✅ |

**Conforme à toutes les règles contrôlées.**

## 04 · Maison sur limite — 1 logement(s), ≈ 230 m² de SDP brute

Maison adossée à la limite ouest (laterale_3) : 10 m de mur R+1 sur la limite, prolongés de 4 m à 3,5 m de haut ; tout le jardin se libère à l'est.

| Règle | Mesuré | Limite | |
|---|---|---|---|
| Volumes dans la parcelle | 0,0 m² hors parcelle | 0 m² | ✅ |
| V · Recul voie 5 m | 8,00 m | ≥ 5,00 m | ✅ |
| H · Hauteur 7 m / 3,5 m | LIM (≤ 25 m) : acrotère 6,5 m | acrotère ≤ 7,0 m | ✅ |
| H · Hauteur 7 m / 3,5 m | PRO (≤ 25 m) : acrotère 3,5 m | acrotère ≤ 7,0 m | ✅ |
| H · Hauteur 7 m / 3,5 m | B (≤ 25 m) : acrotère 6,5 m | acrotère ≤ 7,0 m | ✅ |
| L8 · laterale_1 : façades avec vues (B+PRO+LIM) | 11,27 m | ≥ 8,00 m | ✅ |
| L2 · laterale_1 : tout point (B+PRO+LIM) | 11,27 m | ≥ 3,25 m | ✅ |
| F8 · fond_2 : façades avec vues (B+PRO+LIM) | 24,64 m | ≥ 8,00 m | ✅ |
| F2 · fond_2 : tout point (B+PRO+LIM) | 24,64 m | ≥ 3,25 m | ✅ |
| L2 · laterale_3 : tout point (B+PRO+LIM) | 7,58 m | ≥ 3,25 m | ✅ |
| R12 · 12 m de fond_2 (choix du projet) | 24,64 m | ≥ 12,00 m | ✅ |
| Implantation sur limite : laquelle | laterale_3 | 1 seule latérale | ✅ |
| Sur limite : longueur du mur principal | 9,97 m | ≤ 10,00 m | ✅ |
| Sur limite : prolongement | 3,97 m, haut. 3,5 m | ≤ 4,00 m de long, ≤ 4,0 m de haut | ✅ |
| Sur limite : dans la bande de 25 m | jusqu'à 21,90 m de la voie | ≤ 25,00 m | ✅ |
| Distance entre constructions | 1 seule construction | sans objet | ✅ |
| E · Emprise 35 % | 148,1 m² (11,9 %) | ≤ 434,0 m² | ✅ |
| PT · Pleine terre 40 % | 997,0 m² (80,4 %) | ≥ 495,9 m² | ✅ |
| S · places exigées / comptées | 4 comptées (2 ext. + 2 garage) | ≥ 4 exigées (4) | ✅ |
| S · places intégrées à la construction | 2 | ≥ 2 (50 %, arrondi inférieur) | ✅ |
| S · dimensions des places extérieures | 2,50 × 5,00 m | ≥ 2,50 × 5,00 m | ✅ |
| S · places commandées | autorisées (1 logement) | sans objet | ✅ |
| Accès : une seule entrée charretière | 1 | 1 | ✅ |
| Accès : largeur de la bande roulante | 6,6 m | ≥ 3,5 m (≤ 2 logements) | ✅ |

**Conforme à toutes les règles contrôlées.**

## 05 · Maison et atelier — 1 logement(s), ≈ 223 m² de SDP brute

Maison R+1 serrée contre l'est et atelier de plain-pied au fond du jardin ; le retrait de 12 m est pris sur la limite ouest, qui garde une grande bande de jardin.

| Règle | Mesuré | Limite | |
|---|---|---|---|
| Volumes dans la parcelle | 0,0 m² hors parcelle | 0 m² | ✅ |
| V · Recul voie 5 m | 6,00 m | ≥ 5,00 m | ✅ |
| H · Hauteur 7 m / 3,5 m | M (≤ 25 m) : égout 6,0, faîtage 10,2 m | égout ≤ 7,0, faîtage ≤ 11,5 m | ✅ |
| H · Hauteur 7 m / 3,5 m | AT (> 25 m) : acrotère 3,8 m | acrotère ≤ 4,0 m | ✅ |
| L2 · laterale_1 : façades sans vues (M) | 3,20 m | ≥ 3,00 m (H/2 = 6,0/2, min. 2,5) | ✅ |
| L2 · laterale_1 : tout point (M) | 3,20 m | ≥ 3,00 m | ✅ |
| F8 · fond_2 : façades avec vues (M) | 29,16 m | ≥ 8,00 m | ✅ |
| F2 · fond_2 : tout point (M) | 29,16 m | ≥ 3,00 m | ✅ |
| L8 · laterale_3 : façades avec vues (M) | 13,02 m | ≥ 8,00 m | ✅ |
| L2 · laterale_3 : tout point (M) | 13,02 m | ≥ 3,00 m | ✅ |
| Pignon M face à fond_2 (lecture prudente : faîtage/2) | 29,16 m | ≥ 8,00 m | ✅ |
| L2 · laterale_1 : façades sans vues (AT) | 5,80 m | ≥ 2,50 m (H/2 = 3,8/2, min. 2,5) | ✅ |
| L2 · laterale_1 : tout point (AT) | 5,80 m | ≥ 2,50 m | ✅ |
| F2 · fond_2 : façades sans vues (AT) | 6,89 m | ≥ 2,50 m (H/2 = 3,8/2, min. 2,5) | ✅ |
| F2 · fond_2 : tout point (AT) | 6,89 m | ≥ 2,50 m | ✅ |
| L8 · laterale_3 : façades avec vues (AT) | 14,91 m | ≥ 8,00 m | ✅ |
| L2 · laterale_3 : tout point (AT) | 14,91 m | ≥ 2,50 m | ✅ |
| R12 · 12 m de laterale_3 (choix du projet) | 13,02 m | ≥ 12,00 m | ✅ |
| Implantation sur limite | aucune | 1 latérale au plus, bande 25 m | ✅ |
| Distance entre constructions, façades en vis-à-vis avec vues (M / AT) | 16,30 m | ≥ 16,00 m | ✅ |
| Distance entre constructions, en tout point (M / AT) | 16,30 m | ≥ 5,00 m | ✅ |
| E · Emprise 35 % | 146,0 m² (11,8 %) | ≤ 434,0 m² | ✅ |
| PT · Pleine terre 40 % | 1022,4 m² (82,5 %) | ≥ 495,9 m² | ✅ |
| S · places exigées / comptées | 4 comptées (2 ext. + 2 garage) | ≥ 4 exigées (4) | ✅ |
| S · places intégrées à la construction | 2 | ≥ 2 (50 %, arrondi inférieur) | ✅ |
| S · dimensions des places extérieures | 2,50 × 5,00 m | ≥ 2,50 × 5,00 m | ✅ |
| S · places commandées | autorisées (1 logement) | sans objet | ✅ |
| Accès : une seule entrée charretière | 1 | 1 | ✅ |
| Accès : largeur de la bande roulante | 5,5 m | ≥ 3,5 m (≤ 2 logements) | ✅ |

**Conforme à toutes les règles contrôlées.**

## 06 · Longère partagée — 2 logement(s), ≈ 178 m² de SDP brute

Une longère basse (rez-de-chaussée + combles, toit à 45°) parallèle à la rue, deux logements aux extrémités et une grange-garage au centre.

| Règle | Mesuré | Limite | |
|---|---|---|---|
| Volumes dans la parcelle | 0,0 m² hors parcelle | 0 m² | ✅ |
| V · Recul voie 5 m | 8,00 m | ≥ 5,00 m | ✅ |
| H · Hauteur 7 m / 3,5 m | L1 (≤ 25 m) : égout 4,2, faîtage 8,2 m | égout ≤ 7,0, faîtage ≤ 11,5 m | ✅ |
| H · Hauteur 7 m / 3,5 m | G (≤ 25 m) : égout 4,2, faîtage 8,2 m | égout ≤ 7,0, faîtage ≤ 11,5 m | ✅ |
| H · Hauteur 7 m / 3,5 m | L2 (≤ 25 m) : égout 4,2, faîtage 8,2 m | égout ≤ 7,0, faîtage ≤ 11,5 m | ✅ |
| L2 · laterale_1 : façades sans vues (L2+G+L1) | 4,18 m | ≥ 2,50 m (H/2 = 4,2/2, min. 2,5) | ✅ |
| L2 · laterale_1 : tout point (L2+G+L1) | 4,18 m | ≥ 2,50 m | ✅ |
| F8 · fond_2 : façades avec vues (L2+G+L1) | 30,18 m | ≥ 8,00 m | ✅ |
| F2 · fond_2 : tout point (L2+G+L1) | 30,18 m | ≥ 2,50 m | ✅ |
| L2 · laterale_3 : façades sans vues (L2+G+L1) | 4,55 m | ≥ 2,50 m (H/2 = 4,2/2, min. 2,5) | ✅ |
| L2 · laterale_3 : tout point (L2+G+L1) | 4,55 m | ≥ 2,50 m | ✅ |
| Pignon L2 face à laterale_1 (lecture prudente : faîtage/2) | 4,18 m | ≥ 4,10 m | ✅ |
| Pignon L1 face à laterale_3 (lecture prudente : faîtage/2) | 4,55 m | ≥ 4,10 m | ✅ |
| R12 · 12 m de fond_2 (choix du projet) | 30,18 m | ≥ 12,00 m | ✅ |
| Implantation sur limite | aucune | 1 latérale au plus, bande 25 m | ✅ |
| Distance entre constructions | 1 seule construction | sans objet | ✅ |
| E · Emprise 35 % | 140,8 m² (11,4 %) | ≤ 434,0 m² | ✅ |
| PT · Pleine terre 40 % | 968,7 m² (78,1 %) | ≥ 495,9 m² | ✅ |
| S · places exigées / comptées | 4 comptées (2 ext. + 2 garage) | ≥ 4 exigées (2 + 2) | ✅ |
| S · places intégrées à la construction | 2 | ≥ 2 (50 %, arrondi inférieur) | ✅ |
| S · dimensions des places extérieures | 2,50 × 5,00 m | ≥ 2,50 × 5,00 m | ✅ |
| S · places commandées (interdites dès 2 logements) | 0 place(s) sans accès direct | 0 | ✅ |
| Accès : une seule entrée charretière | 1 | 1 | ✅ |
| Accès : largeur de la bande roulante | 5,6 m | ≥ 3,5 m (≤ 2 logements) | ✅ |

**Conforme à toutes les règles contrôlées.**

## 07 · Maisons jumelées — 2 logement(s), ≈ 230 m² de SDP brute

Deux maisons R+1 accolées par un mur mitoyen, pignons sur rue et sur jardin, un garage intégré chacune.

| Règle | Mesuré | Limite | |
|---|---|---|---|
| Volumes dans la parcelle | 0,0 m² hors parcelle | 0 m² | ✅ |
| V · Recul voie 5 m | 8,50 m | ≥ 5,00 m | ✅ |
| H · Hauteur 7 m / 3,5 m | A (≤ 25 m) : égout 6,0, faîtage 8,9 m | égout ≤ 7,0, faîtage ≤ 11,5 m | ✅ |
| H · Hauteur 7 m / 3,5 m | B (≤ 25 m) : égout 6,0, faîtage 8,9 m | égout ≤ 7,0, faîtage ≤ 11,5 m | ✅ |
| L2 · laterale_1 : façades sans vues (B+A) | 7,30 m | ≥ 3,00 m (H/2 = 6,0/2, min. 2,5) | ✅ |
| L2 · laterale_1 : tout point (B+A) | 7,30 m | ≥ 3,00 m | ✅ |
| F8 · fond_2 : façades avec vues (B+A) | 28,23 m | ≥ 8,00 m | ✅ |
| F2 · fond_2 : tout point (B+A) | 28,23 m | ≥ 3,00 m | ✅ |
| L2 · laterale_3 : façades sans vues (B+A) | 5,00 m | ≥ 3,00 m (H/2 = 6,0/2, min. 2,5) | ✅ |
| L2 · laterale_3 : tout point (B+A) | 5,00 m | ≥ 3,00 m | ✅ |
| Pignon B face à fond_2 (lecture prudente : faîtage/2) | 28,23 m | ≥ 8,00 m | ✅ |
| Pignon A face à fond_2 (lecture prudente : faîtage/2) | 28,38 m | ≥ 8,00 m | ✅ |
| R12 · 12 m de fond_2 (choix du projet) | 28,23 m | ≥ 12,00 m | ✅ |
| Implantation sur limite | aucune | 1 latérale au plus, bande 25 m | ✅ |
| Distance entre constructions | 1 seule construction | sans objet | ✅ |
| E · Emprise 35 % | 133,0 m² (10,7 %) | ≤ 434,0 m² | ✅ |
| PT · Pleine terre 40 % | 979,9 m² (79,0 %) | ≥ 495,9 m² | ✅ |
| S · places exigées / comptées | 4 comptées (2 ext. + 2 garage) | ≥ 4 exigées (2 + 2) | ✅ |
| S · places intégrées à la construction | 2 | ≥ 2 (50 %, arrondi inférieur) | ✅ |
| S · dimensions des places extérieures | 2,50 × 5,00 m | ≥ 2,50 × 5,00 m | ✅ |
| S · places commandées (interdites dès 2 logements) | 0 place(s) sans accès direct | 0 | ✅ |
| Accès : une seule entrée charretière | 1 | 1 | ✅ |
| Accès : largeur de la bande roulante | 6,0 m | ≥ 3,5 m (≤ 2 logements) | ✅ |

**Conforme à toutes les règles contrôlées.**

## 08 · Maisons décalées — 2 logement(s), ≈ 218 m² de SDP brute

Deux maisons R+1 indépendantes, l'une sur rue à l'ouest, l'autre en second rang à l'est, décalées pour qu'aucune façade ne regarde l'autre ; une allée commune de 5 m entre les deux.

| Règle | Mesuré | Limite | |
|---|---|---|---|
| Volumes dans la parcelle | 0,0 m² hors parcelle | 0 m² | ✅ |
| V · Recul voie 5 m | 6,00 m | ≥ 5,00 m | ✅ |
| H · Hauteur 7 m / 3,5 m | A (≤ 25 m) : égout 6,0, faîtage 9,2 m | égout ≤ 7,0, faîtage ≤ 11,5 m | ✅ |
| H · Hauteur 7 m / 3,5 m | B (≤ 25 m) : égout 6,0, faîtage 8,9 m | égout ≤ 7,0, faîtage ≤ 11,5 m | ✅ |
| L8 · laterale_1 : façades avec vues (A) | 15,19 m | ≥ 8,00 m | ✅ |
| L2 · laterale_1 : tout point (A) | 15,19 m | ≥ 3,00 m | ✅ |
| F8 · fond_2 : façades avec vues (A) | 31,41 m | ≥ 8,00 m | ✅ |
| F2 · fond_2 : tout point (A) | 31,41 m | ≥ 3,00 m | ✅ |
| L2 · laterale_3 : façades sans vues (A) | 3,58 m | ≥ 3,00 m (H/2 = 6,0/2, min. 2,5) | ✅ |
| L2 · laterale_3 : tout point (A) | 3,58 m | ≥ 3,00 m | ✅ |
| Pignon A face à fond_2 (lecture prudente : faîtage/2) | 31,41 m | ≥ 8,00 m | ✅ |
| L2 · laterale_1 : façades sans vues (B) | 3,62 m | ≥ 3,00 m (H/2 = 6,0/2, min. 2,5) | ✅ |
| L2 · laterale_1 : tout point (B) | 3,62 m | ≥ 3,00 m | ✅ |
| F8 · fond_2 : façades avec vues (B) | 21,16 m | ≥ 8,00 m | ✅ |
| F2 · fond_2 : tout point (B) | 21,16 m | ≥ 3,00 m | ✅ |
| L8 · laterale_3 : façades avec vues (B) | 15,80 m | ≥ 8,00 m | ✅ |
| L2 · laterale_3 : tout point (B) | 15,80 m | ≥ 3,00 m | ✅ |
| Pignon B face à fond_2 (lecture prudente : faîtage/2) | 21,16 m | ≥ 8,00 m | ✅ |
| R12 · 12 m de fond_2 (choix du projet) | 21,16 m | ≥ 12,00 m | ✅ |
| Implantation sur limite | aucune | 1 latérale au plus, bande 25 m | ✅ |
| Distance entre constructions, en tout point (A / B) | 5,22 m | ≥ 5,00 m | ✅ |
| E · Emprise 35 % | 127,0 m² (10,2 %) | ≤ 434,0 m² | ✅ |
| PT · Pleine terre 40 % | 941,4 m² (75,9 %) | ≥ 495,9 m² | ✅ |
| S · places exigées / comptées | 4 comptées (2 ext. + 2 garage) | ≥ 4 exigées (2 + 2) | ✅ |
| S · places intégrées à la construction | 2 | ≥ 2 (50 %, arrondi inférieur) | ✅ |
| S · dimensions des places extérieures | 2,50 × 5,00 m | ≥ 2,50 × 5,00 m | ✅ |
| S · places commandées (interdites dès 2 logements) | 0 place(s) sans accès direct | 0 | ✅ |
| Accès : une seule entrée charretière | 1 | 1 | ✅ |
| Accès : largeur de la bande roulante | 5,0 m | ≥ 3,5 m (≤ 2 logements) | ✅ |

**Conforme à toutes les règles contrôlées.**

## 09 · Maisons en bande — 3 logement(s), ≈ 326 m² de SDP brute

Trois maisons R+1 en bande, pignons sur rue, garage intégré chacune ; une cour de stationnement commune devant, une seule entrée de 5 m.

| Règle | Mesuré | Limite | |
|---|---|---|---|
| Volumes dans la parcelle | 0,0 m² hors parcelle | 0 m² | ✅ |
| V · Recul voie 5 m | 11,00 m | ≥ 5,00 m | ✅ |
| H · Hauteur 7 m / 3,5 m | M1 (≤ 25 m) : égout 6,0, faîtage 8,7 m | égout ≤ 7,0, faîtage ≤ 11,5 m | ✅ |
| H · Hauteur 7 m / 3,5 m | M2 (≤ 25 m) : égout 6,0, faîtage 8,7 m | égout ≤ 7,0, faîtage ≤ 11,5 m | ✅ |
| H · Hauteur 7 m / 3,5 m | M3 (≤ 25 m) : égout 6,0, faîtage 8,7 m | égout ≤ 7,0, faîtage ≤ 11,5 m | ✅ |
| L2 · laterale_1 : façades sans vues (M3+M2+M1) | 3,90 m | ≥ 3,00 m (H/2 = 6,0/2, min. 2,5) | ✅ |
| L2 · laterale_1 : tout point (M3+M2+M1) | 3,90 m | ≥ 3,00 m | ✅ |
| F8 · fond_2 : façades avec vues (M3+M2+M1) | 25,17 m | ≥ 8,00 m | ✅ |
| F2 · fond_2 : tout point (M3+M2+M1) | 25,17 m | ≥ 3,00 m | ✅ |
| L2 · laterale_3 : façades sans vues (M3+M2+M1) | 3,42 m | ≥ 3,00 m (H/2 = 6,0/2, min. 2,5) | ✅ |
| L2 · laterale_3 : tout point (M3+M2+M1) | 3,42 m | ≥ 3,00 m | ✅ |
| Pignon M3 face à fond_2 (lecture prudente : faîtage/2) | 25,17 m | ≥ 8,00 m | ✅ |
| Pignon M2 face à fond_2 (lecture prudente : faîtage/2) | 25,29 m | ≥ 8,00 m | ✅ |
| Pignon M1 face à fond_2 (lecture prudente : faîtage/2) | 25,43 m | ≥ 8,00 m | ✅ |
| R12 · 12 m de fond_2 (choix du projet) | 25,17 m | ≥ 12,00 m | ✅ |
| Implantation sur limite | aucune | 1 latérale au plus, bande 25 m | ✅ |
| Distance entre constructions | 1 seule construction | sans objet | ✅ |
| E · Emprise 35 % | 190,0 m² (15,3 %) | ≤ 434,0 m² | ✅ |
| PT · Pleine terre 40 % | 822,9 m² (66,4 %) | ≥ 495,9 m² | ✅ |
| S · places exigées / comptées | 7 comptées (4 ext. + 3 garage) | ≥ 7 exigées (2 + 2 + 2 + 1) | ✅ |
| S · places intégrées à la construction | 3 | ≥ 3 (50 %, arrondi inférieur) | ✅ |
| S · dimensions des places extérieures | 2,50 × 5,00 m | ≥ 2,50 × 5,00 m | ✅ |
| S · places commandées (interdites dès 2 logements) | 0 place(s) sans accès direct | 0 | ✅ |
| Accès : une seule entrée charretière | 1 | 1 | ✅ |
| Accès : largeur de la bande roulante | 5,0 m | ≥ 5,0 m (> 2 logements) | ✅ |

**Conforme à toutes les règles contrôlées.**

## 10 · Petit collectif — 6 logement(s), ≈ 524 m² de SDP brute

Un petit immeuble R+1 à toit plat de six logements (trois par niveau, ≈ 78 m² chacun), parking de 12 places en sous-sol sous l'immeuble et la cour avant.

| Règle | Mesuré | Limite | |
|---|---|---|---|
| Volumes dans la parcelle | 0,0 m² hors parcelle | 0 m² | ✅ |
| V · Recul voie 5 m | 10,00 m | ≥ 5,00 m | ✅ |
| H · Hauteur 7 m / 3,5 m | C (≤ 25 m) : acrotère 6,6 m | acrotère ≤ 7,0 m | ✅ |
| L2 · laterale_1 : façades sans vues (C) | 3,86 m | ≥ 3,30 m (H/2 = 6,6/2, min. 2,5) | ✅ |
| L2 · laterale_1 : tout point (C) | 3,86 m | ≥ 3,30 m | ✅ |
| F8 · fond_2 : façades avec vues (C) | 22,17 m | ≥ 8,00 m | ✅ |
| F2 · fond_2 : tout point (C) | 22,17 m | ≥ 3,30 m | ✅ |
| L2 · laterale_3 : façades sans vues (C) | 3,63 m | ≥ 3,30 m (H/2 = 6,6/2, min. 2,5) | ✅ |
| L2 · laterale_3 : tout point (C) | 3,63 m | ≥ 3,30 m | ✅ |
| R12 · 12 m de fond_2 (choix du projet) | 22,17 m | ≥ 12,00 m | ✅ |
| Implantation sur limite | aucune | 1 latérale au plus, bande 25 m | ✅ |
| Distance entre constructions | 1 seule construction | sans objet | ✅ |
| E · Emprise 35 % | 261,8 m² (21,1 %) | ≤ 434,0 m² | ✅ |
| PT · Pleine terre 40 % | 793,5 m² (64,0 %) | ≥ 495,9 m² | ✅ |
| S · places exigées / comptées | 15 comptées (0 ext. + 0 garage + 12 s.-sol × 1,25) | ≥ 14 exigées (2 + 2 + 2 + 2 + 2 + 2 + 2) | ✅ |
| S · places intégrées à la construction | 12 | ≥ 7 (50 %, arrondi inférieur) | ✅ |
| S · places commandées (interdites dès 2 logements) | 0 place(s) sans accès direct | 0 | ✅ |
| Accès : une seule entrée charretière | 1 | 1 | ✅ |
| Accès : largeur de la bande roulante | 5,0 m | ≥ 5,0 m (> 2 logements) | ✅ |

**Conforme à toutes les règles contrôlées.**

---

## Règles contrôlées : citations

Règlement du PLU de Palaiseau (modification approuvée le 24 mars 2025), zone UR, secteur UR1. Pages du PDF `reglement.pdf`.

### Reprises de `regles.json`

- **V — Recul sur la voie** (zone UR, chap. 2, 1/C, p. 139) : « Toute nouvelle construction devra être implantée en retrait de la voie existante ouverte à la circulation à la date d’approbation du présent règlement, avec une distance minimum de 5 mètres. »
- **H — Hauteur selon la bande** (zone UR, chap. 2, 1/B, p. 138) : « Dans la bande des 25 mètres comptée à partir de la limite de voirie : - 7 mètres à l’égout du toit ou l’acrotère pour les toitures terrasses, - 11,50 mètres au faîtage. Au-delà de la limite de 25 mètres comptée à partir de la limite de voirie : - 3,5 mètres à l’égout du toit ou 4 mètres à l’acrotère pour les toitures terrasses, - 7 mètres au faîtage ». Un volume qui touche la bande au-delà de 25 m est contrôlé en entier avec les limites de cette bande.
- **L8 / F8 — Façades avec vues** (1/D, p. 142) : « En cas d’implantation en retrait de la limite séparative, la distance doit être au moins égale à : - 8 mètres si la façade en vis-à-vis de la limite séparative comporte des ouvertures créant des vues ».
- **L2 / F2 — Façades sans vues** (1/D, p. 143) : « la moitié de la hauteur à l'égout du toit le plus haut, avec un minimum de 2,5 mètres si la façade en vis-à-vis de la limite séparative ne comporte pas d’ouvertures créant des vues au sens du présent règlement. » La hauteur prise est l'égout (ou l'acrotère) le plus haut de la construction entière.
- **R12 — 12 m d'une limite au choix** (1/D, p. 143) : « Par ailleurs, les constructions principales doivent être implantées, en tout point de la construction, en retrait avec un minimum de 12 mètres de l’une des limites séparatives (au choix : latérale ou fond de parcelle). »
- **E — Emprise au sol** (1/A, p. 138) : « L’emprise au sol maximale des constructions est fixée à 35 % de la superficie de l’unité foncière. » Définition (p. 308) : « L'emprise au sol est la projection verticale du volume de la construction, tous débords et surplombs inclus. »
- **PT — Pleine terre** (chap. 2, 3, p. 150) : « Dans la zone UR1, une part de 40 % minimum de la superficie de l’unité foncière doit être conservée en espace vert de pleine terre. » Définition (p. 309) : « n’entre pas dans la définition de la pleine terre les espaces de terrasses, accès piétons, piscines et abords, circulation et stationnement des véhicules quel que soit le traitement ». Le sous-sol et la rampe du projet 10 sont donc déduits.
- **S — Stationnement** (chap. 2, 4/A, p. 151) : « 1 place de stationnement par tranche consommée de 60 m² de surface de plancher (exemple : obligation de stationnement pour un logement de : 40 m² SDP = 1 place ; 70 m² SDP = 2 places ; 120 m² SDP = 3 places) », soit ⌊SDP/60⌋ + 1 par logement.

### Ajoutées après relecture du chapitre UR

- **Implantation sur une limite latérale** (1/D, p. 141) : « Dans une bande de 25 mètres comptée à partir de l’alignement : Les constructions peuvent être implantées sur l’une des limites séparatives latérales au maximum. » et « La longueur de la construction principale implantée sur la limite séparative ne peut excéder 10 mètres. Au-delà de ces 10 mètres un prolongement des murs existants est autorisé à condition : - que la longueur du prolongement n’excède pas 4 mètres - que la hauteur du prolongement sur la limite séparative soit inférieure ou égale à 4 mètres. »
- **Au-delà de 25 m, sur limite** (1/D, p. 142) : « Seules les constructions à usage de garages et les constructions annexes peuvent être implantées en limite séparative. La longueur de la construction à usage de garage implantée sur la limite séparative ne peut excéder 6 mètres, et la hauteur de peut excéder 3 mètres au point le plus haut. » Aucun projet n'en use.
- **Distance entre deux constructions sur le même terrain** (1/E, p. 145) : « Lorsque deux constructions, implantées sur une même unité foncière, ne sont pas contiguës, la distance mesurée en tout point séparant les façades en vis à vis de ces deux constructions doit être au moins égale à : - 5 mètres si aucune des façades en vis-à-vis ne comporte des ouvertures créant des vues directes, - 16 mètres dès lors qu’une façade en vis-à-vis comporte des ouvertures créant des vues directes. » et « Il n’est pas fixé de règle entre une construction principale et une construction annexe, ainsi qu’entre les constructions annexes. » Le contrôle ajoute, par prudence, 5 m en tout point même sans vis-à-vis.
- **Annexes** (Définitions, p. 305) : « Est considéré comme bâtiment annexe, une construction qui répond aux conditions ci-après : - une construction non affectée à l’habitation ou à l’activité, à usage de garage, abri de jardin, remise à bois, chaufferie, etc. - une construction non contiguë à une construction principale. » L'atelier du projet 05 n'est donc **pas** traité comme une annexe : il respecte toutes les règles d'une construction.
- **Garages dans la bande de 5 m** (1/C, p. 140) : « Dans la bande de 5 mètres comptée à partir de la limite de voirie, la construction de garages est autorisée à l’alignement ou à la limite qui s’y substitue, sous réserve que l’emprise au sol correspondante soit inférieure à 20% de la surface de la bande considérée. » Aucun projet n'en use.
- **Annexes de 10 m²** (1/B p. 139 et 1/D p. 144) : « Les constructions annexes limitées à 10 m² d’emprise au sol et dont la hauteur est limitée à 2,50 mètres au point le plus haut peuvent être implantées de manière libre sur les alignements ou en retrait. » Aucun projet n'en dessine.
- **Façade, pignon** (Définitions, p. 309) : « Une façade est un mur extérieur délimitant l’enveloppe d’une construction à partir du sol existant jusqu’à l’égout du toit ou l’acrotère. Un pignon constitue une façade. » D'où la ligne « Pignon (lecture prudente) » : la distance d'un pignon aveugle à la limite qu'il regarde est aussi contrôlée contre la moitié du faîtage.
- **Vues** (Définitions, p. 311) : « Ne sont pas considérés comme constituant des vues directes au sens du présent règlement : - Les portes pleines, - Les châssis fixes et verre translucide, - Les pavés de verre, - Les baies (hors porte pleine) d’une dimension inférieure à 0,5 m² limitées au nombre de 2 maximum par façade. »
- **Places intégrées** (4/A, p. 151) : « 50 % au minimum des places de stationnement exigées doivent être intégrées à la construction. Le calcul se fera en arrondissant au nombre entier inférieur (exemple : pour 3 places exigées, une devra être intégrée à la construction). »
- **Sous-sol** (4/A, p. 151) : « Les places de stationnement réalisées en sous-sol de la construction seront comptées pour 1,25 place au titre des places exigées selon les normes définies ci-dessus. Le calcul se fera en arrondissant au nombre entier le plus proche. »
- **Opérations de 3 logements et plus** (4/A, p. 151) : « la réalisation de places supplémentaires est imposée pour des opérations portant le nombre de logements à 3 et plus. Dans ce cas, il doit être créé au moins 1 place de stationnement supplémentaire par tranche de 3 logements. Le nombre de places est arrondi au nombre entier supérieur. »
- **Places commandées** (4/A, p. 152) : « Pour les constructions comprenant plusieurs logements, les places commandées sont interdites. » Définition (p. 311) : « une place commandée est une place qui n’est pas accessible directement depuis la voie de desserte mais en passant par une autre place de stationnement. »
- **Dimensions des places** (Dispositions générales, p. 7) : « Les places de stationnement doivent avoir une dimension minimale de 2,50 m x 5 m. »
- **Desserte** (chap. 3, p. 157) : « Etre dotées d’une bande roulante d’une largeur minimale de: o 3, 50 m pour les voiries desservant deux logements au plus et les voies à sens unique o 5 m pour les voiries desservant plus de deux logements. » et « La création de plusieurs entrées charretières sur une même unité foncière est interdite à l’exception : - Des opérations de logements collectifs, à partir du seuil de 10 logements ».
- **Division** (chap. 2, p. 138) : « dans le cas d’un lotissement ou dans celui de la construction, sur le même terrain, d’un ou plusieurs bâtiments dont le terrain d’assiette doit faire l’objet d’une division en propriété ou en jouissance, les règles édictées au présent article sont appréciées au regard de chacun des lots. » Non contrôlé : tous les projets sont supposés sans division (un seul propriétaire ou copropriété sans jouissance privative). Avec une division, chaque lot devrait passer toutes les règles seul.
