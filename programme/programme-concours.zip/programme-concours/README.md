# programme-concours : installation

Ce dossier est un « skill » pour Claude : il lui apprend à lire le programme d'un concours ou d'un projet (PDF), à
en faire un tableau de surfaces Excel contrôlé, et à le montrer en blocs 3D à l'échelle.

## Dans Claude Code (ordinateur)

1. Copie le dossier `programme-concours` entier dans `~/.claude/skills/` (sous Windows :
   `C:\Users\<toi>\.claude\skills\`). Tu dois obtenir `~/.claude/skills/programme-concours/SKILL.md`.
2. Ouvre Claude Code dans le dossier où se trouve ton PDF et écris par exemple :
   « Voici le programme du concours : programme.pdf. Fais-moi le tableau de surfaces et la 3D. »
3. Il faut Python avec `openpyxl`, `pymupdf`, `pillow` et `numpy` (`pip install openpyxl pymupdf pillow numpy`), et
   ffmpeg si tu veux les vidéos ; Claude te le dira s'il en manque un.
4. Tu peux aussi le lancer par la commande : `/programme-concours programme.pdf`.

## Dans Claude.ai (navigateur ou application)

1. Compresse le dossier `programme-concours` en `.zip` (le dossier lui-même doit être dans le zip).
2. Dans Claude.ai : Réglages → Capacités → active l'exécution de code, puis Skills → « Importer un skill » → choisis
   le zip.
3. Dans une conversation, joins ton PDF et demande : « Fais-moi le tableau de surfaces et le programme en 3D. »
   Télécharge ensuite `surfaces.xlsx`, `programme-3d.html` et les images `01` à `05`.

## Ce qu'il faut savoir

- La 3D s'ouvre d'un double-clic dans Chrome, Edge, Safari ou Firefox ; elle a besoin d'internet pour charger
  Three.js.
- Le classeur recalcule tout : change le coefficient dans l'onglet « Hypothèses » et toutes les SDO suivent.
- Le skill ne devine aucun chiffre : ce que le programme ne donne pas reste vide ou est marqué « hypothèse ». Lis
  l'onglet « À vérifier » avant de dessiner.
- Un PDF scanné (image) ne se lit pas : demande la version texte ou Excel du programme.
- Les blocs ont la vraie surface de chaque local, mais leur forme et leur hauteur servent à la lecture : ce n'est pas
  un plan.
