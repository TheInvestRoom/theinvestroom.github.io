---
name: programme-concours
description: Transforme le programme d'un concours ou d'un projet d'architecture (PDF de programme technique détaillé, programme fonctionnel, cahier des charges d'atelier) en un tableau de surfaces Excel aux formules vivantes, contrôlé contre les totaux du programme, avec la liste de ce qu'il faut vérifier, en une maquette 3D HTML où chaque local est un bloc à l'échelle, regroupé par entité et par niveau, cliquable, et en cinq images plein cadre (tableau contrôlé, programme éclaté, empilé, liaisons, contraintes) avec leur vidéo de 3 s. Se lance aussi par /programme-concours <fichier.pdf>. À charger dès qu'on te donne un programme (PTD, programme de concours, programme d'atelier, tableau de surfaces) et qu'on veut le tableau de surfaces, la synthèse, les contraintes, les liaisons ou « le programme en volumes ».
argument-hint: "[programme.pdf]"
---

# Programme de concours → tableau de surfaces + programme en blocs 3D

Un programme de concours fait souvent 50 à 150 pages. Le tableau de surfaces y est coupé sur plusieurs pages, les
colonnes servent parfois à autre chose que leur titre, les sous-totaux se mêlent aux locaux, et les exigences qui
comptent pour le plan (niveaux, liaisons, ratios) sont dispersées dans le texte. L'architecte passe des heures à
retaper ce tableau, et une ligne oubliée se paie au rendu : le jury vérifie les surfaces.

Programme donné : $ARGUMENTS (si c'est vide, prends le PDF de programme du dossier courant ; s'il y en a plusieurs,
demande lequel). Écris les sorties dans un dossier `programme-<nom court>/` à côté du PDF.

Ce skill rend quatre choses :
1. **`surfaces.xlsx`** : une ligne par local, SU = unitaire × nombre **en formule**, totaux par entité recalculés
   (SUMIFS), comparés aux totaux écrits dans le programme, coefficient SDO/SU dans une cellule nommée, onglet
   « À vérifier » (chaque ambiguïté avec sa page), onglet « Contraintes et rendus ».
2. **`programme-3d.html`** : un bloc par local à sa vraie surface, couleur par entité, vue « éclatée » (le programme
   rangé par entité, extérieurs à côté) et vue « empilée » (les entités posées à leur niveau, bande des circulations
   en blanc), clic = fiche du local (surface, règle, exigences, liaisons, page).
3. **Cinq images 1080 × 1920** (`01-surfaces` à `05-contraintes`, PNG, plus une vidéo MP4 de 3 s chacune si ffmpeg
   est là) : de quoi montrer le résultat sur un téléphone, en réunion ou dans une présentation, sans ouvrir Excel.
4. **Un résumé dans la conversation** : totaux, écarts trouvés, les 5 points à vérifier les plus lourds, les
   contraintes qui dessinent le plan.

Le travail de jugement (lire le programme) est le tien ; le travail mécanique (formules, contrôle, 3D) est fait par
`scripts/construire.py`, à partir d'un fichier `programme.json` que tu écris. **Pourquoi ce partage :** un tableau
Excel écrit à la main par un modèle finit avec des valeurs figées et des totaux faux qu'on ne voit pas ; une 3D
réécrite à chaque fois varie en qualité. Le script garantit que chaque surface est une formule, que chaque total du
programme est recalculé et que la maquette lit exactement les mêmes chiffres que l'Excel.

## Le principe qui tient tout : chaque chiffre doit pouvoir être retrouvé

Le seul moyen de prouver qu'on n'a rien perdu en route est de **retrouver les totaux écrits dans le programme à partir
des lignes**. Si la somme de tes lignes redonne le sous-total de la maternelle, du restaurant et le total général, ta
lecture est juste. Si elle ne le redonne pas, il y a soit une ligne mal lue (à corriger), soit une erreur du programme
(à signaler, jamais à « arranger »). C'est pour ça que `programme.json` contient les totaux écrits, à côté des lignes,
et que le script les contrôle.

Corollaire : **aucun chiffre ne vient de toi.** Un coefficient SU→SDO « habituel », une hauteur sous plafond
« standard », une surface pour un local marqué « à définir » : si le programme ne le donne pas, la case reste vide ou
l'hypothèse est écrite comme telle (statut « hypothèse », cellule jaune) et demandée à l'utilisateur. Un tableau de
surfaces avec un chiffre inventé est pire qu'un tableau incomplet, parce qu'il a l'air juste.

## Lire le programme

Les pièges réels et leur parade sont détaillés dans `references/lire-un-programme.md` (à lire avant le premier
programme). L'essentiel :

- **Extraire le texte avec les numéros de page.** Chaque ligne du JSON porte sa page : c'est ce qui permet à
  l'utilisateur de vérifier en dix secondes, et à toi de revenir au bon endroit. Avec Python :
  `pymupdf` (`page.get_text()`) ou `pdfplumber`. Un PDF scanné ne donne pas de texte : dis-le et demande une version
  texte ou Excel plutôt que de deviner à partir d'une image floue.
- **Le tableau de surfaces se lit comme un calcul, pas comme du texte.** À l'extraction, chaque cellule devient une
  ligne ; repère l'ordre des colonnes dans l'en-tête et reconstruis chaque ligne (code, nom, unitaire, nombre, total,
  observation). Recalcule unitaire × nombre et compare au total de la ligne : si ça ne tombe pas juste, tu as décalé
  une colonne.
- **Une ligne de sous-total n'est pas un local.** « Sous total », « Total locaux… », « Total espace ext. » vont dans
  `totaux`, pas dans `locaux`. Les compter deux fois est l'erreur la plus fréquente.
- **Les colonnes sont parfois détournées.** Cas typique : « Sanitaires enfants | 120,00 | 0,30 | 36,00 », avec
  l'observation « 0,3 m² par enfant ». La colonne « besoin par local » contient l'effectif, la colonne « nombre » le
  ratio. On garde le calcul (120 × 0,30 = 36) et on écrit la règle dans `regle` ; dans la 3D, c'est un seul bloc de
  36 m², pas 0,3 local.
- **Les lignes à zéro, « inclus dans… », « à définir », « suivant projet » restent dans le tableau** (surface 0 ou
  vide) et vont dans « À vérifier ». Les supprimer fait disparaître une exigence ; leur donner une surface en invente
  une.
- **Un code de fiche n'est pas une clé unique.** Un même code (par exemple les sanitaires adultes) peut revenir dans
  trois entités, et deux locaux différents peuvent partager un code par erreur. Identifie un local par entité + nom.
- **Intérieur et extérieur ne s'additionnent pas.** Cours, préaux, jardins, parkings : `exterieur: true`. Ils ont
  leur propre total ; les mêler à la SU fausse la SDO et la maquette.

## Les surfaces et le coefficient

SU, SDO, SDP et « surface bâtie » ne mesurent pas la même chose : la SDO ajoute à la SU les circulations, les gaines
et les locaux techniques ; la SDP (art. R.112-2 du Code de l'urbanisme) se mesure au nu intérieur des façades. Reprends
**la définition donnée par le programme** (souvent en glossaire au début) et écris-la dans le résumé.

Le coefficient SDO/SU n'entre dans le classeur que s'il vient du programme (statut `programme`, avec la page) ou de
l'utilisateur (statut `hypothese`). Quand le programme en donne deux (un ratio dans l'en-tête du tableau, un objectif
différent dans le texte), utilise celui qui **reproduit les totaux du tableau**, et signale l'autre dans « À vérifier »
avec son effet en m² : c'est une vraie question à poser au maître d'ouvrage, et une information de conception (un
objectif plus serré veut dire moins de couloirs).

Les chiffres ronds de l'introduction (« environ 1 800 m² de SU », « 2 500 m² de surface bâtie ») ne sont pas des totaux
de contrôle : compare-les quand même et note l'écart, mais ne corrige pas le tableau pour les rejoindre.

## Niveaux, liaisons, contraintes

- **Niveau** : seulement ce que le texte dit, cité entre guillemets avec la page, et son statut : `impose`
  (« doit être au rez-de-chaussée »), `souhaite` (« autant que faire se peut », « de préférence »), `recommande`, ou
  `libre`. La nuance compte : un concurrent qui traite un souhait comme une obligation se prive d'une option. Dans la
  3D, une entité libre est posée au rez-de-chaussée par défaut et l'utilisateur la monte ou la descend avec ▲▼.
- **Liaisons** : uniquement les liaisons écrites (« accès direct », « à proximité », « liaison visuelle »,
  « contiguë »), avec la nature dans `note`. Une liaison déduite (« la cuisine est forcément près du restaurant »)
  n'est pas une exigence du programme ; si elle te semble importante, mets-la dans « À vérifier ».
- **Contraintes** : celles qui dessinent le plan ou le dossier. Effectifs, surface et forme du site, part de sol
  perméable, compacité, ratio de circulations, mode constructif, phasage en site occupé, accès séparés, hauteurs.
  Une contrainte par ligne, avec la page.
- **Pièces à rendre et dates** : elles sont souvent dans le règlement de la consultation, pas dans le programme. Si
  le document n'en parle pas, écris-le (« rien dans ce document ») au lieu de reprendre une liste type.

## Écrire `programme.json` puis construire

Le format complet, champ par champ, avec un exemple, est dans `references/format-programme-json.md`. Puis :

```
python scripts/construire.py programme.json dossier_de_sortie
```

Le script affiche le contrôle des totaux (SU, et SDO quand le programme en écrit), puis écrit `surfaces.xlsx` et
`programme-3d.html`. **Ne livre pas tant
qu'un écart n'est pas expliqué.** Pour chaque « ÉCART » : relis la page ; si c'est ta lecture, corrige le JSON ; si
c'est le programme (une ligne dont l'observation contredit la valeur, un sous-total qui ne tombe pas juste), garde le chiffre écrit au programme et ajoute une entrée « À vérifier » qui donne les deux valeurs et l'écart
en m². Un écart expliqué est une information précieuse ; un écart caché est une faute.

Sans Python (rare) : livre le JSON et le tableau en Markdown, et dis que l'Excel et la 3D demandent l'exécution de
code.

## Les images plein cadre

```
python scripts/images.py programme.json dossier_de_sortie
```

`01-surfaces` (chaque total du programme recalculé, ✓ ou ✗, et les erreurs de SDO du programme en rouge),
`02-eclate` (un bloc par local, rangés par entité, cours et préaux à côté), `03-empile` (entités posées à leur niveau,
circulations en blanc), `04-liaisons` (les liaisons écrites, en arcs), `05-contraintes` (cartes avec page, puis
pièces à rendre). Chaque image a sa vidéo de 3 s où le dessin se construit ; la dernière image est tenue.

Le dessin 3D est calculé en Python (axonométrie, faces cachées par tampon de profondeur, contours nets) : pas de
navigateur, pas de générateur d'images, le même rendu partout. **Ouvre chaque PNG et regarde-le** avant de le donner :
un texte coupé, une étiquette posée sur une autre ou une contrainte tronquée au milieu d'un mot se voient tout de
suite à l'œil, jamais dans le code. Si une contrainte est coupée, c'est qu'elle est trop longue : raccourcis son
`texte` dans le JSON (une idée, une vingtaine de mots) et mets le reste dans `detail`.

## Ce que tu dis à la fin

Court, dans l'ordre où l'architecte en a besoin :
1. Les totaux (SU intérieure, extérieurs, SDO selon le coefficient et sa source) et le contrôle (« 9 totaux du
   programme sur 9 retrouvés »).
2. Les écarts et contradictions du programme, chiffrés.
3. Les points « À vérifier » d'impact fort.
4. Les 5 à 8 contraintes qui pèsent sur le plan.
5. Les deux fichiers, et comment ouvrir la 3D (double-clic, navigateur récent, connexion internet pour Three.js).

Pas d'avis sur le projet à faire : le skill lit un programme, il ne conçoit pas. La vue empilée montre un ordre de
grandeur (emprise, nombre de niveaux, poids des circulations), pas une implantation ; le pied de page de la 3D le dit.

## Réglages de la 3D (paramètres d'URL)

`?mode=empile` ouvre directement la vue empilée · `?liens` affiche les liaisons · `?tourne` fait tourner la caméra ·
`?auto=4500` alterne éclaté et empilé toutes les 4,5 s · `?h=3.5` change la hauteur de lecture des blocs ·
`?propre` cache les boutons (pour une capture) · `?instant` saute l'animation d'ouverture.

## Fichiers

- `references/lire-un-programme.md` : les pièges de lecture, avec des cas réels et ce qu'on en fait.
- `references/format-programme-json.md` : le format du fichier intermédiaire, champ par champ.
- `scripts/construire.py` : contrôle des totaux, Excel à formules, page 3D.
- `scripts/gabarit-3d.html` : la page 3D (Three.js par CDN), remplie par le script.
- `scripts/images.py` : les cinq images 1080 × 1920 et leurs vidéos (Pillow, numpy, ffmpeg facultatif).
