# Format de `programme.json`

C'est le seul fichier que tu écris à la main. `scripts/construire.py` en tire l'Excel et la 3D. Tous les nombres
sont en m², avec un point décimal (75.83, pas « 75,83 »). Chaque élément qui vient du programme porte sa `page`.

```json
{
  "projet": {
    "nom": "Groupe scolaire du Parc · programme",
    "lieu": "Commune (département)",
    "maitre_ouvrage": "Ville de …",
    "document": "PTD version 2, nom-du-fichier.pdf",
    "effectifs": "4 classes maternelles (100 enfants), 6 classes élémentaires (150 enfants)",
    "definitions": "SU : … (p. 4) · SDO = SU + circulations + gaines + locaux techniques (p. 4)"
  },

  "coefficients": [
    { "id": "sdo_su", "nom": "Coefficient SDO / SU", "valeur": 1.3, "statut": "programme",
      "source": "p. 36, en-tête du tableau des surfaces", "note": "Le chapitre des enjeux (p. 9) vise un autre ratio : voir À vérifier" }
  ],

  "entites": [
    { "id": "MAT", "nom": "Maternelle", "niveau": 0, "niveau_statut": "impose",
      "niveau_source": "p. 9 : « les locaux maternelle seront impérativement de plain-pied »" },
    { "id": "ELE", "nom": "Élémentaire", "niveau": "libre", "niveau_statut": "libre" },
    { "id": "RES", "nom": "Restauration", "niveau": 0, "niveau_statut": "souhaite",
      "niveau_source": "p. 10 : « de préférence en rez-de-chaussée, près de l'aire de livraison »" }
  ],

  "locaux": [
    { "code": "M-02", "nom": "Salle de classe", "entite": "MAT", "groupe": "Enseignement",
      "unitaire": 64, "nombre": 4, "su_annoncee": 256,
      "regle": "", "exigences": "Point d'eau, rangements intégrés ; accès direct à la cour",
      "liaisons": [ { "vers": "M-05", "note": "sanitaires contigus" }, { "vers": "M-20", "note": "accès direct à la cour" } ],
      "page": 36 },
    { "code": "M-05", "nom": "Sanitaires enfants", "entite": "MAT", "groupe": "Enseignement",
      "unitaire": 100, "nombre": 0.3, "su_annoncee": 30, "blocs": 1,
      "regle": "0,3 m² par enfant × 100 enfants (colonnes utilisées pour effectif et ratio)", "page": 36 },
    { "code": "M-20", "nom": "Cour maternelle", "entite": "MAT", "groupe": "Espaces extérieurs",
      "unitaire": 150, "nombre": 4, "su_annoncee": 600, "exterieur": true, "regle": "150 m² par classe", "page": 36 }
  ],

  "totaux": [
    { "portee": "groupe", "entite": "MAT", "groupe": "Enseignement", "su": 286, "sdo": 371.8, "page": 36 },
    { "portee": "entite", "entite": "MAT", "filtre": "interieur", "su": 286, "page": 36,
      "libelle": "Total maternelle" },
    { "portee": "global", "filtre": "interieur", "su": 1480, "sdo": 1924, "page": 38, "libelle": "Total bâtiment" }
  ],

  "a_verifier": [
    { "impact": "fort", "sujet": "Deux ratios SDO/SU",
      "detail": "Le tableau applique 1,30 (p. 36) ; les enjeux visent 1,25 (p. 9). Avec 1,25, la SDO baisse de 74 m² (1 480 × 0,05).",
      "lecture": "Classeur à 1,30 pour retrouver les totaux du tableau ; changer Hypothèses!B5 pour tester 1,25.",
      "page": "9, 36" }
  ],

  "contraintes": [ { "theme": "Site", "texte": "Terrain de 5 200 m², dont 1 200 m² de parking existant à conserver", "page": 12 } ],
  "rendus": [],
  "dates": [],
  "hauteur_lecture": 3.0
}
```

## Champ par champ, et pourquoi

**`entites`** : les grandes parties qui ont leur sous-total (maternelle, élémentaire, restauration, locaux partagés,
technique…). Ce sont les couleurs de la 3D et les lignes de la synthèse : en avoir 4 à 8 garde la vue lisible.
`niveau` vaut 0 (RDC), 1 (R+1)… ou `"libre"` ; `niveau_statut` : `impose`, `souhaite`, `recommande`, `libre`.
`couleur` est facultatif (une palette douce est appliquée).

**`locaux`** : une ligne par ligne du tableau, dans l'ordre du programme (l'architecte compare avec son PDF).
- `groupe` : le sous-ensemble du tableau (« Locaux pédagogiques », « Locaux mutualisés avec l'extra-scolaire »,
  « Espaces extérieurs »). Il doit être écrit **à l'identique** dans les totaux de portée `groupe`.
- `unitaire`, `nombre` : tels qu'écrits. La SU est toujours recalculée (formule Excel), jamais recopiée.
- `su_annoncee` : le total écrit sur la ligne, pour que l'Excel montre un éventuel écart ligne à ligne. Mettre
  `null` si la ligne n'en a pas.
- `exterieur` : `true` pour cours, préaux, jardins, abris extérieurs. Ils sont exclus de la SDO et posés à plat dans
  la 3D.
- `blocs` : facultatif. Par défaut la 3D fait un bloc par local quand `nombre` est un entier ≥ 1 et `unitaire` ≥ 4 m²,
  sinon un seul bloc. Forcer `1` pour les lignes en ratio, ou un autre nombre si le programme précise la répartition
  (« 1 par niveau »).
- `niveau` : facultatif, pour un local qui n'a pas le niveau de son entité.
- `liaisons` : codes d'autres lignes (`"C-2"` ou `{ "vers": "C-2", "note": "accès direct" }`). Si un code existe dans
  plusieurs entités, la 3D relie d'abord celui de la même entité.
- Surface nulle (« inclus dans… ») : `unitaire` tel qu'écrit, `nombre` 0. La ligne reste dans l'Excel, pas dans la 3D.

**`totaux`** : chaque total écrit dans le programme, recopié tel quel, avec sa portée :
- `{"portee": "groupe", "entite": "MAT", "groupe": "…"}` : un sous-total d'un groupe ;
- `{"portee": "entite", "entite": "MAT", "filtre": "interieur"}` : toute l'entité (filtre facultatif) ;
- `{"portee": "global", "filtre": "interieur" | "exterieur"}` ou sans filtre : le général.
`libelle` reprend le libellé du programme. `sdo` est facultatif (s'il est écrit).

**`a_verifier`** : chaque ambiguïté ou contradiction : `impact` (`fort`, `moyen`, `faible`), `sujet`, `detail` (les deux
valeurs, les pages, l'effet en m² quand on peut le calculer), `lecture` (ce que le classeur a retenu), `page`.

**`contraintes`, `rendus`, `dates`** : listes de `{ "theme", "texte", "page", "detail" }`. `texte` est **court**
(une idée, une vingtaine de mots) : c'est lui qui va sur l'image 05 ; les précisions vont dans `detail` (Excel
seulement). Un `theme` par sujet (Site, Niveaux, Morphologie, Sol perméable, Orientation, Construction, Phasage…). Laisser `rendus` vide si le document
n'en parle pas : l'Excel l'écrira.

**`hauteur_lecture`** : la hauteur unique des blocs dans la 3D. C'est un réglage d'affichage (le pied de page le dit),
pas une hauteur sous plafond. Si le programme donne des hauteurs, elles vont dans `exigences`.
