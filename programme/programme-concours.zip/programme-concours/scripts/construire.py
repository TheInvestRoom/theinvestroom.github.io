# -*- coding: utf-8 -*-
"""
Construit, à partir d'un programme.json (voir references/format-programme-json.md) :
  - surfaces.xlsx      : tableau de surfaces avec formules vivantes, synthèse contrôlée, points à vérifier ;
  - programme-3d.html  : le programme en blocs 3D à l'échelle (un bloc par local), cliquable ;
et affiche dans la console le contrôle des totaux (somme retrouvée contre total annoncé).

Usage : python construire.py programme.json dossier_de_sortie
Dépendance : openpyxl (présent dans Claude.ai et dans la plupart des installations Python).
"""
import json, math, os, sys
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.formatting.rule import CellIsRule, FormulaRule
from openpyxl.utils import get_column_letter
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.worksheet.table import Table, TableStyleInfo

ICI = os.path.dirname(os.path.abspath(__file__))
PALETTE = ["#7C9CC9", "#E3A36F", "#8DBF9A", "#C99AC4", "#E6C86E", "#86C2C2", "#D98C8C", "#A7A7D6", "#B9B08F", "#9FBF6F"]
TOL = 0.05  # m² : en dessous, l'écart est un arrondi d'affichage, pas une erreur

ENCRE = "2A2622"
FOND_TITRE = PatternFill("solid", fgColor="2A2622")
JAUNE = PatternFill("solid", fgColor="FFF2B3")
ROUGE = PatternFill("solid", fgColor="F6C9C4")
VERT = PatternFill("solid", fgColor="D5EBD6")
GRIS = PatternFill("solid", fgColor="EFECE6")
FIN = Side(style="thin", color="D9D3C7")
CADRE = Border(top=FIN, bottom=FIN, left=FIN, right=FIN)


def charger(chemin):
    with open(chemin, encoding="utf-8") as f:
        d = json.load(f)
    d.setdefault("coefficients", [])
    d.setdefault("totaux", [])
    d.setdefault("a_verifier", [])
    d.setdefault("contraintes", [])
    d.setdefault("rendus", [])
    d.setdefault("dates", [])
    ents = {e["id"]: e for e in d["entites"]}
    for i, e in enumerate(d["entites"]):
        e.setdefault("couleur", PALETTE[i % len(PALETTE)])
        e.setdefault("niveau", "libre")
        e.setdefault("niveau_statut", "libre")
    for l in d["locaux"]:
        if l["entite"] not in ents:
            raise SystemExit(f"Local {l.get('code')} {l['nom']} : entité inconnue « {l['entite']} »")
        l.setdefault("code", "")
        l.setdefault("groupe", "")
        l.setdefault("exterieur", False)
        l.setdefault("regle", "")
        l.setdefault("exigences", "")
        l.setdefault("liaisons", [])
        l.setdefault("page", "")
        l["su"] = round(float(l["unitaire"]) * float(l["nombre"]), 4)
    return d, ents


def coef(d, cid):
    for c in d["coefficients"]:
        if c["id"] == cid:
            return c
    return None


# ---------------------------------------------------------------- contrôle (même calcul que les formules Excel)
def portee_locaux(d, t):
    p = t["portee"]
    if p == "groupe":
        return [l for l in d["locaux"] if l["entite"] == t["entite"] and l["groupe"] == t["groupe"]]
    if p == "entite":
        f = t.get("filtre")
        return [l for l in d["locaux"] if l["entite"] == t["entite"]
                and (f is None or (f == "exterieur") == bool(l["exterieur"]))]
    if p == "global":
        f = t.get("filtre")
        return [l for l in d["locaux"] if f is None or (f == "exterieur") == bool(l["exterieur"])]
    raise SystemExit(f"Portée inconnue : {p}")


def controler(d):
    lignes = []
    for t in d["totaux"]:
        trouve = sum(l["su"] for l in portee_locaux(d, t))
        ecart = trouve - t["su"]
        lignes.append((t, trouve, ecart))
    return lignes


def controler_sdo(d):
    """SDO écrite au programme contre SDO recalculée (SU intérieure de la portée × coefficient)."""
    c = coef(d, "sdo_su")
    if not c:
        return []
    res = []
    for t in d["totaux"]:
        if t.get("sdo") is None:
            continue
        su_int = sum(l["su"] for l in portee_locaux(d, t) if not l["exterieur"])
        calc = su_int * c["valeur"]
        res.append((t, calc, calc - t["sdo"]))
    return res


# ---------------------------------------------------------------- Excel
def entete(ws, ligne, titres, largeurs=None):
    for j, titre in enumerate(titres, 1):
        c = ws.cell(row=ligne, column=j, value=titre)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = FOND_TITRE
        c.alignment = Alignment(vertical="center", wrap_text=True)
        c.border = CADRE
    if largeurs:
        for j, w in enumerate(largeurs, 1):
            ws.column_dimensions[get_column_letter(j)].width = w


def titre_feuille(ws, texte, sous_titre=""):
    ws["A1"] = texte
    ws["A1"].font = Font(bold=True, size=14, color=ENCRE)
    if sous_titre:
        ws["A2"] = sous_titre
        ws["A2"].font = Font(italic=True, size=10, color="6F675D")


def excel(d, ents, sortie):
    wb = Workbook()
    p = d["projet"]

    # --- Hypothèses (créée en premier : les formules des autres feuilles pointent vers ses cellules nommées)
    wh = wb.active
    wh.title = "Hypothèses"
    titre_feuille(wh, "Coefficients et hypothèses",
                  "Jaune = hypothèse à confirmer (pas donnée par le programme). Changer une valeur ici met tout le classeur à jour.")
    entete(wh, 4, ["Nom", "Valeur", "Statut", "Source", "Note"], [34, 10, 22, 40, 60])
    noms = {}
    for i, c in enumerate(d["coefficients"]):
        r = 5 + i
        wh.cell(row=r, column=1, value=c["nom"])
        v = wh.cell(row=r, column=2, value=c["valeur"])
        wh.cell(row=r, column=3, value="donné par le programme" if c["statut"] == "programme" else "hypothèse à confirmer")
        wh.cell(row=r, column=4, value=c.get("source", ""))
        wh.cell(row=r, column=5, value=c.get("note", ""))
        if c["statut"] != "programme":
            for j in range(1, 6):
                wh.cell(row=r, column=j).fill = JAUNE
        v.number_format = "0.00"
        nom = "coef_" + c["id"]
        wb.defined_names[nom] = DefinedName(nom, attr_text=f"'Hypothèses'!$B${r}")
        noms[c["id"]] = nom
    if not d["coefficients"]:
        wh.cell(row=5, column=1, value="Aucun coefficient : le programme n'en donne pas et aucune hypothèse n'a été saisie. La SDO n'est donc pas calculée.")
    for row in wh.iter_rows(min_row=5, max_row=4 + max(1, len(d["coefficients"])), max_col=5):
        for c in row:
            c.alignment = Alignment(wrap_text=True, vertical="top")
    sdo = noms.get("sdo_su")

    # --- Surfaces
    ws = wb.create_sheet("Surfaces", 0)
    titre_feuille(ws, f"{p['nom']} : tableau de surfaces",
                  f"Source : {p.get('document', '')} · SU = unitaire × nombre (formule) · Écart = SU recalculée − SU écrite dans le programme")
    cols = ["Code", "Local", "Entité", "Groupe", "Niveau", "Unitaire (m²)", "Nombre", "SU (m²)", "SU écrite au programme",
            "Écart", "SDO (m²)", "Int./Ext.", "Règle ou observation du programme", "Exigences", "Liaisons", "Page"]
    entete(ws, 4, cols, [8, 30, 18, 24, 12, 11, 9, 11, 12, 9, 11, 9, 42, 50, 18, 7])
    r0 = 5
    for i, l in enumerate(d["locaux"]):
        r = r0 + i
        e = ents[l["entite"]]
        niv = l.get("niveau", e["niveau"])
        vals = [l["code"], l["nom"], e["nom"], l["groupe"], "RDC" if niv == 0 else (f"R+{niv}" if isinstance(niv, int) else niv),
                l["unitaire"], l["nombre"], f"=F{r}*G{r}", l.get("su_annoncee"),
                f'=IF(I{r}="","",H{r}-I{r})',
                (f'=IF(L{r}="Ext.","",H{r}*{sdo})' if sdo else ""),
                "Ext." if l["exterieur"] else "Int.", l["regle"], l["exigences"],
                ", ".join(x if isinstance(x, str) else x.get("vers", "") for x in l["liaisons"]), l["page"]]
        for j, v in enumerate(vals, 1):
            c = ws.cell(row=r, column=j, value=v)
            c.border = CADRE
            c.alignment = Alignment(vertical="top", wrap_text=j in (2, 13, 14))
        for j in (6, 8, 9, 10, 11):
            ws.cell(row=r, column=j).number_format = '#,##0.00'
        ws.cell(row=r, column=7).number_format = '0.##'
        if l["regle"] and ("?" in l["regle"] or "invers" in l["regle"].lower()):
            ws.cell(row=r, column=13).fill = JAUNE
    rN = r0 + len(d["locaux"]) - 1
    ref = f"A4:{get_column_letter(len(cols))}{rN}"
    tab = Table(displayName="Locaux", ref=ref)
    tab.tableStyleInfo = TableStyleInfo(name="TableStyleLight1", showRowStripes=True)
    ws.add_table(tab)
    ws.conditional_formatting.add(f"J{r0}:J{rN}", FormulaRule(formula=[f'AND(J{r0}<>"",ABS(J{r0})>{TOL})'], fill=ROUGE))
    ws.freeze_panes = "C5"
    ws.row_dimensions[4].height = 32

    # --- Synthèse
    wy = wb.create_sheet("Synthèse", 1)
    titre_feuille(wy, "Synthèse et contrôle des totaux",
                  "Chaque total du programme est recalculé à partir des lignes. ÉCART = la somme des lignes ne redonne pas le total écrit.")
    entete(wy, 4, ["Portée", "SU recalculée", "SU écrite", "Écart SU", "Contrôle", "SDO recalculée", "SDO écrite", "Écart SDO", "Page"],
           [46, 14, 12, 11, 11, 15, 12, 11, 7])
    H, C, D, L = f"Surfaces!$H${r0}:$H${rN}", f"Surfaces!$C${r0}:$C${rN}", f"Surfaces!$D${r0}:$D${rN}", f"Surfaces!$L${r0}:$L${rN}"
    K = f"Surfaces!$K${r0}:$K${rN}"
    r = 5
    for t in d["totaux"]:
        if t["portee"] == "groupe":
            lib = f"{ents[t['entite']]['nom']} · {t['groupe']}"
            f = f'=SUMIFS({H},{C},"{ents[t["entite"]]["nom"]}",{D},"{t["groupe"]}")'
        elif t["portee"] == "entite":
            filt = t.get("filtre")
            lib = f"{ents[t['entite']]['nom']} · total" + (f" ({filt})" if filt else "")
            f = f'=SUMIFS({H},{C},"{ents[t["entite"]]["nom"]}"' + (f',{L},"{"Ext." if filt == "exterieur" else "Int."}")' if filt else ")")
        else:
            filt = t.get("filtre")
            lib = "Total général" + (f" ({filt})" if filt else "")
            f = (f'=SUMIFS({H},{L},"{"Ext." if filt == "exterieur" else "Int."}")' if filt else f"=SUM({H})")
        if t.get("libelle"):
            lib = t["libelle"]
        # SDO recalculée : on somme la colonne SDO des lignes (vide pour les extérieurs), avec les mêmes critères
        n_int = sum(1 for l in portee_locaux(d, t) if not l["exterieur"])
        f_sdo = f.replace(H, K, 1) if (sdo and n_int) else ""
        vals = [lib, f, t["su"], f"=B{r}-C{r}", f'=IF(ABS(D{r})<={TOL},"OK","ÉCART")',
                f_sdo, t.get("sdo"),
                (f'=IF(OR(F{r}="",G{r}=""),"",F{r}-G{r})' if sdo else ""), t.get("page", "")]
        for j, v in enumerate(vals, 1):
            c = wy.cell(row=r, column=j, value=v)
            c.border = CADRE
            if j in (2, 3, 4, 6, 7, 8):
                c.number_format = '#,##0.00'
        r += 1
    wy.conditional_formatting.add(f"E5:E{max(5, r - 1)}", CellIsRule(operator="equal", formula=['"ÉCART"'], fill=ROUGE))
    wy.conditional_formatting.add(f"E5:E{max(5, r - 1)}", CellIsRule(operator="equal", formula=['"OK"'], fill=VERT))
    # répartition par entité, toujours présente, même si le programme ne donne pas de total
    r += 1
    wy.cell(row=r, column=1, value="Répartition par entité (SU intérieure)").font = Font(bold=True)
    r += 1
    entete_r = r
    for j, tt in enumerate(["Entité", "SU intérieure", "Part", "Niveau", "Statut du niveau", "Source du niveau"], 1):
        c = wy.cell(row=r, column=j, value=tt)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = FOND_TITRE
    r += 1
    premier = r
    for e in d["entites"]:
        wy.cell(row=r, column=1, value=e["nom"])
        wy.cell(row=r, column=2, value=f'=SUMIFS({H},{C},"{e["nom"]}",{L},"Int.")').number_format = '#,##0.00'
        wy.cell(row=r, column=4, value="RDC" if e["niveau"] == 0 else (f"R+{e['niveau']}" if isinstance(e["niveau"], int) else e["niveau"]))
        wy.cell(row=r, column=5, value=e["niveau_statut"])
        wy.cell(row=r, column=6, value=e.get("niveau_source", ""))
        r += 1
    for rr in range(premier, r):
        c = wy.cell(row=rr, column=3, value=f"=IF(SUM($B${premier}:$B${r - 1})=0,0,B{rr}/SUM($B${premier}:$B${r - 1}))")
        c.number_format = "0%"
    wy.cell(row=r, column=1, value="Total").font = Font(bold=True)
    wy.cell(row=r, column=2, value=f"=SUM(B{premier}:B{r - 1})").number_format = '#,##0.00'
    wy.freeze_panes = "A5"

    # --- À vérifier
    wv = wb.create_sheet("À vérifier", 2)
    titre_feuille(wv, "Ce qu'il faut vérifier avant de dessiner",
                  "Ambiguïtés, contradictions et choix de lecture. Chaque ligne renvoie à la page du programme.")
    entete(wv, 4, ["Impact", "Sujet", "Ce qui pose question", "Lecture retenue dans ce classeur", "Page"], [9, 30, 70, 50, 8])
    for i, a in enumerate(sorted(d["a_verifier"], key=lambda a: {"fort": 0, "moyen": 1, "faible": 2}.get(a.get("impact"), 3))):
        r = 5 + i
        vals = [a.get("impact", ""), a["sujet"], a["detail"], a.get("lecture", ""), a.get("page", "")]
        for j, v in enumerate(vals, 1):
            c = wv.cell(row=r, column=j, value=v)
            c.alignment = Alignment(wrap_text=True, vertical="top")
            c.border = CADRE
        wv.cell(row=r, column=1).fill = {"fort": ROUGE, "moyen": JAUNE}.get(a.get("impact"), GRIS)

    # --- Contraintes, rendus, dates
    wc = wb.create_sheet("Contraintes et rendus", 3)
    titre_feuille(wc, "Contraintes, pièces à rendre, dates")
    wc.column_dimensions["A"].width = 22
    wc.column_dimensions["B"].width = 100
    wc.column_dimensions["C"].width = 8
    r = 4
    for titre, cle in (("Contraintes", "contraintes"), ("Pièces à rendre", "rendus"), ("Dates", "dates")):
        wc.cell(row=r, column=1, value=titre).font = Font(bold=True, size=12)
        r += 1
        items = d[cle] or [{"texte": "Rien dans ce document (voir le règlement de la consultation).", "page": ""}]
        for it in items:
            wc.cell(row=r, column=1, value=it.get("theme", ""))
            c = wc.cell(row=r, column=2, value=it["texte"] + (f" — {it['detail']}" if it.get("detail") else ""))
            c.alignment = Alignment(wrap_text=True, vertical="top")
            wc.cell(row=r, column=3, value=it.get("page", ""))
            r += 1
        r += 1

    wb.calculation.fullCalcOnLoad = True
    chemin = os.path.join(sortie, "surfaces.xlsx")
    wb.save(chemin)
    return chemin


# ---------------------------------------------------------------- HTML
def html(d, ents, sortie):
    with open(os.path.join(ICI, "gabarit-3d.html"), encoding="utf-8") as f:
        gabarit = f.read()
    c = coef(d, "sdo_su")
    donnees = {
        "projet": d["projet"],
        "hauteur": d.get("hauteur_lecture", 3.0),
        "coef": ({"valeur": c["valeur"], "statut": c["statut"], "source": c.get("source", "")} if c else None),
        "entites": [{k: e.get(k) for k in ("id", "nom", "couleur", "niveau", "niveau_statut", "niveau_source")} for e in d["entites"]],
        "locaux": [{k: l.get(k) for k in ("code", "nom", "entite", "groupe", "unitaire", "nombre", "su", "exterieur", "regle",
                                           "exigences", "liaisons", "page", "blocs", "niveau")} for l in d["locaux"]],
        "totaux": [{"portee": t["portee"], "filtre": t.get("filtre"), "su": t["su"], "page": t.get("page"),
                    "trouve": round(tr, 2), "ok": abs(ec) <= TOL} for t, tr, ec in controler(d)],
    }
    page = gabarit.replace("/*__DONNEES__*/null", json.dumps(donnees, ensure_ascii=False))
    page = page.replace("__TITRE__", d["projet"]["nom"])
    chemin = os.path.join(sortie, "programme-3d.html")
    with open(chemin, "w", encoding="utf-8") as f:
        f.write(page)
    return chemin


def main():
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    d, ents = charger(sys.argv[1])
    os.makedirs(sys.argv[2], exist_ok=True)
    print("Contrôle des totaux (somme des lignes contre total écrit dans le programme) :")
    n_ecarts = 0
    for t, trouve, ecart in controler(d):
        nom = t.get("libelle") or (t["portee"] + " " + str(t.get("entite", "")) + " " + str(t.get("groupe", "")) + " " + str(t.get("filtre") or "")).strip()
        etat = "OK " if abs(ecart) <= TOL else "ÉCART"
        n_ecarts += abs(ecart) > TOL
        print(f"  [{etat}] {nom:<60} lignes {trouve:>10.2f}  programme {t['su']:>10.2f}  écart {ecart:+.2f}  (p. {t.get('page', '?')})")
    for t, calc, ecart in controler_sdo(d):
        if abs(ecart) > TOL:
            n_ecarts += 1
            nom = t.get("libelle") or t["portee"]
            print(f"  [ÉCART SDO] {nom:<56} recalculée {calc:>10.2f}  programme {t['sdo']:>10.2f}  écart {ecart:+.2f}  (p. {t.get('page', '?')})")
    for l in d["locaux"]:
        if l.get("su_annoncee") is not None and abs(l["su"] - l["su_annoncee"]) > TOL:
            n_ecarts += 1
            print(f"  [ÉCART] ligne {l['code']} {l['nom']} : {l['unitaire']} × {l['nombre']} = {l['su']:.2f}, le programme écrit {l['su_annoncee']}")
    print(f"{n_ecarts} écart(s).")
    print("Écrit :", excel(d, ents, sys.argv[2]))
    print("Écrit :", html(d, ents, sys.argv[2]))


if __name__ == "__main__":
    main()
