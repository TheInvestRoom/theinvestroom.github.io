# -*- coding: utf-8 -*-
"""
Dessine, à partir de programme.json, cinq images plein cadre 1080 × 1920 (PNG) et, si ffmpeg est présent, une vidéo
de 3 s pour chacune (le dessin se construit, puis l'image finale est tenue) :
  01-surfaces      : la synthèse du tableau de surfaces, chaque total du programme recalculé et contrôlé ;
  02-eclate        : le programme en blocs à l'échelle, rangé par entité, extérieurs à côté ;
  03-empile        : les mêmes blocs posés à leur niveau, circulations en blanc (si un coefficient est connu) ;
  04-liaisons      : les liaisons écrites dans le programme, tracées entre les blocs ;
  05-contraintes   : les contraintes qui dessinent le plan, et les pièces à rendre.

Usage : python images.py programme.json dossier_de_sortie [--sans-video]
Dépendances : Pillow, numpy ; ffmpeg (facultatif) pour les MP4. Aucun navigateur, aucun générateur d'images.

Le rendu 3D est une axonométrie isométrique calculée ici : faces remplies avec un tampon de profondeur (les faces
cachées ne passent jamais devant), contours tirés des changements de face, ce qui donne un trait propre de maquette.
"""
import json, math, os, shutil, subprocess, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from construire import charger, controler, controler_sdo, coef, portee_locaux, TOL  # même lecture, même contrôle que l'Excel

W, H = 1080, 1920
FOND = (241, 237, 228)
ENCRE = (42, 38, 34)
DOUX = (111, 103, 93)
OK = (61, 138, 87)
KO = (181, 72, 61)
CARTE = (251, 249, 244)
TRAIT = (221, 214, 200)


# ---------------------------------------------------------------- polices (on prend ce que la machine a)
def police(taille, gras=False):
    noms = (["segoeuib.ttf", "bahnschrift.ttf", "arialbd.ttf", "DejaVuSans-Bold.ttf"] if gras
            else ["segoeui.ttf", "bahnschrift.ttf", "arial.ttf", "DejaVuSans.ttf"])
    dossiers = [r"C:\Windows\Fonts", "/usr/share/fonts/truetype/dejavu", "/Library/Fonts", "/System/Library/Fonts"]
    try:
        import matplotlib
        dossiers.append(os.path.join(os.path.dirname(matplotlib.__file__), "mpl-data", "fonts", "ttf"))
    except Exception:
        pass
    for n in noms:
        for d in dossiers:
            p = os.path.join(d, n)
            if os.path.exists(p):
                return ImageFont.truetype(p, taille)
    return ImageFont.load_default()


def hexrgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def melange(c, d, t):
    return tuple(int(round(a + (b - a) * t)) for a, b in zip(c, d))


def fmt(x, dec=0):
    s = f"{x:,.{dec}f}".replace(",", " ").replace(".", ",")
    return s


def couper(txt, f, largeur, draw):
    mots, lignes, cur = txt.split(), [], ""
    for m in mots:
        essai = (cur + " " + m).strip()
        if draw.textlength(essai, font=f) <= largeur:
            cur = essai
        else:
            if cur:
                lignes.append(cur)
            cur = m
    if cur:
        lignes.append(cur)
    return lignes


def cartouche(draw, titre, projet, source):
    f1, f2 = police(26, True), police(22)
    y = H - 92
    draw.line([(60, y), (W - 60, y)], fill=TRAIT, width=2)
    draw.text((60, y + 16), titre, font=f1, fill=ENCRE)
    draw.text((60, y + 50), f"{projet} · {source}", font=f2, fill=DOUX)


# ---------------------------------------------------------------- blocs et mise en page (en mètres, y vers le haut)
def faire_blocs(d):
    blocs = []
    for l in d["locaux"]:
        if not l["su"] > 0:
            continue
        n = l.get("blocs")
        if n is None:
            n = int(l["nombre"]) if (float(l["nombre"]).is_integer() and l["nombre"] >= 1 and l["unitaire"] >= 4) else 1
        a = l["su"] / n
        for k in range(n):
            r = 1.5 if a > 90 else 1.0
            w = math.sqrt(a * r)
            blocs.append({"l": l, "k": k, "a": a, "w": w, "d": a / w, "ext": bool(l["exterieur"]), "ent": l["entite"]})
    return blocs


def etagere(liste, largeur, jeu):
    x = z = rang = Wm = 0.0
    pos = {}
    for b in sorted(liste, key=lambda b: -b["a"]):
        if x > 0 and x + b["w"] > largeur:
            x, z, rang = 0.0, z + rang + jeu, 0.0
        pos[id(b)] = (x, z)
        x += b["w"] + jeu
        rang = max(rang, b["d"])
        Wm = max(Wm, x - jeu)
    return pos, Wm, z + rang


def disposer(d, blocs, mode, hl):
    """Renvoie des boîtes (x0, y0, z0, w, h, dz, couleur, nature, bloc) et des étiquettes d'entité."""
    boites, etiq = [], []
    c = coef(d, "sdo_su")
    if mode == "eclate":
        # les îlots d'entité descendent en diagonale (x et z croissent ensemble) : à l'écran, une colonne
        s = 0.0
        for e in d["entites"]:
            mes = [b for b in blocs if b["ent"] == e["id"] and not b["ext"]]
            dehors = [b for b in blocs if b["ent"] == e["id"] and b["ext"]]
            if not mes and not dehors:
                continue
            A = sum(b["a"] for b in mes)
            lg = max([math.sqrt(A) * 1.35 if A else 0] + [b["w"] for b in mes] + [10])
            pos, Wi, Di = etagere(mes, lg, 1.2)
            for b in mes:
                x, z = pos[id(b)]
                boites.append((s + x, 0, s + z, b["w"], hl, b["d"], e["couleur"], "int", b))
            if dehors:
                lgE = max([lg] + [b["w"] for b in dehors])
                posE, WE, DE = etagere(dehors, lgE, 1.2)
                for b in dehors:
                    x, z = posE[id(b)]
                    boites.append((s + Wi + 6 + x, 0, s + z, b["w"], 0.15, b["d"], e["couleur"], "ext", b))
                Wi2 = Wi + 6 + WE
            else:
                Wi2 = Wi
            if mes:
                etiq.append((e, s, hl, s, A))
            s += max(Di, 8) + 10 + 0.15 * Wi2
    else:
        # chaque niveau : les entités en grappes compactes, rangées en grille (pas en rangée : l'image est verticale)
        niveaux = {}
        for e in d["entites"]:
            n = e["niveau"] if isinstance(e["niveau"], int) else 0
            niveaux.setdefault(n, []).append(e)
        grappes = {}
        for n, es in niveaux.items():
            for e in es:
                mes = [b for b in blocs if b["ent"] == e["id"] and not b["ext"]]
                if not mes:
                    continue
                A = sum(b["a"] for b in mes)
                pos, Wi, Di = etagere(mes, max([math.sqrt(A) * 1.1] + [b["w"] for b in mes]), 0.25)
                g = None
                Wt = Wi
                if c:
                    aire = A * (c["valeur"] - 1)
                    g = (Wi + 0.25, aire / Di, Di, aire)
                    Wt += 0.25 + aire / Di
                grappes.setdefault(n, []).append({"e": e, "mes": mes, "pos": pos, "W": Wt, "D": Di, "Wi": Wi, "g": g, "A": A})
        ref = grappes.get(min(grappes)) if grappes else []
        cible_l = math.sqrt(sum(gr["W"] * gr["D"] for gr in ref)) * 1.15 if ref else 20
        etages = {}
        for n, grs in grappes.items():
            x0 = z0 = rang = 0.0
            Wn = 0.0
            for gr in grs:
                if x0 > 0 and x0 + gr["W"] > max(cible_l, gr["W"]):
                    x0, z0, rang = 0.0, z0 + rang + 0.5, 0.0
                gr["x"], gr["z"] = x0, z0
                x0 += gr["W"] + 0.5
                rang = max(rang, gr["D"])
                Wn = max(Wn, x0 - 0.5)
            etages[n] = (Wn, z0 + rang)
        Wm = max(w for w, _ in etages.values())
        Dm = max(dd for _, dd in etages.values())
        for n, grs in grappes.items():
            dx, dz = (Wm - etages[n][0]) / 2, (Dm - etages[n][1]) / 2
            for gr in grs:
                X, Z = dx + gr["x"], dz + gr["z"]
                for b in gr["mes"]:
                    x, z = gr["pos"][id(b)]
                    boites.append((X + x, n * hl, Z + z, b["w"], hl, b["d"], gr["e"]["couleur"], "int", b))
                if gr["g"]:
                    g = gr["g"]
                    boites.append((X + g[0], n * hl, Z, g[1], hl, g[2], "#FFFFFF", "circ", {"aire": g[3], "e": gr["e"]}))
                etiq.append((gr["e"], X, (n + 1) * hl, Z, gr["A"]))
        # extérieurs : en plan à côté de la masse, placés pour tomber juste en dessous à l'écran
        dehors = [b for b in blocs if b["ext"]]
        if dehors:
            aireE = sum(b["a"] for b in dehors)
            posE, WE, DE = etagere(dehors, max([math.sqrt(aireE) * 1.1] + [b["w"] for b in dehors]), 1.5)
            ox = Wm / 2 - WE / 2 + Dm / 2 + 6 + DE / 2
            ents = {e["id"]: e for e in d["entites"]}
            for b in dehors:
                x, z = posE[id(b)]
                boites.append((ox + x, 0, Dm + 6 + z, b["w"], 0.15, b["d"], ents[b["ent"]]["couleur"], "ext", b))
    return boites, etiq


# ---------------------------------------------------------------- rendu axonométrique (tampon de profondeur)
C30, S30 = math.cos(math.radians(30)), math.sin(math.radians(30))


def proj(x, y, z):
    return (x - z) * C30, (x + z) * S30 - y


def cadrage(boites, haut=150, bas=140, marge=60):
    us, vs = [], []
    for (x, y, z, w, h, dz, *_r) in boites:
        for px in (x, x + w):
            for py in (y, y + h):
                for pz in (z, z + dz):
                    u, v = proj(px, py, pz)
                    us.append(u)
                    vs.append(v)
    u0, u1, v0, v1 = min(us), max(us), min(vs), max(vs)
    k = min((W - 2 * marge) / (u1 - u0), (H - haut - bas) / (v1 - v0))
    ox = W / 2 - k * (u0 + u1) / 2
    oy = haut + (H - haut - bas) / 2 - k * (v0 + v1) / 2
    return k, ox, oy


def rendre(boites, cad, S=2, montee=None):
    """montee : dict id(boite) -> décalage vertical en mètres (animation). Renvoie une image RGB 1080 × 1920."""
    k, ox, oy = cad
    Ws, Hs = W * S, H * S
    zbuf = np.full((Hs, Ws), -1e9, dtype=np.float32)
    ids = np.zeros((Hs, Ws), dtype=np.int32)
    col = np.zeros((Hs, Ws, 3), dtype=np.float32)
    col[:] = FOND
    # ombres portées au sol (lumière venant de la gauche, en haut)
    ombre = Image.new("L", (Ws, Hs), 0)
    od = ImageDraw.Draw(ombre)
    for i, bt in enumerate(boites):
        x, y, z, w, h, dz = bt[:6]
        dy = (montee or {}).get(i, 0.0)
        if bt[7] == "ext" or y + dy > 0.01:
            continue
        sx, sz = h * 0.55, -h * 0.25
        pts = [(x, z), (x + w, z), (x + w, z + dz), (x, z + dz)]
        pts += [(px + sx, pz + sz) for px, pz in pts]
        hull = convexe([proj(px, 0, pz) for px, pz in pts])
        od.polygon([((u * k + ox) * S, (v * k + oy) * S) for u, v in hull], fill=60)
    a = np.asarray(ombre, dtype=np.float32)[..., None] / 255.0
    col = col * (1 - a) + np.array(ENCRE, dtype=np.float32) * a
    fid = 0
    for i, bt in enumerate(boites):
        x, y, z, w, h, dz, couleur, nature = bt[:8]
        y = y + (montee or {}).get(i, 0.0)
        base = hexrgb(couleur)
        if nature == "ext":
            base = melange(base, (255, 255, 255), 0.55)
        teintes = {"haut": melange(base, (255, 255, 255), 0.12), "x": melange(base, (0, 0, 0), 0.14), "z": melange(base, (0, 0, 0), 0.28)}
        if nature == "circ":
            teintes = {"haut": (255, 255, 255), "x": (238, 236, 232), "z": (226, 223, 217)}
        faces = {
            "haut": [(x, y + h, z), (x + w, y + h, z), (x + w, y + h, z + dz), (x, y + h, z + dz)],
            "x": [(x + w, y, z), (x + w, y + h, z), (x + w, y + h, z + dz), (x + w, y, z + dz)],
            "z": [(x, y, z + dz), (x + w, y, z + dz), (x + w, y + h, z + dz), (x, y + h, z + dz)],
        }
        for nom, pts3 in faces.items():
            fid += 1
            pts2 = [((proj(*p)[0] * k + ox) * S, (proj(*p)[1] * k + oy) * S) for p in pts3]
            prof = [p[0] + p[1] + p[2] for p in pts3]
            u0, v0 = int(max(0, math.floor(min(p[0] for p in pts2)))), int(max(0, math.floor(min(p[1] for p in pts2))))
            u1, v1 = int(min(Ws, math.ceil(max(p[0] for p in pts2)) + 1)), int(min(Hs, math.ceil(max(p[1] for p in pts2)) + 1))
            if u1 <= u0 or v1 <= v0:
                continue
            m = Image.new("L", (u1 - u0, v1 - v0), 0)
            ImageDraw.Draw(m).polygon([(p[0] - u0, p[1] - v0) for p in pts2], fill=255)
            mask = np.asarray(m) > 0
            # profondeur affine sur la face : on la résout à partir de trois sommets
            A = np.array([[pts2[j][0], pts2[j][1], 1.0] for j in (0, 1, 3)])
            try:
                cf = np.linalg.solve(A, np.array([prof[0], prof[1], prof[3]]))
            except np.linalg.LinAlgError:
                continue
            uu, vv = np.meshgrid(np.arange(u0, u1) + 0.5, np.arange(v0, v1) + 0.5)
            dep = (cf[0] * uu + cf[1] * vv + cf[2]).astype(np.float32) + 1e-3 * (nom == "haut")
            zone = zbuf[v0:v1, u0:u1]
            gagne = mask & (dep > zone)
            zone[gagne] = dep[gagne]
            ids[v0:v1, u0:u1][gagne] = fid
            col[v0:v1, u0:u1][gagne] = teintes[nom]
    # contours : là où la face change
    bord = np.zeros((Hs, Ws), dtype=bool)
    bord[:, 1:] |= ids[:, 1:] != ids[:, :-1]
    bord[1:, :] |= ids[1:, :] != ids[:-1, :]
    bord &= np.maximum(ids, np.roll(ids, 1, axis=1)) > 0
    col[bord] = col[bord] * 0.35 + np.array(ENCRE, dtype=np.float32) * 0.65
    img = Image.fromarray(np.clip(col, 0, 255).astype(np.uint8), "RGB")
    return img.resize((W, H), Image.LANCZOS) if S != 1 else img


def convexe(pts):
    pts = sorted(set(pts))
    if len(pts) <= 2:
        return pts
    def cr(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lo, hi = [], []
    for p in pts:
        while len(lo) >= 2 and cr(lo[-2], lo[-1], p) <= 0:
            lo.pop()
        lo.append(p)
    for p in reversed(pts):
        while len(hi) >= 2 and cr(hi[-2], hi[-1], p) <= 0:
            hi.pop()
        hi.append(p)
    return lo[:-1] + hi[:-1]


def ecran(cad, x, y, z):
    k, ox, oy = cad
    u, v = proj(x, y, z)
    return u * k + ox, v * k + oy


def etiquettes(img, etiq, cad, total=True):
    dr = ImageDraw.Draw(img)
    f1, f2 = police(26, True), police(22)
    poses = []
    for e, x, y, z, A in etiq:
        u, v = ecran(cad, x, y, z)
        t1, t2 = e["nom"], f"{fmt(A)} m²"
        lw = dr.textlength(t1, font=f1) + 12 + dr.textlength(t2, font=f2) + 28
        bx, by = u - lw / 2, v - 62
        bx = min(max(20, bx), W - 20 - lw)
        for _ in range(8):  # évite qu'une étiquette en recouvre une autre
            if all(abs(by - py) > 48 or bx + lw < px or bx > px + pw for px, py, pw in poses):
                break
            by -= 50
        poses.append((bx, by, lw))
        dr.line([(u, v), (u, by + 40)], fill=ENCRE, width=2)
        dr.rounded_rectangle([bx, by, bx + lw, by + 40], radius=9, fill=hexrgb(e["couleur"]), outline=ENCRE, width=2)
        dr.text((bx + 14, by + 5), t1, font=f1, fill=ENCRE)
        dr.text((bx + 14 + dr.textlength(t1, font=f1) + 12, by + 9), t2, font=f2, fill=ENCRE)
    return img


def legende(img, d, boites):
    """Légende en bas de l'image : couleur, entité, surface, niveau (et * si le niveau vient du programme)."""
    dr = ImageDraw.Draw(img)
    f1, f2 = police(25, True), police(24)
    lignes = []
    for e in d["entites"]:
        A = sum(b[3] * b[5] for b in boites if b[7] == "int" and b[8]["ent"] == e["id"])
        if A:
            n = e["niveau"] if isinstance(e["niveau"], int) else 0
            niv = ("RDC" if n == 0 else f"R+{n}") + ("*" if e.get("niveau_statut") not in (None, "libre") else "")
            lignes.append((e, A, niv))
    if any(b[7] == "circ" for b in boites):
        lignes.append(({"nom": "Circulations (SDO − SU)", "couleur": "#FFFFFF"},
                       sum(b[8]["aire"] for b in boites if b[7] == "circ"), ""))
    col = 2
    rangs = math.ceil(len(lignes) / col)
    y0 = H - 110 - rangs * 44 - 30
    for i, (e, A, niv) in enumerate(lignes):
        x = 60 + (i % col) * 490
        y = y0 + (i // col) * 44
        dr.rectangle([x, y + 6, x + 26, y + 32], fill=hexrgb(e["couleur"]), outline=ENCRE, width=2)
        dr.text((x + 38, y + 3), e["nom"][:24], font=f1, fill=ENCRE)
        dr.text((x + 470 - dr.textlength(f"{fmt(A)} m²  {niv}", font=f2), y + 4), f"{fmt(A)} m²  {niv}", font=f2, fill=DOUX)


def entete(img, titre, sous):
    dr = ImageDraw.Draw(img)
    dr.text((60, 56), titre, font=police(44, True), fill=ENCRE)
    dr.text((60, 112), sous, font=police(26), fill=DOUX)


# ---------------------------------------------------------------- vidéo
def video(chemin, images_fn, n=90, tenue=20):
    if not shutil.which("ffmpeg"):
        return None
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", "30",
           "-i", "-", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", "-movflags", "+faststart", chemin]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    anim = n - tenue
    for i in range(n):
        t = min(1.0, i / max(1, anim - 1))
        p.stdin.write(images_fn(t).convert("RGB").tobytes())
    p.stdin.close()
    p.wait()
    return chemin


def ease(t):
    return 4 * t ** 3 if t < .5 else 1 - (-2 * t + 2) ** 3 / 2


# ---------------------------------------------------------------- 01 : synthèse du tableau de surfaces
def image_surfaces(d, ents, t=1.0):
    img = Image.new("RGB", (W, H), FOND)
    dr = ImageDraw.Draw(img)
    ctl = controler(d)
    n_ok = sum(abs(e) <= TOL for _, _, e in ctl)
    entete(img, "Tableau de surfaces", f"{len([l for l in d['locaux'] if not l['exterieur']])} lignes relues · chaque total recalculé")
    c = coef(d, "sdo_su")
    # en-tête du tableau
    y = 180
    cols = [(60, "Total du programme"), (640, "Recalculé"), (830, "Écrit"), (985, "")]
    dr.rectangle([40, y, W - 40, y + 54], fill=ENCRE)
    f = police(24, True)
    for x, tt in cols:
        dr.text((x, y + 13), tt, font=f, fill=(255, 255, 255))
    y += 54
    lignes = []
    for tot, trouve, ecart in ctl:
        if tot["portee"] == "groupe":
            lib = f"{ents[tot['entite']]['nom']} · {tot['groupe']}"
            coul = ents[tot["entite"]]["couleur"]
        elif tot["portee"] == "entite":
            lib = tot.get("libelle") or ents[tot["entite"]]["nom"]
            coul = ents[tot["entite"]]["couleur"]
        else:
            lib = tot.get("libelle") or "Total général"
            coul = None
        lignes.append((lib, coul, trouve, tot["su"], ecart, tot["portee"] == "global"))
    h_l = min(66, int((1060 - 54) / max(1, len(lignes))))
    fl, fn = police(min(25, h_l - 30), False), police(min(27, h_l - 28), True)
    vis = int(math.ceil(ease(t) * len(lignes))) if t < 1 else len(lignes)
    for i, (lib, coul, trouve, ecrit, ecart, gros) in enumerate(lignes[:max(1, vis)]):
        fond = CARTE if i % 2 == 0 else (245, 242, 235)
        dr.rectangle([40, y, W - 40, y + h_l], fill=fond, outline=TRAIT)
        if coul:
            dr.rectangle([40, y, 52, y + h_l], fill=hexrgb(coul))
        ff = police(min(25, h_l - 30), True) if gros else fl
        txt = lib
        while dr.textlength(txt, font=ff) > 560 and len(txt) > 8:
            txt = txt[:-2]
        if txt != lib:
            txt = txt.rstrip() + "…"
        dr.text((66, y + (h_l - 30) / 2), txt, font=ff, fill=ENCRE)
        dr.text((640, y + (h_l - 32) / 2), fmt(trouve, 2 if trouve % 1 else 0), font=fn, fill=ENCRE)
        dr.text((830, y + (h_l - 30) / 2), fmt(ecrit, 2 if ecrit % 1 else 0), font=fl, fill=DOUX)
        ok = abs(ecart) <= TOL
        cx, cy = 1005, y + h_l / 2
        dr.ellipse([cx - 17, cy - 17, cx + 17, cy + 17], fill=OK if ok else KO)
        if ok:
            dr.line([(cx - 8, cy), (cx - 2, cy + 7), (cx + 9, cy - 7)], fill=(255, 255, 255), width=4)
        else:
            dr.line([(cx - 7, cy - 7), (cx + 7, cy + 7)], fill=(255, 255, 255), width=4)
            dr.line([(cx - 7, cy + 7), (cx + 7, cy - 7)], fill=(255, 255, 255), width=4)
        y += h_l
    y = 180 + 54 + h_l * len(lignes) + 30
    if t >= 0.6:
        # bandeau de résultat
        tout = n_ok == len(ctl)
        dr.rounded_rectangle([40, y, W - 40, y + 92], radius=16, fill=OK if tout else KO)
        dr.text((70, y + 22), f"{n_ok}/{len(ctl)} totaux du programme retrouvés", font=police(36, True), fill=(255, 255, 255))
        y += 120
        for tot, calc, ec in controler_sdo(d):
            if abs(ec) <= TOL or y > H - 520:
                continue
            lib = tot.get("libelle") or "Total"
            dr.rounded_rectangle([40, y, W - 40, y + 150], radius=16, fill=(250, 232, 228), outline=KO, width=3)
            dr.text((70, y + 18), f"Erreur dans le programme : {fmt(abs(ec), 2 if abs(ec) % 1 else 0)} m² de SDO {'en trop' if ec < 0 else 'en moins'}", font=police(32, True), fill=KO)
            for j, lig in enumerate(couper(f"{lib} (p. {tot.get('page', '?')}) : écrit {fmt(tot['sdo'], 2)} m², recalculé {fmt(calc, 2)} m².", police(25), W - 140, dr)[:2]):
                dr.text((70, y + 66 + 34 * j), lig, font=police(25), fill=ENCRE)
            y += 172
        suI = sum(l["su"] for l in d["locaux"] if not l["exterieur"])
        suE = sum(l["su"] for l in d["locaux"] if l["exterieur"])
        cartes = [("Surface utile", f"{fmt(suI)} m²")]
        if c:
            cartes.append((f"SDO ×{fmt(c['valeur'], 2)}" + ("" if c["statut"] == "programme" else " (hyp.)"), f"{fmt(suI * c['valeur'])} m²"))
        if suE:
            cartes.append(("Extérieurs", f"{fmt(suE)} m²"))
        lw = (W - 80 - 20 * (len(cartes) - 1)) / len(cartes)
        for j, (a, b) in enumerate(cartes):
            x0 = 40 + j * (lw + 20)
            dr.rounded_rectangle([x0, y, x0 + lw, y + 120], radius=14, fill=CARTE, outline=TRAIT, width=2)
            dr.text((x0 + 22, y + 16), a, font=police(24), fill=DOUX)
            dr.text((x0 + 22, y + 52), b, font=police(42, True), fill=ENCRE)
        y += 150
    if t >= 0.85 and y < H - 300:
        fort = [a for a in d["a_verifier"] if a.get("impact") == "fort"]
        dr.text((40, y), f"À vérifier : {len(d['a_verifier'])} point{'s' if len(d['a_verifier']) > 1 else ''}, dont {len(fort)} d'impact fort", font=police(28, True), fill=KO)
        y += 46
        for a in fort[:4]:
            if y > H - 170:
                break
            for k2, lig in enumerate(couper("• " + a["sujet"] + (f" (p. {a['page']})" if a.get("page") else ""), police(25), W - 100, dr)[:2]):
                dr.text((52, y), lig, font=police(25), fill=ENCRE)
                y += 34
            y += 6
    cartouche(dr, "01 · Tableau de surfaces contrôlé", d["projet"]["nom"], "surfaces.xlsx")
    return img


# ---------------------------------------------------------------- 05 : contraintes et pièces à rendre
def image_contraintes(d, t=1.0):
    img = Image.new("RGB", (W, H), FOND)
    dr = ImageDraw.Draw(img)
    entete(img, "Ce qui dessine le plan", "Contraintes relevées dans le programme, avec leur page")
    y = 190
    items = d["contraintes"][:9]
    vis = len(items) if t >= 1 else max(1, int(math.ceil(ease(min(1, t / 0.8)) * len(items))))
    ft, fx, fp = police(22, True), police(28), police(22)
    for it in items[:vis]:
        tout = couper(it["texte"], fx, W - 130, dr)
        lignes = tout[:4]
        if len(tout) > 4:
            lignes[-1] = lignes[-1].rstrip(" ;,.") + " …"
        hh = 56 + 38 * len(lignes)
        if y + hh > H - 330:
            break
        dr.rounded_rectangle([40, y, W - 40, y + hh], radius=14, fill=CARTE, outline=TRAIT, width=2)
        theme = (it.get("theme") or "").upper()
        dr.text((66, y + 14), theme, font=ft, fill=DOUX)
        if it.get("page"):
            pt = f"p. {it['page']}"
            dr.text((W - 66 - dr.textlength(pt, font=fp), y + 14), pt, font=fp, fill=DOUX)
        for j, lig in enumerate(lignes):
            dr.text((66, y + 46 + 38 * j), lig, font=fx, fill=ENCRE)
        y += hh + 14
    if t >= 0.9:
        y += 10
        dr.text((40, y), "Pièces à rendre", font=police(30, True), fill=ENCRE)
        y += 48
        rendus = d["rendus"] or [{"texte": "Pas dans ce document : elles sont dans le règlement de la consultation."}]
        for it in rendus[:5]:
            for lig in couper("• " + it["texte"], police(26), W - 100, dr)[:2]:
                if y > H - 140:
                    break
                dr.text((52, y), lig, font=police(26), fill=ENCRE if d["rendus"] else DOUX)
                y += 36
    cartouche(dr, "05 · Contraintes et pièces à rendre", d["projet"]["nom"], "onglet « Contraintes et rendus »")
    return img


# ---------------------------------------------------------------- 02, 03, 04 : la 3D
def scene(d, ents, mode, hl):
    blocs = faire_blocs(d)
    boites, etiq = disposer(d, blocs, mode, hl)
    bas = 150 if mode == "eclate" else 150 + 44 * math.ceil((len(d["entites"]) + 1) / 2) + 40
    cad = cadrage(boites, haut=240, bas=bas)
    return boites, etiq, cad


def image_3d(d, ents, mode, hl, t=1.0, S=2, base=None):
    boites, etiq, cad = base or scene(d, ents, mode, hl)
    ordre = sorted(range(len(boites)), key=lambda i: (boites[i][7] != "ext", boites[i][1], boites[i][2] + boites[i][0]))
    montee = {}
    if t < 1:
        n = len(ordre)
        for rang, i in enumerate(ordre):
            debut = 0.12 + 0.6 * rang / max(1, n)  # les extérieurs et les premiers blocs sont déjà là au départ
            p = min(1.0, max(0.0, (t - debut) / 0.25)) if boites[i][7] != "ext" else 1.0
            if rang < max(3, n // 12):
                p = 1.0
            montee[i] = (1 - ease(p)) * 60 if p < 1 else 0.0
            if p <= 0:
                montee[i] = 400.0  # hors cadre
    img = rendre(boites, cad, S=S, montee=montee)
    if t >= 1 and mode == "eclate":
        etiquettes(img, etiq, cad)
    if mode == "empile":
        legende(img, d, boites)
    dr = ImageDraw.Draw(img)
    if t < 1:  # les blocs qui tombent passent sous le titre, pas au travers
        dr.rectangle([0, 0, W, 165], fill=FOND)
    suI = sum(b[3] * b[5] for b in boites if b[7] == "int")
    c = coef(d, "sdo_su")
    if mode == "eclate":
        entete(img, "Le programme à l'échelle", f"{len([b for b in boites if b[7] == 'int'])} locaux · {fmt(suI)} m² de surface utile · un bloc = un local")
        cartouche(dr, "02 · Programme éclaté par entité", d["projet"]["nom"], "surfaces réelles, hauteur de lecture " + fmt(hl, 1) + " m")
    else:
        niv = sorted({b[1] for b in boites if b[7] == "int"})
        sous = f"{len(niv)} niveau{'x' if len(niv) > 1 else ''} · emprise et volumes à l'échelle"
        if c:
            sous += f" · en blanc : circulations (×{fmt(c['valeur'], 2)})"
        entete(img, "Empilé par niveau", sous)
        cartouche(dr, "03 · Programme empilé", d["projet"]["nom"], "niveaux selon le programme · ce n'est pas un plan")
    return img


def image_liaisons(d, ents, hl, base_img, base, t=1.0):
    boites, etiq, cad = base
    img = base_img.copy()
    dr = ImageDraw.Draw(img, "RGBA")
    premier = {}
    for bt in boites:
        if bt[7] in ("int", "ext") and bt[8]["k"] == 0:
            premier.setdefault((bt[8]["l"]["code"], bt[8]["ent"]), bt)
            premier.setdefault((bt[8]["l"]["code"], None), bt)
    liens, vus = [], set()
    for bt in boites:
        if bt[7] not in ("int", "ext") or bt[8]["k"] != 0:
            continue
        l = bt[8]["l"]
        for li in l.get("liaisons") or []:
            code = li if isinstance(li, str) else li.get("vers")
            o = premier.get((code, bt[8]["ent"])) or premier.get((code, None))
            if not o or o is bt:
                continue
            cle = frozenset([id(bt), id(o)])
            if cle in vus:
                continue
            vus.add(cle)
            liens.append((bt, o))
    # voile clair pour que les liaisons ressortent
    dr.rectangle([0, 0, W, H], fill=FOND + (120,))
    vis = len(liens) if t >= 1 else max(1, int(math.ceil(ease(t) * len(liens))))
    for a, b in liens[:vis]:
        pa = ecran(cad, a[0] + a[3] / 2, a[1] + a[4], a[2] + a[5] / 2)
        pb = ecran(cad, b[0] + b[3] / 2, b[1] + b[4], b[2] + b[5] / 2)
        dist = math.hypot(pb[0] - pa[0], pb[1] - pa[1])
        m = ((pa[0] + pb[0]) / 2, (pa[1] + pb[1]) / 2 - 40 - dist * 0.25)
        pts = [((1 - s) ** 2 * pa[0] + 2 * (1 - s) * s * m[0] + s * s * pb[0],
                (1 - s) ** 2 * pa[1] + 2 * (1 - s) * s * m[1] + s * s * pb[1]) for s in np.linspace(0, 1, 40)]
        dr.line(pts, fill=ENCRE + (230,), width=4, joint="curve")
        for p in (pa, pb):
            dr.ellipse([p[0] - 8, p[1] - 8, p[0] + 8, p[1] + 8], fill=(255, 255, 255, 255), outline=ENCRE + (255,), width=3)
    dr.rectangle([0, 0, W, 170], fill=FOND + (255,))
    entete(img, "Les liaisons du programme", f"{len(liens)} liaisons écrites dans les fiches · rien n'est déduit")
    dr.rectangle([0, H - 100, W, H], fill=FOND + (255,))
    cartouche(ImageDraw.Draw(img), "04 · Liaisons", d["projet"]["nom"], "« accès direct », « à proximité », « liaison visuelle »")
    return img, len(liens)


def main():
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    d, ents = charger(sys.argv[1])
    sortie = sys.argv[2]
    os.makedirs(sortie, exist_ok=True)
    vid = "--sans-video" not in sys.argv
    hl = d.get("hauteur_lecture", 3.0)
    faits = []

    im = image_surfaces(d, ents)
    im.save(os.path.join(sortie, "01-surfaces.png"))
    faits.append("01-surfaces.png")
    if vid and video(os.path.join(sortie, "01-surfaces.mp4"), lambda t: image_surfaces(d, ents, t)):
        faits.append("01-surfaces.mp4")

    for num, mode in (("02", "eclate"), ("03", "empile")):
        base = scene(d, ents, mode, hl)
        im = image_3d(d, ents, mode, hl, base=base)
        nom = f"{num}-{mode}"
        im.save(os.path.join(sortie, nom + ".png"))
        faits.append(nom + ".png")
        if mode == "eclate":
            img_e, base_e = im, base
        if vid and video(os.path.join(sortie, nom + ".mp4"),
                         lambda t, b=base, m=mode: image_3d(d, ents, m, hl, t=t, S=1 if t < 1 else 2, base=b)):
            faits.append(nom + ".mp4")

    im, n = image_liaisons(d, ents, hl, img_e, base_e)
    im.save(os.path.join(sortie, "04-liaisons.png"))
    faits.append("04-liaisons.png")
    if vid and video(os.path.join(sortie, "04-liaisons.mp4"), lambda t: image_liaisons(d, ents, hl, img_e, base_e, t)[0]):
        faits.append("04-liaisons.mp4")

    im = image_contraintes(d)
    im.save(os.path.join(sortie, "05-contraintes.png"))
    faits.append("05-contraintes.png")
    if vid and video(os.path.join(sortie, "05-contraintes.mp4"), lambda t: image_contraintes(d, t)):
        faits.append("05-contraintes.mp4")

    print("Écrit dans", sortie, ":", ", ".join(faits))
    if not vid or not shutil.which("ffmpeg"):
        print("Pas de vidéo (ffmpeg absent ou --sans-video).")


if __name__ == "__main__":
    main()
