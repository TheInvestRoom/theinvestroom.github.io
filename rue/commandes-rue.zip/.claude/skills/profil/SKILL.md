---
name: profil
description: Le profil en travers coté de la rue.
argument-hint: "[photo de la rue]"
disable-model-invocation: true
---

Fais le profil en travers de cette rue, comme une coupe d'urbaniste au 1/200 : les deux façades qui se font face coupées en noir avec leurs étages, leurs combles et leur rez-de-chaussée, le sol de la rue (pavés, caniveau, bordures ou plateau), les terrasses, un réverbère, quelques personnages à l'échelle. Cotes : largeur entre façades, largeur de chaque bande (terrasse, passage piéton, caniveau), hauteur à l'égout de chaque immeuble, et en grand le rapport hauteur sur largeur (H/L) avec une phrase sur ce qu'il veut dire (rue en canyon ou rue ouverte).

Photo donnée : $ARGUMENTS (s'il n'y a rien, prends la photo de la rue du dossier courant).

Commence toujours comme ça :
1. Ouvre la photo et regarde-la vraiment : la rue, sa largeur, les trottoirs ou le plateau piéton, les immeubles des deux côtés (nombre d'étages, combles, rez-de-chaussée, terrasses, auvents), le carrefour, le mobilier (bornes, potelets, réverbères, poubelles), les gens, l'orientation probable d'après les ombres.
2. Si `rue.json` existe déjà, réutilise-le. Sinon, relève la rue par la perspective : point de fuite, lignes des égouts de toit et des trottoirs, puis déduis en mètres la largeur entre façades, la largeur des trottoirs et de la chaussée, la hauteur de chaque immeuble au premier plan (prends une hauteur d'étage plausible, 3,0 m pour les étages, 3,8 à 4,5 m pour le rez-de-chaussée, et écris qu'elle est supposée), l'emprise des terrasses et le mobilier. Si tu reconnais le lieu, dis-le, et sers-toi de ce que tu sais de son orientation en l'écrivant comme une hypothèse. Écris `rue.json` avec ce relevé et ce que tu n'as pas pu lire.
3. Vérifie ta lecture avant de dessiner : reprojette ton relevé en traits rouges fins sur la photo (`controle.png`), regarde-le et corrige `rue.json` tant que les égouts de toit, les étages et les trottoirs ne tombent pas sur la photo.

Dessine ensuite en code, avec un script Python (matplotlib, numpy, Pillow ; installe ce qui manque avec pip, et ffmpeg sert à la vidéo). Aucun générateur d'images : tout se calcule depuis `rue.json`.

Ce que tu rends, dans le dossier courant :
- `profil.png` : le dessin final, 1080 × 1920 en portrait, sans marge perdue. Le dessin occupe au moins 85 % de la largeur et se lit sur un téléphone : traits assez épais, textes d'au moins 26 px, couleurs franches. La place libre sert à la légende, jamais à du vide. Niveau d'un rendu d'école d'architecture ou d'agence, jamais un graphique de tableur. Pas de titre géant : un petit cartouche discret (nom du dessin, échelle graphique, nord si utile).
- `profil.mp4` : 3 s, 1080 × 1920, 30 i/s, H.264, yuv420p, où le dessin se construit sous les yeux (le sol se pose, les deux façades montent étage par étage, puis les cotes et le rapport H/L) et se termine sur l'image finale tenue les 20 dernières images. La première image n'est jamais vide.

Ouvre le PNG pour le regarder, et corrige s'il y a du texte coupé ou qui se chevauche, ou un dessin trop petit. Termine en disant en quelques lignes ce que le dessin montre, ce que tu as lu sur la photo et ce que tu as supposé parce qu'elle ne le dit pas. N'invente rien sans le dire.
