# capacite-parcelle — étude de capacité d'un terrain avec Claude

Donne une adresse ou une référence cadastrale ; Claude trouve la parcelle, lit le règlement de sa zone de PLU, cite
chaque règle avec sa page, calcule l'enveloppe et un volume indicatif, et te rend une page 3D, six images, une courte
vidéo et un rapport. Étude de premier niveau : elle ne remplace ni un certificat d'urbanisme ni un géomètre.

## Installer

**Claude Code** (recommandé : il faut un terminal, Python 3 et l'accès internet)
1. Copie le dossier `capacite-parcelle` dans `~/.claude/skills/` (tous tes projets) ou dans `.claude/skills/` de ton
   projet.
2. Lance Claude Code et tape : `/capacite-parcelle "12 rue Exemple 91120 Palaiseau"` ou
   `/capacite-parcelle "91477 AE 0443"` (code INSEE, section, numéro).

**Claude.ai** (dans les réglages, partie Skills, importer un skill) : zippe le dossier `capacite-parcelle` et importe le zip.
Il faut que l'exécution de code et l'accès web soient activés ; si l'environnement bloque les services de l'IGN,
télécharge toi-même le règlement PDF et donne-le à Claude avec la référence cadastrale.

## Ce qu'il faut sur la machine

- Python 3 (bibliothèque standard seulement pour les calculs ; PyMuPDF, pypdf ou pdftotext pour lire le PDF).
- Google Chrome, Chromium ou Edge pour les images ; ffmpeg pour la vidéo (sinon, seulement la page 3D et le rapport).
- Un accès internet : cadastre, BD TOPO et Géoportail de l'urbanisme (services publics gratuits de l'IGN), et
  Three.js chargé depuis unpkg.com par la page 3D.

## Ce que ça ne fait pas

Pas de plan de zonage graphique lu automatiquement (marges et hauteurs dessinées : à vérifier), pas d'OAP, pas de
servitudes de droit privé, terrain dessiné plat. Tout ce qui n'a pas pu être tranché est listé dans le rapport et
sur la dernière image.
