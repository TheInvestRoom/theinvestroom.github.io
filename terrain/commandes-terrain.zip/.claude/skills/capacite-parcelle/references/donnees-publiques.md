# Les données publiques utilisées, et leurs limites

Tout est gratuit et sans clé. Les données IGN et du Géoportail de l'urbanisme sont sous Licence Ouverte (Etalab 2.0) :
cite la source sur les images et dans le rapport.

| Besoin | Service | Ce qu'on en tire | Ce qui peut clocher |
|---|---|---|---|
| Adresse → point | Base Adresse Nationale `https://api-adresse.data.gouv.fr/search/?q=…` | coordonnées, code INSEE | une adresse en rue longue tombe parfois sur la parcelle d'en face : vérifie la référence trouvée |
| Point ou référence → parcelle | API Carto cadastre `https://apicarto.ign.fr/api/cadastre/parcelle` (`geom=` ou `code_insee`, `section`, `numero`) | identifiant `idu`, contenance | numéro sur 4 chiffres (`0443`), section en majuscules |
| Parcelles en Lambert 93 | WFS Géoplateforme `https://data.geopf.fr/wfs/ows`, couche `CADASTRALPARCELS.PARCELLAIRE_EXPRESS:parcelle`, `srsName=EPSG:2154` | polygone en mètres, voisines | `bbox` en latitude, longitude (ordre EPSG:4326) ; 3 000 objets au plus par requête |
| Bâtiments voisins | même WFS, `BDTOPO_V3:batiment` | emprise, `hauteur`, nombre d'étages, usage | hauteur absente ou approximative (mesure aérienne) ; bâtiment récent pas encore saisi |
| Rues | même WFS, `BDTOPO_V3:troncon_de_route` | nom, largeur de chaussée, voie privée ou non | axe de la chaussée, pas limite du domaine public |
| Zone du PLU et PDF | API Carto GPU `https://apicarto.ign.fr/api/gpu/zone-urba?geom=…` | libellé de zone, `partition`, `gpu_doc_id`, `nomfic` | commune au RNU ou en carte communale : pas de zone ; PLUi : le document est intercommunal |
| Règlement (PDF) | `https://data.geopf.fr/annexes/gpu/documents/<partition>/<gpu_doc_id>/<nomfic>` | le texte opposable publié | une modification récente peut ne pas être encore versée : vérifie la date sur le site de la commune |
| Prescriptions, informations, servitudes | API Carto GPU : `prescription-surf`, `-lin`, `-pct`, `info-surf`, `-lin`, `-pct`, `assiette-sup-s`, `-l`, `-p` | espaces protégés, marges, périmètres, PPR, monuments | toutes les servitudes ne sont pas numérisées : une absence ne prouve rien |
| Altitudes | `https://data.geopf.fr/altimetrie/1.0/calcul/alti/rest/elevation.json` (RGE ALTI) | dénivelé entre sommets | précision métrique : suffit pour repérer une pente, pas pour un projet |

## Si un service ne répond pas

- **Géoportail de l'urbanisme absent pour la commune** : le règlement est sur le site de la commune ou de
  l'intercommunalité ; demande le PDF à l'utilisateur et la zone (lue sur le plan de zonage).
- **WFS en panne** : la parcelle peut venir d'API Carto cadastre (en degrés) ; il faut alors la projeter en mètres
  (Lambert 93) avant tout calcul de retrait. Ne calcule jamais une distance en degrés.
- **Pas de Chrome** pour les images : `capacite.html` s'ouvre dans n'importe quel navigateur récent ; fais les
  captures à la main.

## Ce que ces données ne disent pas

Les limites exactes (seul un bornage par géomètre les fixe), les servitudes de droit privé (vues, passage, cour
commune), les réseaux, la nature du sol, l'avis de l'ABF, et les projets de la commune en cours de révision du PLU.
