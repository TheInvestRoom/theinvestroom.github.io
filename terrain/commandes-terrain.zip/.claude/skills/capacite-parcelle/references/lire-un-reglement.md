# Lire un règlement de PLU pour en tirer un gabarit

Un règlement se lit comme un contrat : le sens d'un chiffre dépend d'une définition écrite cinquante pages plus loin
et d'une exception glissée dans un « toutefois ». Ce fichier dit, article par article, ce qui change le calcul et où
une lecture rapide se trompe.

## Avant les articles : la structure du document

- **Depuis 2016**, les règlements « modernisés » sont en chapitres (destinations ; caractéristiques urbaines,
  architecturales, environnementales et paysagères ; équipements et réseaux). Les anciens gardent les **articles 1
  à 16** (article 6 = implantation par rapport aux voies, 7 = limites séparatives, 8 = entre bâtiments, 9 = emprise,
  10 = hauteur, 12 = stationnement, 13 = espaces libres). Cite la numérotation du document que tu lis.
- **Le lexique** (souvent en fin de document) reprend ou adapte le lexique national de l'urbanisme. Lis-le d'abord :
  « emprise au sol », « hauteur », « limite séparative », « vue », « terrain naturel » y sont définis, et une commune
  peut s'écarter du sens courant.
- **Les dispositions générales** s'appliquent à toutes les zones (bandes le long des grandes routes, berges,
  risques, règles pour les lotissements). Elles s'ajoutent à la zone, elles ne la remplacent pas.
- **Le règlement graphique** (plan de zonage) peut porter des règles que le texte ne contient pas : marges de recul,
  bandes constructibles dessinées, hauteurs par secteur, emplacements réservés, espaces verts protégés. Une partie
  remonte dans les prescriptions de `site.json` ; le reste demande d'ouvrir le plan.

## Implantation par rapport aux voies

- **D'où mesure-t-on ?** « L'alignement » = la limite entre le terrain et la voie publique (ou la limite future si
  un plan d'alignement ou un emplacement réservé d'élargissement existe). « L'axe de la voie » = le milieu de la
  chaussée : une règle comptée depuis l'axe (fréquente le long des routes départementales) ne se mesure pas depuis le
  bord de la parcelle. Si le texte dit « axe », pars de `dist_route` (axe de la chaussée de la BD TOPO, à quelques décimètres près) ; si la
  règle dépend de la largeur de la voie, `emprise_voie_m` donne la distance jusqu'à la parcelle d'en face.
- **Voies concernées.** « Voies publiques ou privées ouvertes à la circulation », « voie existante à la date
  d'approbation » : une impasse privée cadastrée peut compter comme voie. Vérifie le type des côtés.
- **Terrain d'angle.** Deux voies, donc deux retraits, et souvent une règle particulière (pan coupé, retrait réduit
  sur la voie secondaire, latérales qui deviennent toutes deux « latérales »). Cherche « angle » dans la zone.
- **Bande de constructibilité.** « Dans une bande de 20 m comptée depuis l'alignement » : la distance se compte
  perpendiculairement à l'alignement, et une construction peut parfois déborder de la bande si elle respecte une
  hauteur réduite. Lis ce qui est permis au-delà (annexes, garages, hauteur limitée).

## Implantation par rapport aux limites séparatives

- **Latérale ou fond.** Définie dans le lexique. Le calcul les déduit du cadastre ; si le règlement en a une autre
  définition (par exemple : toute limite qui aboutit à la voie est latérale, même si elle fait un angle), corrige les
  rôles dans `site.json`.
- **Avec ou sans vues.** La plupart des règlements distinguent les façades qui ont des « vues » (fenêtres, portes
  vitrées, balcons, terrasses surélevées) et les autres. Le lexique dit ce qui ne compte pas comme vue (jours de
  souffrance, verre translucide, châssis de toit placés haut). Ce sont deux variantes d'un même groupe.
- **Prospect.** « La distance est au moins égale à la moitié de la hauteur » (H/2) ou « à la hauteur » (L ≥ H).
  Quelle hauteur ? Lis la phrase entière : « hauteur à l'égout du toit le plus haut », « hauteur de la façade en
  vis-à-vis », « hauteur en tout point ». Ce choix déplace l'enveloppe de plusieurs mètres.
- **Le piège des pignons.** Si le prospect est calculé à l'égout, un pignon (mur triangulaire sous un toit à deux
  pentes) qui fait face à la limite monte jusqu'au faîtage : certains instructeurs le comptent à sa hauteur réelle.
  Et si la hauteur maximale vaut « en tout point de la façade », un pignon qui dépasse cette hauteur peut être refusé
  même si l'égout est conforme. Le calcul applique le prospect à l'égout ; écris le doute en `a_verifier`.
- **Implantation sur la limite.** Souvent permise sur une seule latérale, sur une longueur limitée, ou si le terrain
  est étroit. Le calcul ne dessine que l'implantation en retrait : signale l'autre possibilité, avec ce qu'elle
  gagnerait (une largeur de façade en plus).
- **Retrait d'une limite au choix.** « En tout point, à X m de l'une des limites séparatives, au choix » : c'est ce
  qui garantit un jardin. `retrait_au_choix` essaie chaque option.

## Hauteur

- **Point de départ.** « Terrain naturel avant travaux », « en tout point » : sur un terrain en pente, la hauteur
  permise suit la pente. Le calcul dessine un terrain plat ; au-delà d'un mètre de dénivelé sur la parcelle, dis que
  le volume réel sera plus bas côté bas du terrain (ou plus haut, si le texte mesure depuis le point bas).
- **Égout, acrotère, faîtage.** Égout = bas du toit en pente (la gouttière) ; acrotère = haut du muret d'un toit
  plat ; faîtage = sommet du toit. Un règlement donne souvent deux plafonds (égout et faîtage) : le volume en toit
  plat est limité par l'égout ou l'acrotère, le comble par le faîtage.
- **Niveaux.** « R+1+C » = rez-de-chaussée, un étage, combles. N'en déduis pas de mètres : si seuls des niveaux sont
  donnés, la hauteur d'étage est une hypothèse.
- **Hauteurs graphiques** (plans de hauteurs, épannelage) : à lire sur le plan, le calcul ne les a pas.

## Emprise au sol et espaces libres

- **Emprise au sol** : projection verticale de la construction, débords et surplombs compris (définition nationale),
  avec des exclusions locales (terrasses de moins de 60 cm, ornements, parfois piscines). Le pourcentage porte sur
  l'**unité foncière** (toutes les parcelles contiguës d'un même propriétaire), pas forcément sur une parcelle.
- **Pleine terre** : souvent « sans aucune construction en sous-sol » ; un parking enterré ne compte pas. Elle
  s'additionne avec l'emprise et les surfaces minérales (allées, stationnement extérieur) : vérifie que la somme
  tient dans la parcelle.
- **Coefficient de biotope**, surfaces éco-aménageables : à rapporter, pas à dessiner.

## Stationnement

- Lis l'unité : « par logement », « par tranche de X m² de surface de plancher », « entamée » ou « consommée », et
  vérifie ta formule sur les **exemples du texte**.
- **Près d'une gare** ou d'un transport en site propre, le code de l'urbanisme (articles L151-35 et L151-36) plafonne
  le nombre de places exigibles pour le logement, quel que soit le PLU. La prescription « périmètre de 500 m » de
  `site.json` en est souvent le signe.
- Les places se dessinent : 2,5 × 5 m chacune plus les circulations ; sur un petit terrain, elles mangent la pleine
  terre. Ne les dessine pas, mais dis si ça peut coincer.

## Les phrases qui renversent une lecture

- « Il n'est pas fixé de règle pour les équipements d'intérêt collectif » : ne concerne pas un projet de logement.
- « En cas d'extension d'une construction existante… » : règle plus souple, pour l'existant seulement.
- « Dans le cas d'un lotissement ou d'une division… les règles sont appréciées lot par lot » : la règle nationale
  (article R151-21 du code de l'urbanisme) les apprécie sur l'ensemble du projet, sauf si le règlement s'y oppose,
  comme ici. Ça change tout pour une division de terrain.
- « Nonobstant… », « toutefois… », « sauf… » : l'exception est souvent plus importante que la règle.

## Ce que le Géoportail de l'urbanisme peut signaler (champ `prescriptions_et_servitudes`)

Lis le **libellé**. Exemples rencontrés : « Espace vert » (espace protégé où l'on ne construit pas), « Marge de
retrait » (recul dessiné sur le plan), « PPRI » (règlement du plan de prévention à lire en plus), « Perimetre 500 m »
(autour d'une gare), « perimetre etude » (sursis à statuer possible), « Secteur avec interdiction de
constructibilité » ; côté servitudes : `ac1` (abords d'un monument historique, avis de l'architecte des Bâtiments de
France), `pm1` (plan de prévention des risques), `i4` (ligne électrique), `t1` (voie ferrée)… ; côté
informations : classement sonore des routes (isolation des façades), droit de préemption, taxe d'aménagement.
Aucune n'est à ignorer : chacune devient une ligne de `a_verifier` avec sa conséquence.
