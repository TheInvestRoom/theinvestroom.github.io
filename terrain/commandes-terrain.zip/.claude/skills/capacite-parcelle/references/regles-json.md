# Le format de `regles.json`

`regles.json` est la seule chose que tu écris à la main : c'est ta lecture du règlement. Le calcul n'invente rien ;
s'il manque une règle ici, elle manque dans l'enveloppe. Les chiffres des exemples sont fictifs : ne les reprends jamais sans les lire dans ton règlement.

## Structure

```json
{
  "zone": "UB",
  "document": {"titre": "…", "date": "…", "url": "https://…/reglement.pdf"},
  "regles": [ … ],
  "hypotheses": {"hauteur_etage_m": 2.9, "pente_toit_max_deg": 45, "batiments_existants": "aucun"},
  "hypotheses_texte": ["Hauteur d'étage de 2,9 m : hypothèse de dessin, pas une règle du PLU.", "…"],
  "a_verifier": [{"sujet": "…", "court": "…", "pourquoi": "…", "source": "p. 141"}]
}
```

Champs communs à chaque règle : `id` (court, unique), `nom`, `nom_court` (3 ou 4 mots, pour l'image 02), `type`,
`article`, `page`, `citation` (phrase **exacte** du texte extrait), `lecture` (ton interprétation, si tu en fais une).

## `depuis` : à partir de quels côtés

Une liste de types de côtés (`"voie"`, `"laterale"`, `"fond"`) ou d'identifiants de côtés de `site.json`
(`"voie_4"`, `"laterale_1"`…). Les distances sont mesurées au **segment le plus proche** de ces côtés, pas à la
droite qui les prolonge : c'est ce que fait un instructeur avec une règle graduée sur un plan masse.

## Les types géométriques

### `retrait` : une distance minimale

```json
{"id": "R1", "type": "retrait", "depuis": ["voie"], "min": 4}
```
Toute cellule à moins de `min` mètres des côtés visés est interdite.

### `prospect` : la distance dépend de la hauteur

« La distance doit être au moins égale à la moitié de la hauteur à l'égout, avec un minimum de 3 m » :
```json
{"id": "R3b", "type": "prospect", "depuis": ["laterale", "fond"], "ratio": 0.5, "min": 3, "applique_a": "egout"}
```
Le calcul inverse la règle : à une distance `d`, la hauteur permise est `d / ratio` (ici 2 × d), et rien sous `min`.
`L ≥ H` s'écrit `ratio: 1`. `applique_a` vaut `egout` (défaut), `faitage` ou `tout`, selon la hauteur que vise le
texte. C'est ce qui dessine les plans inclinés de l'enveloppe.

### `hauteur_bande` : la hauteur change avec la distance à la rue

```json
{"id": "R2", "type": "hauteur_bande", "depuis": ["voie"],
 "bandes": [{"jusqua": 20, "egout": 9, "faitage": 12},
            {"jusqua": null, "egout": 4, "acrotere": 4.5, "faitage": 7}]}
```
Les bandes se lisent dans l'ordre ; `jusqua: null` = au-delà. `acrotere` est gardé pour le rapport ; l'enveloppe est
calculée à l'égout (ou à l'acrotère si c'est la seule hauteur donnée : mets-la alors dans `egout`).

### `hauteur_max` : une hauteur unique

```json
{"id": "H", "type": "hauteur_max", "egout": 9, "faitage": 12}
```
Si le règlement donne des niveaux (« R+2+C ») et pas des mètres, n'invente pas de mètres : mets la hauteur en
mètres seulement si le texte la donne ailleurs, sinon note la règle en `a_verifier` et choisis `hauteur_etage_m`
pour dessiner R+2, en le disant.

### `bande_max` : bande de constructibilité

```json
{"id": "B", "type": "bande_max", "depuis": ["voie"], "max": 50}
```
Au-delà de `max` mètres des côtés visés, rien (sauf les annexes que le texte autorise : à mettre en `a_verifier`).

### `retrait_au_choix` : un retrait qu'on choisit

```json
{"id": "R4", "type": "retrait_au_choix", "parmi": ["laterale", "fond"], "min": 10}
```
Options essayées : chaque latérale seule, puis le fond entier (un fond découpé entre plusieurs voisins reste une
seule limite de fond). L'enveloppe garde l'option qui laisse le plus de surface, le volume indicatif celle qui donne
la plus grande surface de plancher. Une seule règle de ce type est prise en compte pour le volume indicatif.

## Variantes : `groupe` et `indicatif`

Deux règles du même `groupe` sont des **alternatives** : il suffit d'en respecter une. L'enveloppe maximale prend,
en chaque point, la plus permissive. Le volume indicatif prend celle qui porte `"indicatif": true` (sinon la plus
stricte).

```json
{"id": "R3a", "groupe": "limites", "indicatif": true, "variante": "façades avec vues", "type": "retrait", "depuis": ["laterale","fond"], "min": 6},
{"id": "R3b", "groupe": "limites", "variante": "façades sans vues", "type": "prospect", "depuis": ["laterale","fond"], "ratio": 0.5, "min": 3}
```

Les groupes peuvent être **par côté** : un groupe `laterales` (indicatif = sans vues, façades aveugles) et un groupe
`fond` (indicatif = avec vues). C'est souvent la seule lecture qui laisse un volume sur une parcelle étroite.

Pourquoi la variante « avec vues » pour le volume indicatif : un logement a des fenêtres sur ses longues façades ;
dessiner un volume qui ne tient qu'avec des façades aveugles promettrait une surface que peu de projets atteignent.

## Les types non géométriques

```json
{"id": "R5", "type": "emprise_max", "pourcentage": 40},
{"id": "R6", "type": "pleine_terre_min", "pourcentage": 30},
{"id": "R7", "type": "stationnement", "formule": "math.ceil(sdp/50)"}
```
`emprise_max` plafonne le volume indicatif. `pleine_terre_min` est rapportée (surface à garder). `formule` reçoit
`sdp` (surface de plancher brute du volume) et `math` ; cale-la sur les exemples du règlement s'il en donne, et dis
dans `lecture` pour combien de logements elle vaut (« 2 places par logement » s'écrit `"formule": "2"` pour une maison). N'invente pas de coefficient (« surface
réglementaire = 80 % de la brute », « logements de 70 m² ») pour obtenir un nombre : donne la règle par logement et
le nombre de places pour un ou deux programmes types que tu nommes comme tels (une règle « par logement » appliquée à toute la surface
surestime le nombre de places).

## Ce qui n'a pas de type, exprès

- Implantation **sur** une limite séparative avec une longueur maximale (« sur 10 m au plus »).
- « Respecter le gabarit de la construction voisine », « s'harmoniser avec… ».
- Hauteurs ou retraits portés **sur le plan de zonage** (marges de recul, polygones d'implantation, plans de
  hauteurs) : vérifie les prescriptions de `site.json`, puis le plan de zonage lui-même.
- Distances entre deux bâtiments sur un même terrain (le volume indicatif n'en dessine qu'un).

Écris-les dans `a_verifier`. Les forcer dans un type voisin donnerait une enveloppe fausse qui a l'air juste.

## Exemple de lecture (zone pavillonnaire type)

Un article « Les constructions doivent être implantées en retrait d'au moins 4 m de l'alignement » devient un
`retrait` depuis `voie` de 4 ; « la hauteur ne peut excéder 9 m à l'égout dans une bande de 20 m comptée depuis la
voie, 4 m au-delà » devient une `hauteur_bande` ; « en retrait des limites séparatives, la distance est au moins
égale à 6 m si la façade comporte des vues, sinon à la moitié de la hauteur avec un minimum de 3 m » devient deux
règles du même `groupe` ; « l'emprise au sol ne peut excéder 40 % de l'unité foncière » devient `emprise_max` 40.
