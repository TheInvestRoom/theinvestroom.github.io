"""Calcule l'enveloppe constructible d'une parcelle à partir de site.json et regles.json.

Usage :
    python calculer.py site.json regles.json dossier_sortie/

Écrit dans dossier_sortie/ :
    resultats.json   grille, calques par règle, choix faits, volume indicatif, chiffres
    capacite.html    page 3D autonome (Three.js par CDN), un calque par règle
    rapport.md       chiffres, règles citées, choix, hypothèses, ce qui reste à vérifier

Bibliothèque standard seulement. Les règles ne sont PAS lues ici : c'est le travail de
Claude dans regles.json (voir references/regles-json.md). Ce script ne fait que la géométrie.
"""
import json
import math
import os
import sys

PAS = 0.25         # taille d'une cellule de la grille, en mètres (0,5 au-delà de 2 500 m²)
INF = float("inf")
ICI = os.path.dirname(os.path.abspath(__file__))


# ------------------------------------------------------------------ géométrie de base
def dedans(x, y, ring):
    c = False
    n = len(ring)
    for i in range(n):
        x1, y1 = ring[i]
        x2, y2 = ring[(i + 1) % n]
        if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1) + x1:
            c = not c
    return c


def dist_seg(px, py, s):
    ax, ay, bx, by = s
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    t = 0 if L2 == 0 else max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / L2))
    return math.hypot(px - ax - t * dx, py - ay - t * dy)


def aire(ring):
    return abs(sum(x1 * y2 - x2 * y1 for (x1, y1), (x2, y2) in zip(ring, ring[1:] + ring[:1]))) / 2


# ------------------------------------------------------------------ repère et grille
def repere(site):
    """Axe u le long de la voie principale, axe v vers l'intérieur de la parcelle.

    Pourquoi : le volume indicatif est un rectangle parallèle à la rue, comme presque toutes
    les implantations en tissu pavillonnaire ; aligner la grille sur la rue évite un
    rectangle « en biais » qui perdrait de la surface pour rien.
    """
    voies = [c for c in site["cotes"] if c["type"] == "voie"]
    ref = max(voies or site["cotes"], key=lambda c: c["longueur"])
    s0, s1 = ref["segments"][0], ref["segments"][-1]
    dx, dy = s1[2] - s0[0], s1[3] - s0[1]
    L = math.hypot(dx, dy) or 1.0
    eu = (dx / L, dy / L)
    ev = (-eu[1], eu[0])  # gauche de l'arête = intérieur (anneau trigonométrique)
    poly = site["parcelle"]["polygone"]
    us = [p[0] * eu[0] + p[1] * eu[1] for p in poly]
    vs = [p[0] * ev[0] + p[1] * ev[1] for p in poly]
    return {"eu": eu, "ev": ev, "u0": min(us), "v0": min(vs),
            "nu": int(math.ceil((max(us) - min(us)) / PAS)),
            "nv": int(math.ceil((max(vs) - min(vs)) / PAS)), "voie_ref": ref["id"]}


def grille(site, R):
    poly = site["parcelle"]["polygone"]
    cells = []
    for j in range(R["nv"]):
        for i in range(R["nu"]):
            u = R["u0"] + (i + 0.5) * PAS
            v = R["v0"] + (j + 0.5) * PAS
            x = u * R["eu"][0] + v * R["ev"][0]
            y = u * R["eu"][1] + v * R["ev"][1]
            if dedans(x, y, poly):
                cells.append((i, j, x, y))
    return cells


def cotes_vises(site, depuis):
    """depuis = liste de types ('voie', 'laterale', 'fond') ou d'identifiants de côtés."""
    out = []
    for c in site["cotes"]:
        typ = c.get("role", c["type"]) if c["type"] == "separative" else c["type"]
        if typ in depuis or c["id"] in depuis:
            out.append(c)
    return out


def distances(cells, cotes):
    segs = [s for c in cotes for s in c["segments"]]
    if not segs:
        return [INF] * len(cells)
    return [min(dist_seg(x, y, s) for s in segs) for (_, _, x, y) in cells]


# ------------------------------------------------------------------ règles -> calques
def calque(regle, site, cells, cotes_option=None):
    """Retourne (egout, faitage) : une limite par cellule. INF = pas de limite, -1 = interdit."""
    t = regle["type"]
    n = len(cells)
    E = [INF] * n
    F = [INF] * n
    if t in ("retrait", "retrait_au_choix"):
        cotes = cotes_option if cotes_option is not None else cotes_vises(site, regle["depuis"])
        d = distances(cells, cotes)
        for k in range(n):
            if d[k] < regle["min"]:
                E[k] = F[k] = -1
    elif t == "bande_max":
        d = distances(cells, cotes_vises(site, regle["depuis"]))
        for k in range(n):
            if d[k] > regle["max"]:
                E[k] = F[k] = -1
    elif t == "prospect":
        # d >= ratio * H  <=>  H <= d / ratio ; et d >= min dans tous les cas
        d = distances(cells, cotes_vises(site, regle["depuis"]))
        cible = regle.get("applique_a", "egout")
        for k in range(n):
            if d[k] < regle.get("min", 0):
                E[k] = F[k] = -1
            else:
                h = d[k] / regle["ratio"]
                if cible in ("egout", "tout"):
                    E[k] = h
                if cible in ("faitage", "tout"):
                    F[k] = h
    elif t == "hauteur_bande":
        d = distances(cells, cotes_vises(site, regle["depuis"]))
        bandes = regle["bandes"]
        for k in range(n):
            for b in bandes:
                if b.get("jusqua") is None or d[k] <= b["jusqua"]:
                    E[k] = b.get("egout", INF)
                    F[k] = b.get("faitage", INF)
                    break
    elif t == "hauteur_max":
        E = [regle.get("egout", INF)] * n
        F = [regle.get("faitage", INF)] * n
    else:
        return None  # règle non géométrique (emprise, pleine terre, stationnement…)
    return E, F


def combiner(listes, mode):
    """mode 'min' : toutes les règles s'appliquent ; 'max' : il suffit d'une variante."""
    if not listes:
        return None
    f = min if mode == "min" else max
    return [f(vals) for vals in zip(*listes)]


def options_au_choix(regle, site):
    """« Au choix : latérale ou fond » : chaque latérale seule, ou tout le fond ensemble.

    Pourquoi : un fond de parcelle découpé en plusieurs voisins reste UNE limite de fond au
    sens du règlement ; une latérale, elle, est une limite à part entière.
    """
    opts = []
    parmi = regle["parmi"]
    for c in site["cotes"]:
        if c["type"] == "separative" and c.get("role") == "laterale" and "laterale" in parmi:
            opts.append((c["id"], [c]))
    if "fond" in parmi:
        fonds = [c for c in site["cotes"] if c["type"] == "separative" and c.get("role") == "fond"]
        if fonds:
            opts.append(("fond (" + ", ".join(c["id"] for c in fonds) + ")", fonds))
    for x in parmi:
        if x not in ("laterale", "fond"):
            opts.append((x, [c for c in site["cotes"] if c["id"] == x]))
    return opts


# ------------------------------------------------------------------ plus grand rectangle
def plus_grand_rectangle(masque, nu, nv):
    """Plus grand rectangle de cellules vraies (algorithme de l'histogramme), O(nu*nv)."""
    h = [0] * nu
    best = (0, None)
    for j in range(nv):
        for i in range(nu):
            h[i] = h[i] + 1 if masque[j][i] else 0
        pile = []
        for i in range(nu + 1):
            hh = h[i] if i < nu else 0
            debut = i
            while pile and pile[-1][1] >= hh:
                debut, hp = pile.pop()
                a = hp * (i - debut)
                if a > best[0]:
                    best = (a, (debut, j - hp + 1, i - 1, j))  # i0, j0, i1, j1
            pile.append((debut, hh))
    return best[1]


# ------------------------------------------------------------------ calcul principal
def calculer(site, regles):
    global PAS
    PAS = 0.25 if site["parcelle"]["surface_calculee_m2"] < 2500 else 0.5
    R = repere(site)
    cells = grille(site, R)
    n = len(cells)
    surface = site["parcelle"]["surface_calculee_m2"]
    hyp = regles.get("hypotheses", {})
    h_etage = hyp.get("hauteur_etage_m")
    if not h_etage:
        sys.exit("regles.json : hypotheses.hauteur_etage_m manque (hypothèse à écrire et à signaler).")

    calques = []      # pour la page : un calque par règle géométrique
    groupes = {}      # groupe -> liste de (regle, E, F)
    au_choix = []
    for r in regles["regles"]:
        if r["type"] == "retrait_au_choix":
            au_choix.append(r)
            continue
        cf = calque(r, site, cells)
        if cf is None:
            continue
        g = r.get("groupe") or r["id"]
        groupes.setdefault(g, []).append((r, cf[0], cf[1]))
        calques.append({"id": r["id"], "groupe": g, "E": cf[0], "F": cf[1]})

    def enveloppe(strict, exclure=()):
        E_l, F_l = [], []
        for g, lst in groupes.items():
            lst2 = [x for x in lst if x[0]["id"] not in exclure]
            if not lst2:
                continue
            if strict:
                choix = [x for x in lst2 if x[0].get("indicatif")] or lst2
                E_l.append(combiner([x[1] for x in choix], "min"))
                F_l.append(combiner([x[2] for x in choix], "min"))
            else:
                E_l.append(combiner([x[1] for x in lst2], "max"))
                F_l.append(combiner([x[2] for x in lst2], "max"))
        E = combiner(E_l, "min") or [INF] * n
        F = combiner(F_l, "min") or [INF] * n
        return E, F

    E_max, F_max = enveloppe(False)
    E_ind, F_ind = enveloppe(True)

    # --- règles « au choix » : on essaie chaque option et on garde la meilleure, en le disant
    choix_faits = []
    for r in au_choix:
        opts = options_au_choix(r, site)
        res = []
        for nom, cotes in opts:
            Eo, Fo = calque(r, site, cells, cotes_option=cotes)
            res.append((nom, Eo, Fo))
        if not res:
            continue
        def aire_ok(E):
            return sum(1 for e in E if e > 0) * PAS * PAS
        scores = [(aire_ok([min(a, b) for a, b in zip(E_max, o[1])]), o) for o in res]
        scores.sort(key=lambda s: -s[0])
        best = scores[0][1]
        E_max = [min(a, b) for a, b in zip(E_max, best[1])]
        F_max = [min(a, b) for a, b in zip(F_max, best[2])]
        r["_options"] = [(o[0], round(s, 1)) for s, o in scores]
        r["_retenue_max"] = best[0]
        r["_res"] = res
        calques.append({"id": r["id"], "groupe": r["id"], "E": best[1], "F": best[2],
                        "option": best[0]})
        choix_faits.append({"regle": r["id"], "options_m2_constructibles": r["_options"],
                            "retenue": best[0]})

    # --- volume indicatif : le meilleur rectangle parallèle à la rue, niveau par niveau
    bats_conserves = hyp.get("batiments_existants") == "conserves"
    emprise_pct = next((r["pourcentage"] for r in regles["regles"] if r["type"] == "emprise_max"), None)
    emprise_max = surface * emprise_pct / 100 if emprise_pct is not None else INF
    emprise_existante = 0.0
    sous_bati = set()
    if bats_conserves:
        for b in site["batiments"]:
            if b["sur_parcelle"]:
                emprise_existante += aire(b["poly"])
                for k, (_, _, x, y) in enumerate(cells):
                    if dedans(x, y, b["poly"]):
                        sous_bati.add(k)
    budget = emprise_max - emprise_existante
    w_min = hyp.get("largeur_min_batiment_m", 5.0)
    p_min = hyp.get("profondeur_min_batiment_m", 6.0)
    pente = math.radians(hyp.get("pente_toit_max_deg", 45))

    meilleur = None
    opts_ind = [(None, None, None)]
    for r in au_choix:
        opts_ind = [(o[0], o[1], o[2]) for o in r["_res"]]  # une seule règle au choix gérée
    for nom_opt, Eo, Fo in opts_ind:
        E_s = E_ind if Eo is None else [min(a, b) for a, b in zip(E_ind, Eo)]
        F_s = F_ind if Fo is None else [min(a, b) for a, b in zip(F_ind, Fo)]
        e_top = max([e for e in E_s if e > 0] or [0])
        nmax = int(math.floor(min(e_top, 200) / h_etage + 1e-9))
        for nlev in range(nmax, 0, -1):
            m = [[False] * R["nu"] for _ in range(R["nv"])]
            for k, (i, j, _, _) in enumerate(cells):
                if k not in sous_bati and E_s[k] >= nlev * h_etage - 1e-6:
                    m[j][i] = True
            rect = plus_grand_rectangle(m, R["nu"], R["nv"])
            if not rect:
                continue
            i0, j0, i1, j1 = rect
            w = (i1 - i0 + 1) * PAS
            p = (j1 - j0 + 1) * PAS
            if w < w_min or p < p_min:
                continue
            # plafond d'emprise : on raccourcit la profondeur en gardant le côté rue
            if w * p > budget:
                p_cap = math.floor(budget / w / PAS) * PAS
                if p_cap < p_min:
                    w = math.floor(budget / p_min / PAS) * PAS
                    p_cap = p_min
                    if w < w_min:
                        continue
                p = p_cap
                j1 = j0 + int(round(p / PAS)) - 1
                i1 = i0 + int(round(w / PAS)) - 1
            surf = w * p * nlev
            if not meilleur or surf > meilleur["surface_plancher_brute_m2"] + 1e-6:
                ks = [k for k, (i, j, _, _) in enumerate(cells) if i0 <= i <= i1 and j0 <= j <= j1]
                f_lim = min([F_s[k] for k in ks] or [INF])
                egout = nlev * h_etage
                court = min(w, p)
                faitage = egout
                if f_lim > egout + 1:
                    faitage = min(f_lim, egout + court / 2 * math.tan(pente))
                meilleur = {"option_au_choix": nom_opt, "niveaux": nlev, "largeur_m": w,
                            "profondeur_m": p, "emprise_m2": round(w * p, 1),
                            "surface_plancher_brute_m2": round(surf, 1),
                            "egout_m": round(egout, 2), "faitage_m": round(faitage, 2),
                            "faitage_autorise_m": None if f_lim == INF else round(f_lim, 2),
                            "rect_ij": [i0, j0, i1, j1],
                            "faitage_parallele_a": "rue" if w >= p else "profondeur"}
    # --- chiffres
    def surf_ok(E):
        return round(sum(1 for e in E if e > 0) * PAS * PAS, 1)

    places = None
    st = next((r for r in regles["regles"] if r["type"] == "stationnement"), None)
    if st and meilleur and st.get("formule"):
        places = eval(st["formule"], {"__builtins__": {}, "math": math},
                      {"sdp": meilleur["surface_plancher_brute_m2"]})
    pt_pct = next((r["pourcentage"] for r in regles["regles"] if r["type"] == "pleine_terre_min"), None)
    chiffres = {
        "surface_parcelle_calculee_m2": surface,
        "contenance_cadastrale_m2": site["parcelle"].get("contenance_cadastrale_m2"),
        "emprise_max_reglement_m2": None if emprise_pct is None else round(emprise_max, 1),
        "emprise_existante_conservee_m2": round(emprise_existante, 1),
        "zone_hors_retraits_m2_enveloppe_max": surf_ok(E_max),
        "zone_hors_retraits_m2_indicatif": surf_ok(
            E_ind if not meilleur or meilleur["option_au_choix"] is None else
            [min(a, b) for a, b in zip(E_ind, next(o[1] for o in opts_ind if o[0] == meilleur["option_au_choix"]))]),
        "hauteur_egout_max_m": max([e for e in E_max if 0 < e < INF] or [0]),
        "hauteur_faitage_max_m": max([f for f in F_max if 0 < f < INF] or [0]),
        "pleine_terre_min_m2": None if pt_pct is None else round(surface * pt_pct / 100, 1),
        "places_stationnement_indicatives": places,
    }
    if meilleur and pt_pct is not None:
        chiffres["reste_hors_volume_m2"] = round(surface - meilleur["emprise_m2"] - emprise_existante, 1)

    def js(L):
        return [None if v == INF else round(v, 2) for v in L]

    return {
        "pas_m": PAS, "repere": R,
        "cellules": [[c[0], c[1]] for c in cells],
        "calques": [{**c, "E": js(c["E"]), "F": js(c["F"])} for c in calques],
        "enveloppe_max": {"E": js(E_max), "F": js(F_max)},
        "enveloppe_indicative": {"E": js(E_ind), "F": js(F_ind)},
        "choix_faits": choix_faits,
        "volume_indicatif": meilleur,
        "chiffres": chiffres,
    }


# ------------------------------------------------------------------ rapport
def fr(x):
    """Nombre à la française (virgule décimale, espace des milliers) pour le rapport."""
    if isinstance(x, bool) or not isinstance(x, (int, float)):
        return x
    t = f"{x:,.1f}" if isinstance(x, float) else f"{x:,}"
    if t.endswith(".0"):
        t = t[:-2]
    return t.replace(",", " ").replace(".", ",")


def rapport(site, regles, res):
    p = site["parcelle"]
    c = res["chiffres"]
    v = res["volume_indicatif"]
    L = []
    L.append(f"# Étude de capacité indicative — parcelle {p['insee']} {p['section']} {p['numero']} ({p['commune']})\n")
    L.append(f"Zone **{regles.get('zone')}** — {regles.get('document', {}).get('titre', '')}  ")
    L.append(f"Règlement : {regles.get('document', {}).get('url', '')}  ")
    L.append(f"Données récupérées le {site['genere_le']} (cadastre IGN, BD TOPO, Géoportail de l'urbanisme).\n")
    L.append("> Étude de faisabilité de premier niveau, pour savoir si un terrain vaut une vraie étude. "
             "Elle ne remplace ni un certificat d'urbanisme, ni un géomètre, ni l'instruction en mairie.\n")
    L.append("## Chiffres\n")
    L.append("| | |\n|---|---|")
    L.append(f"| Surface de la parcelle (calculée sur le plan cadastral) | {fr(c['surface_parcelle_calculee_m2'])} m² |")
    L.append(f"| Contenance indiquée au cadastre | {fr(c['contenance_cadastrale_m2'])} m² |")
    if c["emprise_max_reglement_m2"] is not None:
        L.append(f"| Emprise au sol maximale permise par le pourcentage | {fr(c['emprise_max_reglement_m2'])} m² |")
    L.append(f"| Surface au sol hors retraits (lecture la plus favorable) | {fr(c['zone_hors_retraits_m2_enveloppe_max'])} m² |")
    L.append(f"| Surface au sol hors retraits (façades avec vues, lecture prudente) | {fr(c['zone_hors_retraits_m2_indicatif'])} m² |")
    L.append(f"| Hauteur maximale à l'égout / acrotère | {fr(c['hauteur_egout_max_m'])} m |")
    L.append(f"| Hauteur maximale au faîtage | {fr(c['hauteur_faitage_max_m'])} m |")
    if c["pleine_terre_min_m2"] is not None:
        L.append(f"| Pleine terre à garder au minimum | {fr(c['pleine_terre_min_m2'])} m² |")
    if v:
        L.append(f"| **Volume indicatif** | {fr(v['largeur_m'])} × {fr(v['profondeur_m'])} m, {fr(v['niveaux'])} niveau(x), "
                 f"égout {fr(v['egout_m'])} m, faîtage {fr(v['faitage_m'])} m |")
        L.append(f"| **Surface de plancher indicative (brute)** | **{fr(v['surface_plancher_brute_m2'])} m²** |")
    if c.get("places_stationnement_indicatives") is not None:
        L.append(f"| Places de stationnement exigées pour cette surface | {fr(c['places_stationnement_indicatives'])} |")
    L.append("")
    L.append("La surface de plancher indiquée est **brute** (au nu extérieur des murs, tous niveaux pleins). "
             "La surface de plancher réglementaire sera plus faible : elle se mesure au nu intérieur et déduit "
             "trémies, parties de moins de 1,80 m de hauteur, stationnement, etc.\n")
    L.append("## Règles appliquées (citées)\n")
    for r in regles["regles"]:
        L.append(f"**{r['id']} — {r.get('nom', r['type'])}** ({r.get('article', '')}, p. {r.get('page', '?')})  ")
        L.append(f"> {r.get('citation', '')}\n")
        if r.get("lecture"):
            L.append(f"Lecture : {r['lecture']}\n")
    if res["choix_faits"]:
        L.append("## Choix faits par le calcul\n")
        for ch in res["choix_faits"]:
            opts = "; ".join(f"{o[0]} → {o[1]} m² constructibles" for o in ch["options_m2_constructibles"])
            L.append(f"- {ch['regle']} : options essayées : {opts}. Retenue pour l'enveloppe : **{ch['retenue']}**.")
        if v and v.get("option_au_choix"):
            L.append(f"- Volume indicatif : option **{v['option_au_choix']}**.")
        L.append("")
    L.append("## Hypothèses (à confirmer)\n")
    for k, val in regles.get("hypotheses", {}).items():
        L.append(f"- `{k}` : {val}")
    for h in regles.get("hypotheses_texte", []):
        L.append(f"- {h}")
    L.append("")
    L.append("## Ce que Claude n'a pas pu trancher\n")
    for a in regles.get("a_verifier", []):
        L.append(f"- **{a['sujet']}** — {a['pourquoi']}" + (f" (source : {a['source']})" if a.get("source") else ""))
    L.append("")
    L.append("## Côtés de la parcelle (déduits du cadastre)\n")
    for ct in site["cotes"]:
        info = f" — {ct['route']} (axe à {ct['dist_route']} m)" if ct["type"] == "voie" else (
            f" — voisin {ct['voisin']}" if ct.get("voisin") else "")
        L.append(f"- {ct['id']} : {ct['longueur']} m{info}")
    return "\n".join(L) + "\n"


def main():
    if len(sys.argv) < 4:
        sys.exit(__doc__)
    site = json.load(open(sys.argv[1], encoding="utf-8"))
    regles = json.load(open(sys.argv[2], encoding="utf-8"))
    out = sys.argv[3]
    os.makedirs(out, exist_ok=True)
    res = calculer(site, regles)
    for r in regles["regles"]:
        for k in ("_res",):
            r.pop(k, None)
    with open(os.path.join(out, "resultats.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False)
    with open(os.path.join(out, "rapport.md"), "w", encoding="utf-8") as f:
        f.write(rapport(site, regles, res))
    gabarit = open(os.path.join(ICI, "gabarit.html"), encoding="utf-8").read()
    donnees = json.dumps({"site": site, "regles": regles, "res": res}, ensure_ascii=False)
    with open(os.path.join(out, "capacite.html"), "w", encoding="utf-8") as f:
        f.write(gabarit.replace("/*__DONNEES__*/null", donnees))
    print(json.dumps(res["chiffres"], ensure_ascii=False, indent=1))
    print(json.dumps(res["volume_indicatif"], ensure_ascii=False, indent=1))
    for ch in res["choix_faits"]:
        print("choix :", ch)


if __name__ == "__main__":
    main()
