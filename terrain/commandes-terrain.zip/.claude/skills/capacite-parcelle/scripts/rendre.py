"""Transforme capacite.html en 6 images 1080 x 1920 et en une vidéo courte.

Usage :
    python rendre.py dossier_sortie/            (images 01 à 06 + capacite.mp4)
    python rendre.py dossier_sortie/ --sans-video
    python rendre.py dossier_sortie/ --anonyme      (sans nom de rue sur les images)

Il faut Google Chrome, Chromium ou Edge (rendu WebGL sans écran) et, pour la vidéo, ffmpeg.
La page charge Three.js depuis unpkg.com : il faut un accès internet.
"""
import concurrent.futures as cf
import os
import pathlib
import shutil
import subprocess
import sys

CANDIDATS = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "google-chrome", "chromium", "chromium-browser", "microsoft-edge",
]


def trouver_chrome():
    for c in CANDIDATS:
        if os.path.isfile(c) or shutil.which(c):
            return c if os.path.isfile(c) else shutil.which(c)
    sys.exit("Chrome, Chromium ou Edge introuvable : ouvre capacite.html à la main et fais des captures.")


def capture(chrome, html, ancre, png):
    url = pathlib.Path(html).resolve().as_uri() + "#" + ancre + ("&anonyme=1" if "--anonyme" in sys.argv else "")
    subprocess.run([chrome, "--headless=new", "--use-angle=swiftshader", "--enable-unsafe-swiftshader",
                    "--hide-scrollbars", "--force-device-scale-factor=1", "--window-size=1080,1920",
                    "--virtual-time-budget=12000", f"--screenshot={png}", url],
                   check=True, capture_output=True)
    return png


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    dossier = os.path.abspath(sys.argv[1])
    html = os.path.join(dossier, "capacite.html")
    chrome = trouver_chrome()
    noms = {"01": "01_parcelle", "02": "02_retraits", "03": "03_emprise",
            "04": "04_enveloppe", "05": "05_volume", "06": "06_a_verifier"}
    with cf.ThreadPoolExecutor(6) as ex:
        list(ex.map(lambda k: capture(chrome, html, f"capture={k}", os.path.join(dossier, noms[k] + ".png")), noms))
    print("Images :", ", ".join(n + ".png" for n in noms.values()))

    if "--sans-video" in sys.argv:
        return
    if not shutil.which("ffmpeg"):
        print("ffmpeg absent : pas de vidéo (les images suffisent).")
        return
    fps, duree = 24, 11.0
    images = os.path.join(dossier, "_images")
    os.makedirs(images, exist_ok=True)
    n = int(fps * duree)
    with cf.ThreadPoolExecutor(6) as ex:
        list(ex.map(lambda i: capture(chrome, html, f"t={i / fps:.3f}",
                                      os.path.join(images, f"f{i:04d}.png")), range(n)))
    mp4 = os.path.join(dossier, "capacite.mp4")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-framerate", str(fps), "-i",
                    os.path.join(images, "f%04d.png"), "-c:v", "libx264", "-pix_fmt", "yuv420p",
                    "-crf", "18", mp4], check=True)
    shutil.rmtree(images)
    print("Vidéo :", mp4, f"({duree:.0f} s, {fps} i/s)")


if __name__ == "__main__":
    main()
