---
name: terrain-volume
description: Deuxième temps de /terrain. À partir du dossier terrain-…/ (site.json, regles.json, annonce.json), calcule l'enveloppe maximale et le volume indicatif sur la vraie parcelle avec les scripts de capacite-parcelle, rend les images (sans nom de rue), et la fiche verdict : surface de plancher brute indicative et prix de l'annonce rapporté au m² constructible. À charger après /terrain, ou quand on tape /terrain-volume suivi du dossier.
argument-hint: "<dossier terrain-…/ produit par /terrain>"
---

# Ce que je peux construire sur ce terrain ? (2/2 : le volume et le verdict)

Dossier : $ARGUMENTS (s'il n'y a rien, prends le seul dossier `terrain-*/` présent).

Lis d'abord le SKILL.md de `capacite-parcelle` (sections 5 et 6) : c'est lui qui fait le calcul.

1. **Calcule et rends** :
   ```
   python .claude/skills/capacite-parcelle/scripts/calculer.py <dossier>/site.json <dossier>/regles.json <dossier>/
   python .claude/skills/capacite-parcelle/scripts/rendre.py <dossier>/ --anonyme --sans-video
   ```
   Fais les vérifications à la main de capacite-parcelle (emprise = surface × pourcentage, largeur − retraits, hauteur sous
   la bande), puis **ouvre chaque image** et corrige ce qui cloche avant d'aller plus loin.
2. **La fiche verdict** : écris `<dossier>/verdict.json` (format en tête de `.claude/skills/terrain/scripts/verdict.py`) avec
   les chiffres du calcul, jamais d'autres : l'annonce (surface, prix), la parcelle, la zone, 4 à 6 lignes de règles
   (règle, chiffre, page), le chiffre principal = la surface de plancher brute indicative, et en `sous_chiffre` le prix de
   l'annonce divisé par cette surface (arrondi à 5 € près), écrit « ≈ … € par m² constructible ». Lance
   `python .claude/skills/terrain/scripts/verdict.py <dossier>/verdict.json` et regarde l'image : rien de coupé, rien qui
   chevauche.
3. **Ce que tu dis à la fin** : la surface de plancher brute indicative, le volume (niveaux, dimensions, hauteur), ce qui la
   limite le plus, le prix au m² constructible, et ce qui reste à vérifier, du plus lourd au plus léger. Rappelle que c'est
   une enveloppe maximale théorique et un volume indicatif, pas une autorisation de construire.
