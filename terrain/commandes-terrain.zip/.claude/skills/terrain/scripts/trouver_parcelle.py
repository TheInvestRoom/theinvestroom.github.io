"""Retrouve la parcelle d'une annonce de terrain : commune + rue + surface -> parcelles candidates du cadastre.

Usage :
    python trouver_parcelle.py --commune "Palaiseau" --cp 91120 --rue "avenue du Général Leclerc" --surface 535 [--tolerance 3]

Sources (gratuites, sans clé) : Base Adresse Nationale (la rue), Géoplateforme IGN WFS (parcelles du Parcellaire Express,
tronçons de route BD TOPO, bâtiments BD TOPO). Imprime les candidates triées et écrit candidates.json.
Une parcelle candidate n'est pas une preuve : c'est la contenance cadastrale qui colle et la rue qui la borde.
"""
import argparse, json, math, sys, unicodedata, urllib.parse, urllib.request


def get_json(url, params):
    with urllib.request.urlopen(url + "?" + urllib.parse.urlencode(params), timeout=90) as r:
        return json.load(r)


def simple(t):
    t = unicodedata.normalize("NFD", t or "").encode("ascii", "ignore").decode().lower()
    for m in ("avenue ", "rue ", "chemin ", "boulevard ", "allee ", "impasse ", "route ", "place ", "du ", "de la ", "des ", "de ", "d'", "l'", "le ", "la "):
        t = t.replace(m, " ")
    return " ".join(t.replace("-", " ").split())


def wfs(typ, bbox):
    s, w, n, e = bbox
    return get_json("https://data.geopf.fr/wfs/ows", {"service": "WFS", "version": "2.0.0", "request": "GetFeature",
        "typeNames": typ, "outputFormat": "application/json", "srsName": "EPSG:2154", "count": 3000,
        "bbox": f"{s},{w},{n},{e},urn:ogc:def:crs:EPSG::4326"})["features"]


def anneaux(g):
    if g["type"] == "Polygon":
        return [g["coordinates"][0]]
    if g["type"] == "MultiPolygon":
        return [p[0] for p in g["coordinates"]]
    return []


def lignes(g):
    if g["type"] == "LineString":
        return [g["coordinates"]]
    if g["type"] == "MultiLineString":
        return g["coordinates"]
    return []


def aire(r):
    return abs(sum(r[i][0] * r[i + 1][1] - r[i + 1][0] * r[i][1] for i in range(len(r) - 1))) / 2


def dseg(p, a, b):
    ax, ay, bx, by = a[0], a[1], b[0], b[1]
    dx, dy = bx - ax, by - ay
    t = 0 if dx == dy == 0 else max(0, min(1, ((p[0] - ax) * dx + (p[1] - ay) * dy) / (dx * dx + dy * dy)))
    return math.hypot(p[0] - ax - t * dx, p[1] - ay - t * dy)


def dedans(p, r):
    c = False
    for i in range(len(r) - 1):
        (x1, y1), (x2, y2) = r[i][:2], r[i + 1][:2]
        if (y1 > p[1]) != (y2 > p[1]) and p[0] < (x2 - x1) * (p[1] - y1) / (y2 - y1) + x1:
            c = not c
    return c


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--commune", required=True); ap.add_argument("--cp", default="")
    ap.add_argument("--rue", required=True); ap.add_argument("--surface", type=float, required=True)
    ap.add_argument("--tolerance", type=float, default=3.0, help="écart admis sur la contenance, en %%")
    a = ap.parse_args()
    d = get_json("https://api-adresse.data.gouv.fr/search/", {"q": f"{a.rue} {a.cp} {a.commune}", "type": "street", "limit": 1})
    if not d["features"]:
        sys.exit("Rue introuvable dans la Base Adresse Nationale.")
    f = d["features"][0]; lon, lat = f["geometry"]["coordinates"]; insee = f["properties"]["citycode"]
    print(f"Rue : {f['properties']['label']} (INSEE {insee}, score {f['properties']['score']:.2f})")
    cible = simple(f["properties"]["name"])
    dl, dn = 0.012, 0.012 / math.cos(math.radians(lat))
    bbox = (lat - dl, lon - dn, lat + dl, lon + dn)
    routes = [l for t in wfs("BDTOPO_V3:troncon_de_route", bbox)
              if cible and cible in simple(" ".join(str(t["properties"].get(k) or "") for k in
                 ("nom_voie_ban_gauche", "nom_voie_ban_droite", "nom_collaboratif_gauche", "nom_collaboratif_droite")))
              for l in lignes(t["geometry"])]
    if not routes:
        sys.exit("Aucun tronçon de cette rue dans la BD TOPO autour du point : vérifie le nom de la rue.")
    bats = [r for b in wfs("BDTOPO_V3:batiment", bbox) for r in anneaux(b["geometry"])]
    cands = []
    vues = {}
    for i in range(4):          # 3 000 objets au plus par requête : on découpe la zone en 16 tuiles
        for j in range(4):
            tuile = (bbox[0] + i * dl / 2, bbox[1] + j * dn / 2, bbox[0] + (i + 1) * dl / 2, bbox[1] + (j + 1) * dn / 2)
            for p in wfs("CADASTRALPARCELS.PARCELLAIRE_EXPRESS:parcelle", tuile):
                vues[p["properties"].get("idu") or p.get("id")] = p
    for p in vues.values():
        pr = p["properties"]
        if pr.get("code_insee") != insee:
            continue
        cont = float(pr.get("contenance") or 0)
        if not cont or abs(cont - a.surface) / a.surface * 100 > a.tolerance:
            continue
        r = anneaux(p["geometry"])[0]
        drue = min(dseg(v, l[i], l[i + 1]) for v in r for l in routes for i in range(len(l) - 1))
        if drue > 25:
            continue
        bati = sum(1 for b in bats if any(dedans(v, r) for v in b[:-1]))
        cands.append({"insee": insee, "section": pr["section"], "numero": pr["numero"], "contenance_m2": cont,
                      "surface_calculee_m2": round(aire(r), 1), "distance_rue_m": round(drue, 1), "batiments": bati})
    cands.sort(key=lambda c: (abs(c["contenance_m2"] - a.surface), c["distance_rue_m"]))
    json.dump({"rue": f["properties"]["label"], "surface_annonce": a.surface, "candidates": cands},
              open("candidates.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    if not cands:
        print("Aucune parcelle de cette surface le long de cette rue (à ± %s %%)." % a.tolerance)
    for c in cands:
        print(f"  {c['insee']} {c['section']} {c['numero']} : {c['contenance_m2']:.0f} m² au cadastre, à {c['distance_rue_m']} m de la rue, {c['batiments']} bâtiment(s)")


if __name__ == "__main__":
    main()
