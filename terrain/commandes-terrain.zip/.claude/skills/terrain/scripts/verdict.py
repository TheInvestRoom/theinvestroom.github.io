"""Fiche verdict d'une annonce de terrain : verdict.json -> verdict.html et verdict.png (1080 x 1920).

Usage :
    python verdict.py dossier/verdict.json

verdict.json :
{
  "annonce": "Terrain à bâtir · 535 m² · 329 000 €",
  "parcelle": "Palaiseau · 91477 BO 0160 · 535 m² au cadastre",
  "zone": "UR1 · zone résidentielle (PLU du 24/03/2025)",
  "constructible": true,
  "chiffre": "≈ 380 m²",                 # le chiffre principal, tel que calculé
  "chiffre_legende": "de plancher (brut, indicatif)",
  "sous_chiffre": "≈ 865 € par m² constructible",   # facultatif
  "lignes": [{"regle": "Emprise au sol", "valeur": "35 % → 187 m²", "source": "p. 138"}],
  "sources": "cadastre IGN, Géoportail de l'urbanisme, règlement p. 138-143"
}
Il faut Chrome, Chromium ou Edge.
"""
import html, json, pathlib, subprocess, sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "capacite-parcelle" / "scripts"))
from rendre import trouver_chrome  # noqa: E402

GABARIT = """<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8"><style>
html,body{margin:0;width:1080px;height:1920px;background:#F3EFE6;color:#1E1E1C;font-family:"Helvetica Neue",Helvetica,Arial,sans-serif}
.p{position:absolute;inset:0;padding:120px 84px;box-sizing:border-box;display:flex;flex-direction:column}
.k{font:600 28px/1 "Courier New",monospace;letter-spacing:.12em;color:#8C867B;text-transform:uppercase}
.annonce{margin-top:26px;font-size:46px;font-weight:700;line-height:1.15}
.parc{margin-top:54px;border-top:3px solid #1E1E1C;padding-top:22px;font-size:36px;line-height:1.35}
.parc b{font-weight:800}
.lignes{margin-top:46px}
.l{display:flex;justify-content:space-between;align-items:baseline;gap:24px;border-bottom:1px solid #d8d1c3;padding:20px 0;font-size:36px}
.l .r{color:#4b473f}.l .v{font-weight:800;text-align:right;font-variant-numeric:tabular-nums}
.l .s{display:block;font-size:24px;color:#8C867B;font-weight:400;margin-top:4px}
.bas{margin-top:auto}
.chiffre{font-size:200px;font-weight:900;letter-spacing:-.03em;line-height:1;color:COULEUR}
.leg{font-size:42px;font-weight:700;margin-top:14px}
.sous{font-size:40px;margin-top:22px;color:#4b473f}
.src{font-size:22px;color:#8C867B;margin-top:46px;line-height:1.4}
</style></head><body><div class="p">
<div class="k">L'annonce</div><div class="annonce">ANNONCE</div>
<div class="parc">PARCELLE<br>ZONE</div>
<div class="lignes">LIGNES</div>
<div class="bas"><div class="k">Ce que tu peux construire</div><div class="chiffre">CHIFFRE</div>
<div class="leg">LEGENDE</div>SOUS<div class="src">SOURCES</div></div>
</div></body></html>"""


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    src = pathlib.Path(sys.argv[1]).resolve()
    v = json.loads(src.read_text(encoding="utf-8"))
    e = html.escape
    lignes = "".join(
        f'<div class="l"><span class="r">{e(l["regle"])}{"<span class=s>" + e(l["source"]) + "</span>" if l.get("source") else ""}</span>'
        f'<span class="v">{e(l["valeur"])}</span></div>' for l in v.get("lignes", [])[:6])
    page = (GABARIT.replace("COULEUR", "#1E1E1C" if v.get("constructible", True) else "#B3372B")
            .replace("ANNONCE", e(v["annonce"])).replace("PARCELLE", "<b>" + e(v["parcelle"]) + "</b>")
            .replace("ZONE", e(v["zone"])).replace("LIGNES", lignes).replace("CHIFFRE", e(v["chiffre"]))
            .replace("LEGENDE", e(v.get("chiffre_legende", "")))
            .replace("SOUS", f'<div class="sous">{e(v["sous_chiffre"])}</div>' if v.get("sous_chiffre") else "")
            .replace("SOURCES", e(v.get("sources", ""))))
    page_html = src.with_name("verdict.html")
    page_html.write_text(page, encoding="utf-8")
    png = src.with_name("verdict.png")
    subprocess.run([trouver_chrome(), "--headless=new", "--hide-scrollbars", "--force-device-scale-factor=1",
                    "--window-size=1080,1920", f"--screenshot={png}", page_html.as_uri()], check=True, capture_output=True)
    print("Fiche :", png)


if __name__ == "__main__":
    main()
