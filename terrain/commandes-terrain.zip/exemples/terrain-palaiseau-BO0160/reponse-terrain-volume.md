## Terrain de Palaiseau (91477 BO 0160, zone UR1) : environ 297 m² de surface de plancher brute indicative

Le calcul est fait. J'ai vérifié les chiffres à la main et ouvert les six images et la fiche verdict : rien n'est coupé, rien ne se chevauche, le volume reste dans la parcelle. Je n'ai rien eu à corriger.

**Le volume indicatif**
- Une maison en **R+1** : 2 niveaux de 3 m (c'est une hypothèse de dessin, pas une règle).
- Au sol : **8,3 m × 18 m**, soit 148,5 m² d'emprise.
- Hauteur : **6 m à l'égout** pour 7 m permis, et 10,1 m au faîtage pour 11,5 m permis.
- Le volume est entre 5 m et 23 m de la rue, donc entièrement dans la bande des 25 m.

**Les vérifications à la main**
- **Emprise :** 520 m² × 35 % = 182 m². C'est calculé sur la surface mesurée de la parcelle ; sur les 535 m² du cadastre, on aurait 187 m².
- **Largeur :** 14,75 m de façade − 2 × 3 m de retrait ≈ 8,75 m. Les côtés sont un peu de biais par rapport à la rue, ce qui retire environ 0,5 m : on retombe sur les 8,25 m du calcul.
- **Profondeur :** 5 m de recul sur la rue et 12 m avant le fond (le fond est à environ 35 m de la rue). Le compte est juste à 25 cm près.

**Ce qui limite le plus**
1. **Les retraits, et non le pourcentage d'emprise.** Le règlement permettrait 182 m² au sol, mais une fois les retraits enlevés il ne reste que 177 m², et le plus grand rectangle qui tient fait 148,5 m².
2. **La parcelle est étroite (14,75 m).** Avec des fenêtres sur les côtés, il faudrait 8 m de retrait de chaque côté, ce qui ne laisse rien. J'ai donc supposé des façades latérales sans fenêtres, avec un retrait de la moitié de la hauteur (3 m ici). Les fenêtres donnent sur la rue et le jardin.
3. **Le retrait de 12 m d'une limite au choix.** Je l'ai pris au fond, parce que c'est le seul choix qui laisse une largeur utilisable. Il coupe la profondeur à 18 m.
4. **La hauteur de 7 m à l'égout**, qui fixe le R+1.

**Le prix :** 329 000 € / 297 m² ≈ **1 110 € par m² constructible**.

**Ce qui reste à vérifier, du plus lourd au plus léger**
1. **L'identité de la parcelle.** BO 0160 est très probable mais n'est pas confirmée par le vendeur. Si le terrain est un lot en cours de division, toute l'étude est à refaire.
2. **Le dénivelé de 6,9 m.** La hauteur se mesure en tout point depuis le terrain naturel, donc c'est le point bas qui compte. J'ai dessiné le terrain plat : le volume réel peut perdre de la hauteur, et un relevé topographique est indispensable.
3. **Le plan de zonage et les servitudes, non consultés.** Il peut y avoir un espace vert protégé, une marge de recul ou un emplacement réservé : que le Géoportail n'en montre pas ne prouve pas qu'il n'y en a pas.
4. **Construire sur une limite latérale.** C'est possible sur 10 m de long (plus 4 m à 4 m de haut). Le calcul ne le dessine pas, et cela ferait gagner environ 3,5 m de largeur.
5. **Les argiles.** Une étude de sol (G1/G2) est à prévoir pour les fondations.
6. **Le terrain n'est pas viabilisé.** Les raccordements (eau, assainissement, électricité) sont à chiffrer.
7. **La voie est classée bruyante (catégorie 4).** Cela impose une isolation acoustique, sans effet sur le volume.
8. **Le stationnement.** Il faut une place par tranche de 60 m² entamée, soit environ 5 places à loger hors pleine terre. Avec 208 m² de pleine terre minimum, il reste peu de place pour l'allée et les places.

Ce chiffre est une **enveloppe maximale théorique** avec un **volume indicatif**, établis à partir du règlement de la zone UR1. Ce n'est pas une autorisation de construire. La surface de plancher réglementaire, mesurée à l'intérieur des murs, sera plus faible. Un géomètre doit confirmer la surface et les limites, et seul un certificat d'urbanisme opérationnel ou le service urbanisme de Palaiseau peut confirmer la constructibilité.

Tout est dans `terrain-palaiseau-BO0160/` :
- `verdict.png` : la fiche verdict ;
- `01_parcelle.png` à `06_a_verifier.png` : les six images ;
- `capacite.html` : la page 3D ;
- `rapport.md` : le rapport.

--- fichier créé : capacite.html ---
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Étude de capacité</title>
<style>
  :root { --papier:#F3EFE6; --encre:#1E1E1C; --gris:#8C867B; --accent:#C8794A; --bleu:#3D5A80; }
  html,body { margin:0; height:100%; background:var(--papier); color:var(--encre);
    font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; overflow:hidden; }
  #scene { position:absolute; inset:0; }
  .etiq { position:absolute; transform:translate(-50%,-50%); white-space:nowrap; pointer-events:none;
    font-size:13px; letter-spacing:.02em; color:var(--encre); }
  .etiq.voie { font-weight:700; text-transform:uppercase; font-size:12px; color:#5d584f; }
  .etiq.cote { background:rgba(243,239,230,.85); padding:1px 4px; border-radius:3px; }
  .etiq.regle { font-weight:700; font-size:12px; padding:2px 6px; border-radius:3px; color:#fff; }
  #panneau { position:absolute; right:0; top:0; bottom:0; width:380px; background:rgba(243,239,230,.96);
    border-left:1px solid #d8d1c3; overflow:auto; padding:18px 18px 40px; box-sizing:border-box; font-size:14px; }
  #panneau h1 { font-size:18px; margin:0 0 4px; }
  #panneau h2 { font-size:12px; text-transform:uppercase; letter-spacing:.08em; color:var(--gris); margin:18px 0 8px; }
  .chiffre { display:flex; justify-content:space-between; border-bottom:1px solid #e2dccf; padding:5px 0; }
  .chiffre b { font-variant-numeric: tabular-nums; }
  .regle-l { border:1px solid #e2dccf; border-radius:6px; padding:8px 10px; margin:6px 0; background:#fbf9f4; }
  .regle-l label { display:flex; gap:8px; align-items:center; font-weight:600; cursor:pointer; }
  .pastille { width:12px; height:12px; border-radius:3px; flex:none; }
  .regle-l blockquote { margin:6px 0 0; font-size:12.5px; color:#4b473f; border-left:3px solid #d8d1c3; padding-left:8px; display:none; }
  .regle-l.ouverte blockquote { display:block; }
  .regle-l .src { font-size:11.5px; color:var(--gris); margin-top:4px; display:none; }
  .regle-l.ouverte .src { display:block; }
  .verif { margin:6px 0; padding-left:10px; border-left:3px solid var(--accent); font-size:13px; }
  .onglets button { font:inherit; font-size:13px; border:1px solid #cfc7b7; background:#fff; padding:5px 10px; border-radius:20px; cursor:pointer; }
  .onglets button.actif { background:var(--encre); color:#fff; border-color:var(--encre); }
  .petit { font-size:12px; color:var(--gris); }
  @media (max-aspect-ratio: 1/1) { #panneau { top:auto; width:100%; height:42%; border-left:0; border-top:1px solid #d8d1c3; } }
  /* ---- mode capture 1080 x 1920 ---- */
  body.capture #panneau { display:none; }
  #cartouche { display:none; position:absolute; left:64px; right:64px; bottom:70px; }
  #voile { display:none; position:absolute; left:0; right:0; bottom:0; height:34%;
    background:linear-gradient(to bottom, rgba(243,239,230,0) 0%, rgba(243,239,230,.92) 22%, #F3EFE6 40%); }
  body.capture #voile { display:block; }
  body.capture #cartouche { display:block; }
  #cartouche .num { font: 600 26px/1 "Courier New", monospace; color:var(--gris); letter-spacing:.1em; }
  #cartouche .titre { font-size:58px; font-weight:800; line-height:1.05; margin:14px 0 18px; letter-spacing:-.01em; }
  #cartouche .ligne { display:flex; gap:28px; flex-wrap:wrap; }
  #cartouche .bloc { border-top:3px solid var(--encre); padding-top:10px; min-width:200px; }
  #cartouche .bloc .v { font-size:44px; font-weight:800; font-variant-numeric:tabular-nums; }
  #cartouche .bloc .l { font-size:22px; color:#4b473f; margin-top:4px; }
  #cartouche .ref { font-size:20px; color:var(--gris); margin-top:22px; }
  #liste { display:none; position:absolute; left:64px; right:64px; top:120px; }
  body.capture.etape6 #liste { display:block; }
  #liste .it { font-size:31px; line-height:1.25; margin:0 0 26px; padding-left:22px; border-left:6px solid var(--accent); }
  #liste .it span { display:block; font-size:22px; color:#5d584f; margin-top:6px; }
  #nord { position:absolute; display:none; width:60px; text-align:center; font:700 22px Arial; }
  body.capture #nord { display:block; right:70px; top:70px; }
  #echelle { position:absolute; display:none; font: 18px Arial; }
  body.capture #echelle { display:block; left:64px; top:70px; }
</style>
</head>
<body>
<div id="scene"></div>
<div id="etiquettes"></div>
<div id="nord"><svg width="40" height="56" viewBox="0 0 40 56"><polygon id="fleche" points="20,2 34,40 20,32 6,40" fill="#1E1E1C"/></svg><div>N</div></div>
<div id="echelle"></div>
<div id="liste"></div>
<div id="voile"></div>
<div id="cartouche"><div class="num"></div><div class="titre"></div><div class="ligne"></div><div class="ref"></div></div>
<div id="panneau"></div>

<script type="importmap">
{ "imports": {
  "three": "https://unpkg.com/three@0.160.0/build/three.module.js",
  "three/addons/": "https://unpkg.com/three@0.160.0/examples/jsm/" } }
</script>
<script type="module">
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { mergeGeometries, mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js';

const D = {"site": {"genere_le": "2026-11-06T01:03", "sources": {"cadastre": "IGN Parcellaire Express (WFS data.geopf.fr) + API Carto cadastre", "batiments_routes": "IGN BD TOPO V3 (WFS data.geopf.fr)", "urbanisme": "Géoportail de l'urbanisme via API Carto GPU", "altimetrie": "IGN RGE ALTI (data.geopf.fr/altimetrie)"}, "adresse_geocodee": null, "parcelle": {"idu": "91477000BO0160", "commune": "Palaiseau", "insee": "91477", "section": "BO", "numero": "0160", "contenance_cadastrale_m2": 535, "surface_calculee_m2": 520.0, "polygone": [[-5.975, 18.868], [-8.685, -15.812], [5.975, -17.412], [7.425, -0.182], [7.955, 6.058], [8.935, 17.728]]}, "origine_lambert93": [643404.25, 6845164.17], "cotes": [{"type": "separative", "segments": [[-5.975, 18.868, -8.685, -15.812]], "longueur": 34.79, "voisin": "91477000BO0164", "route": "Avenue du Général Leclerc", "dist_route": 27.3, "largeur_chaussee": 5, "route_privee": false, "emprise_voie_m": null, "role": "laterale", "id": "laterale_1"}, {"type": "voie", "segments": [[-8.685, -15.812, 5.975, -17.412]], "longueur": 14.75, "voisin": null, "route": "Avenue du Général Leclerc", "dist_route": 8.9, "largeur_chaussee": 5, "route_privee": false, "emprise_voie_m": 19.0, "id": "voie_2"}, {"type": "separative", "segments": [[5.975, -17.412, 7.425, -0.182], [7.425, -0.182, 7.955, 6.058], [7.955, 6.058, 8.935, 17.728]], "longueur": 35.26, "voisin": "91477000BO0159", "route": "Avenue du Général Leclerc", "dist_route": 18.6, "largeur_chaussee": 5, "route_privee": false, "emprise_voie_m": null, "role": "laterale", "id": "laterale_3"}, {"type": "separative", "segments": [[8.935, 17.728, -5.975, 18.868]], "longueur": 14.95, "voisin": "91477000BO0161", "route": "Avenue du Général Leclerc", "dist_route": 45.9, "largeur_chaussee": 5, "route_privee": false, "emprise_voie_m": null, "role": "fond", "id": "fond_4"}], "voisins": [{"idu": "91477000BO0167", "poly": [[-44.215, -8.262], [-43.045, 14.728], [-42.635, 22.548], [-41.245, 49.648], [-31.215, 49.158], [-29.435, 49.068], [-31.075, 22.098], [-31.565, 14.228], [-33.375, -13.052], [-40.355, -9.902]]}, {"idu": "91477000BO0145", "poly": [[173.695, 93.608], [168.705, 92.378], [168.675, 91.488], [168.585, 88.058], [168.115, 70.138], [168.285, 37.278], [168.625, 1.618], [168.165, 1.478], [127.925, -8.182], [98.785, -15.482], [77.335, -19.282], [76.765, -3.872], [76.675, -1.582], [76.325, 6.958], [75.015, 37.478], [73.865, 69.898], [73.795, 71.928], [72.985, 94.658], [72.935, 95.678], [87.595, 94.478], [91.825, 93.978], [105.345, 93.168], [116.055, 92.848], [125.985, 92.578], [129.735, 92.488], [132.425, 92.498], [152.385, 94.558], [152.535, 95.848], [173.465, 98.138]]}, {"idu": "91477000BO0146", "poly": [[77.335, -19.282], [67.125, -21.362], [66.915, -21.352], [66.595, -13.542], [66.195, -4.282], [65.835, 4.208], [65.745, 6.448], [64.455, 37.128], [75.015, 37.478], [76.325, 6.958], [76.675, -1.582], [76.765, -3.872]]}, {"idu": "91477000BO0147", "poly": [[75.015, 37.478], [64.455, 37.128], [63.865, 51.338], [63.445, 61.638], [62.905, 74.758], [62.505, 83.898], [61.995, 95.428], [72.985, 94.658], [73.795, 71.928], [73.865, 69.898]]}, {"idu": "91477000BO0148", "poly": [[63.445, 61.638], [53.535, 61.318], [52.965, 74.478], [52.955, 74.938], [52.675, 81.488], [52.635, 82.578], [52.095, 95.298], [52.055, 96.118], [61.995, 95.428], [62.505, 83.898], [62.905, 74.758]]}, {"idu": "91477000BO0151", "poly": [[45.725, 22.498], [55.155, 22.888], [55.995, 5.178], [56.045, 3.988], [56.445, -4.672], [56.865, -13.372], [57.055, -17.682], [48.145, -18.082], [47.595, -18.112], [46.985, -5.032], [46.575, 3.968], [46.545, 4.748]]}, {"idu": "91477000BO0154", "poly": [[45.725, 22.498], [46.545, 4.748], [46.575, 3.968], [46.985, -5.032], [47.595, -18.112], [46.955, -18.132], [37.745, -18.552], [37.635, -15.982], [37.545, -14.082], [37.115, -5.432], [36.645, 3.608], [35.715, 22.098]]}, {"idu": "91477000BO0155", "poly": [[45.725, 22.498], [35.715, 22.098], [34.875, 38.508], [32.005, 96.478], [42.265, 95.878], [44.215, 55.438], [45.045, 37.478], [45.375, 30.258]]}, {"idu": "91477000BO0156", "poly": [[26.785, 38.168], [25.285, 98.458], [31.855, 97.848], [32.005, 96.478], [34.875, 38.508]]}, {"idu": "91477000BO0157", "poly": [[26.785, 38.168], [34.875, 38.508], [35.715, 22.098], [36.645, 3.608], [37.115, -5.432], [37.545, -14.082], [37.635, -15.982], [37.745, -18.552], [37.825, -20.212], [33.265, -20.072], [28.015, -19.912], [27.825, -7.722], [27.695, -2.142], [27.535, 4.708], [26.805, 36.978]]}, {"idu": "91477000BO0158", "poly": [[22.695, 16.668], [23.625, 16.598], [24.405, -16.502], [21.415, -18.932], [22.115, -10.162], [22.395, -5.732], [22.715, -1.092]]}, {"idu": "91477000BO0159", "poly": [[8.935, 17.728], [22.695, 16.668], [22.715, -1.092], [22.395, -5.732], [22.115, -10.162], [21.415, -18.932], [21.175, -19.142], [5.975, -17.412], [7.425, -0.182], [7.955, 6.058]]}, {"idu": "91477000BO0161", "poly": [[-5.615, 23.438], [9.315, 22.248], [8.935, 17.728], [-5.975, 18.868]]}, {"idu": "91477000BO0162", "poly": [[26.805, 36.978], [27.535, 4.708], [27.695, -2.142], [27.825, -7.722], [28.015, -19.912], [21.175, -19.142], [21.415, -18.932], [24.405, -16.502], [23.625, 16.598], [22.695, 16.668], [8.935, 17.728], [9.315, 22.248], [-5.615, 23.438], [-4.385, 39.178], [9.975, 38.168], [17.715, 37.618]]}, {"idu": "91477000BO0163", "poly": [[26.785, 38.168], [26.805, 36.978], [17.715, 37.618], [9.975, 38.168], [-4.385, 39.178], [-5.615, 23.438], [-13.175, 24.028], [-13.605, 24.068], [-17.945, 24.408], [-17.035, 38.858], [-16.425, 48.448], [-13.025, 102.078], [-12.845, 102.078], [25.285, 98.458]]}, {"idu": "91477000BO0164", "poly": [[-5.615, 23.438], [-5.975, 18.868], [-8.685, -15.812], [-15.085, -15.102], [-18.825, -14.712], [-20.365, -14.532], [-19.325, 0.358], [-18.945, 6.848], [-18.785, 9.748], [-18.735, 10.638], [-18.165, 20.608], [-17.945, 24.408], [-13.605, 24.068], [-13.175, 24.028]]}, {"idu": "91477000BO0165", "poly": [[-17.945, 24.408], [-18.165, 20.608], [-18.735, 10.638], [-18.785, 9.748], [-18.945, 6.848], [-19.325, 0.358], [-20.365, -14.532], [-33.375, -13.052], [-31.565, 14.228], [-31.075, 22.098], [-29.435, 49.068], [-16.425, 48.448], [-17.035, 38.858]]}, {"idu": "91477000BO0166", "poly": [[-44.505, -13.942], [-44.215, -8.262], [-40.355, -9.902], [-33.375, -13.052]]}, {"idu": "91477000BO0168", "poly": [[-16.425, 48.448], [-29.435, 49.068], [-31.215, 49.158], [-29.485, 84.418], [-29.165, 90.778], [-28.845, 97.318], [-28.605, 102.288], [-13.025, 102.078]]}, {"idu": "91477000BO0169", "poly": [[-41.245, 49.648], [-40.935, 55.948], [-44.115, 56.088], [-48.515, 56.288], [-48.235, 63.578], [-48.155, 65.608], [-47.835, 73.648], [-47.715, 76.798], [-47.595, 79.908], [-46.605, 79.858], [-39.765, 79.548], [-39.715, 80.838], [-39.445, 88.428], [-39.395, 89.958], [-39.355, 91.358], [-39.125, 97.888], [-38.965, 102.438], [-34.975, 102.358], [-28.605, 102.288], [-28.845, 97.318], [-29.165, 90.778], [-29.485, 84.418], [-31.215, 49.158]]}, {"idu": "91477000BO0170", "poly": [[-47.595, 79.908], [-47.315, 88.798], [-47.265, 90.348], [-46.935, 100.308], [-46.875, 102.038], [-40.105, 102.368], [-38.965, 102.438], [-39.125, 97.888], [-39.355, 91.358], [-39.395, 89.958], [-39.445, 88.428], [-39.715, 80.838], [-39.765, 79.548], [-46.605, 79.858]]}, {"idu": "91477000BO0196", "poly": [[64.455, 37.128], [65.745, 6.448], [65.835, 4.208], [66.195, -4.282], [66.595, -13.542], [66.915, -21.352], [59.255, -20.822], [57.195, -20.772], [57.055, -17.682], [56.865, -13.372], [56.445, -4.672], [56.045, 3.988], [55.995, 5.178], [55.155, 22.888], [53.965, 50.978], [63.865, 51.338]]}, {"idu": "91477000BO0197", "poly": [[63.865, 51.338], [53.965, 50.978], [53.545, 61.078], [53.535, 61.318], [63.445, 61.638]]}, {"idu": "91477000BO0228", "poly": [[45.725, 22.498], [45.375, 30.258], [45.045, 37.478], [44.215, 55.438], [42.265, 95.878], [44.045, 95.768], [45.635, 60.718], [53.545, 61.078], [53.965, 50.978], [55.155, 22.888]]}, {"idu": "91477000BO0229", "poly": [[53.535, 61.318], [53.545, 61.078], [45.635, 60.718], [44.045, 95.768], [52.095, 95.298], [52.635, 82.578], [52.675, 81.488], [52.955, 74.938], [52.965, 74.478]]}, {"idu": "91477000BO0244", "poly": [[-46.875, 102.038], [-46.935, 100.308], [-47.265, 90.348], [-47.315, 88.798], [-47.595, 79.908], [-47.715, 76.798], [-47.835, 73.648], [-48.155, 65.608], [-48.235, 63.578], [-48.515, 56.288], [-44.115, 56.088], [-40.935, 55.948], [-41.245, 49.648], [-42.635, 22.548], [-43.045, 14.728], [-44.215, -8.262], [-44.505, -13.942], [-118.555, -18.812], [-124.275, -19.122], [-156.195, -21.532], [-156.205, -21.302], [-156.385, -13.262], [-156.575, -5.312], [-156.735, 6.368], [-157.195, 22.708], [-157.615, 48.018], [-158.365, 83.408], [-107.055, 92.138], [-95.015, 93.998], [-84.715, 95.728], [-66.545, 99.518], [-57.365, 101.298], [-51.765, 102.408]]}, {"idu": "91477000AW0351", "poly": [[95.845, -35.292], [92.545, -56.782], [91.165, -65.732], [87.575, -89.112], [76.015, -86.882], [80.205, -63.772], [81.795, -54.712], [84.715, -38.032]]}, {"idu": "91477000AW0352", "poly": [[67.355, -140.522], [63.195, -139.802], [67.345, -116.282], [71.725, -91.392], [80.805, -39.002], [84.715, -38.032], [81.795, -54.712], [80.205, -63.772], [76.015, -86.882], [87.575, -89.112], [86.355, -96.332], [84.605, -107.642], [80.145, -136.452], [79.125, -143.352], [77.125, -142.802], [71.185, -141.182]]}, {"idu": "91477000AW0359", "poly": [[80.805, -39.002], [71.725, -91.392], [48.845, -85.772], [60.525, -43.322], [62.855, -41.262], [70.875, -40.292], [81.055, -37.202], [80.945, -38.172]]}, {"idu": "91477000BO0152", "poly": [[57.195, -20.772], [48.215, -20.512], [47.705, -20.502], [47.595, -18.112], [48.145, -18.082], [57.055, -17.682]]}, {"idu": "91477000BO0153", "poly": [[47.595, -18.112], [47.705, -20.502], [47.015, -20.482], [37.825, -20.212], [37.745, -18.552], [4

--- fichier créé : rapport.md ---
# Étude de capacité indicative — parcelle 91477 BO 0160 (Palaiseau)

Zone **UR1** — Palaiseau — PLU, 6. Règlement (révisé le 25 juin 2018, modification approuvée le 24 mars 2025)  
Règlement : https://data.geopf.fr/annexes/gpu/documents/DU_91477/e6219e2b37cf79f6c55e983adfe5d336/91477_reglement_20250324.pdf  
Données récupérées le 2026-11-06T01:03 (cadastre IGN, BD TOPO, Géoportail de l'urbanisme).

> Étude de faisabilité de premier niveau, pour savoir si un terrain vaut une vraie étude. Elle ne remplace ni un certificat d'urbanisme, ni un géomètre, ni l'instruction en mairie.

## Chiffres

| | |
|---|---|
| Surface de la parcelle (calculée sur le plan cadastral) | 520 m² |
| Contenance indiquée au cadastre | 535 m² |
| Emprise au sol maximale permise par le pourcentage | 182 m² |
| Surface au sol hors retraits (lecture la plus favorable) | 177 m² |
| Surface au sol hors retraits (façades avec vues, lecture prudente) | 177 m² |
| Hauteur maximale à l'égout / acrotère | 7 m |
| Hauteur maximale au faîtage | 11,5 m |
| Pleine terre à garder au minimum | 208 m² |
| **Volume indicatif** | 8,2 × 18 m, 2 niveau(x), égout 6 m, faîtage 10,1 m |
| **Surface de plancher indicative (brute)** | **297 m²** |
| Places de stationnement exigées pour cette surface | 5 |

La surface de plancher indiquée est **brute** (au nu extérieur des murs, tous niveaux pleins). La surface de plancher réglementaire sera plus faible : elle se mesure au nu intérieur et déduit trémies, parties de moins de 1,80 m de hauteur, stationnement, etc.

## Règles appliquées (citées)

**EMP — Emprise au sol maximale** (UR, chap. 2, 1/A, p. 138)  
> Dans la zone UR1 : L’emprise au sol maximale des constructions est fixée à 35 % de la superficie de l’unité foncière.

Lecture : 535 m² × 35 % = 187 m² sur la contenance cadastrale (182 m² sur la surface calculée de 520 m²). L'emprise inclut « tous débords et surplombs » et les terrasses à plus de 60 cm du terrain (définitions, p. 308) : avec 6,9 m de dénivelé, une terrasse côté bas compte vite.

**PT — Espace vert de pleine terre** (UR, chap. 2, 3, p. 150)  
> Dans la zone UR1, une part de 40 % minimum de la superficie de l’unité foncière doit être conservée en espace vert de pleine terre.

Lecture : 214 m² à garder en vraie pleine terre (rien dessous sur 4 m, ni allée, ni stationnement, ni terrasse : définitions p. 308-309). Il reste 535 − 187 − 214 ≈ 134 m² pour l'accès, le stationnement extérieur et les terrasses.

**RV — Retrait par rapport à la voie** (UR, chap. 2, 1/C, p. 139)  
> Toute nouvelle construction devra être implantée en retrait de la voie existante ouverte à la circulation à la date d’approbation du présent règlement, avec une distance minimum de 5 mètres.

Lecture : 5 m comptés depuis la limite de la parcelle sur l'avenue (l'alignement), pas depuis l'axe.

**H — Hauteur selon la bande de 25 m** (UR, chap. 2, 1/B, p. 138)  
> La hauteur des constructions ne doit pas excéder : Dans la bande des 25 mètres comptée à partir de la limite de voirie : - 7 mètres à l’égout du toit ou l’acrotère pour les toitures terrasses, - 11,50 mètres au faîtage. Au-delà de la limite de 25 mètres comptée à partir de la limite de voirie : - 3,5 mètres à l’égout du toit ou 4 mètres à l’acrotère pour les toitures terrasses, - 7 mètres au faîtage

Lecture : La hauteur se mesure « à compter du terrain naturel existant avant travaux en tout point de la construction » (définitions, p. 309) : sur un terrain qui descend de près de 7 m, c'est le point bas qui fixe la hauteur. Avec 5 m de recul et 12 m de retrait au fond, tout le volume tombe dans la bande des 25 m.

**RLa — Limites latérales, façade avec vues** (UR, chap. 2, 1/D, p. 142)  
> Dans la zone UR1 : En cas d’implantation en retrait de la limite séparative, la distance doit être au moins égale à : - 8 mètres si la façade en vis-à-vis de la limite séparative comporte des ouvertures créant des vues

Lecture : Sur 14,75 m de façade, 8 m des deux côtés ne laissent rien : les latérales seront aveugles (ou une seule fenêtrée, avec l'autre façade en limite).

**RLb — Limites latérales, façade sans vues** (UR, chap. 2, 1/D, p. 143)  
> - la moitié de la hauteur à l'égout du toit le plus haut, avec un minimum de 2,5 mètres si la façade en vis-à-vis de la limite séparative ne comporte pas d’ouvertures créant des vues au sens du présent règlement.

Lecture : À 7 m d'égout : 3,5 m de chaque latérale. Le texte vise « l'égout du toit le plus haut » : c'est la hauteur du bâtiment qui fixe le retrait de toute la façade, pas la hauteur point par point ; le prospect incliné dessiné ici est l'enveloppe la plus large, le volume indicatif doit garder 3,5 m.

**RFa — Fond de parcelle, façade avec vues** (UR, chap. 2, 1/D, p. 142)  
> Dans la zone UR1 : En cas d’implantation en retrait de la limite séparative, la distance doit être au moins égale à : - 8 mètres si la façade en vis-à-vis de la limite séparative comporte des ouvertures créant des vues

Lecture : Le texte parle des limites séparatives sans distinguer latérales et fond. Ici sans effet propre : le retrait de 12 m (règle R12) s'applique au fond.

**RFb — Fond de parcelle, façade sans vues** (UR, chap. 2, 1/D, p. 143)  
> - la moitié de la hauteur à l'égout du toit le plus haut, avec un minimum de 2,5 mètres si la façade en vis-à-vis de la limite séparative ne comporte pas d’ouvertures créant des vues au sens du présent règlement.

**R12 — Retrait de 12 m d'une limite au choix** (UR, chap. 2, 1/D, p. 143)  
> Par ailleurs, les constructions principales doivent être implantées, en tout point de la construction, en retrait avec un minimum de 12 mètres de l’une des limites séparatives (au choix : latérale ou fond de parcelle).

Lecture : Sur 14,75 m de large, 12 m d'une latérale ne laisseraient que 2,75 m : le choix sera le fond. Profondeur constructible alors : de 5 m à environ 23 m de l'avenue (≈ 18 m).

**STAT — Stationnement des logements** (UR, chap. 2, 4/A, p. 151)  
> • 1 place de stationnement par tranche consommée de 60 m² de surface de plancher (exemple : obligation de stationnement pour un logement de : 40 m² SDP = 1 place ; 70 m² SDP = 2 places ; 120 m² SDP = 3 places)

Lecture : Les exemples du texte (40 → 1, 70 → 2, 120 → 3) ne collent pas à un arrondi supérieur de sdp/60 (120 → 2) : la formule qui les reproduit est floor(sdp/60) + 1. Elle vaut pour UN logement (une maison) ; pour plusieurs logements, appliquer par logement et ajouter « au moins 1 place de stationnement supplémentaire par tranche de 3 logements » dès 3 logements. 50 % des places (arrondi inférieur) intégrées à la construction ; places commandées interdites si plusieurs logements. Exemple : une maison de 150 m² → 3 places, dont 1 dans la construction.

## Choix faits par le calcul

- R12 : options essayées : fond (fond_4) → 177.0 m² constructibles; laterale_1 → 9.8 m² constructibles; laterale_3 → 9.7 m² constructibles. Retenue pour l'enveloppe : **fond (fond_4)**.
- Volume indicatif : option **fond (fond_4)**.

## Hypothèses (à confirmer)

- `hauteur_etage_m` : 3.0
- `pente_toit_max_deg` : 45
- `batiments_existants` : aucun (BD TOPO, 0 bâtiment sur la parcelle)
- Hauteur d'étage de 3,0 m : hypothèse de dessin pour du logement, pas une règle du PLU. Avec 7 m à l'égout : rez-de-chaussée + 1 étage, et des combles sous le faîtage de 11,50 m.
- Parcelle retenue : 91477 BO 0160, seule candidate à exactement 535 m² sur l'avenue, façade 14,75 m ≈ « environ 15 m ». Non confirmée par le vendeur.
- Secteur UR1 : donné par le Géoportail de l'urbanisme (libellé « UR1 », zone résidentielle). Le règlement n'a qu'un chapitre UR, avec ses règles UR1 et UR2 séparées ; seules les règles UR1 sont reprises.
- Latérales traitées sans vues (H/2, 2,5 m minimum), fenêtres sur la rue et le jardin : 8 m des deux côtés ne laisseraient aucune largeur sur 14,75 m.
- Retrait de 12 m pris au fond : c'est la seule option qui laisse une largeur utile.
- Terrain dessiné plat, alors que les sommets cadastraux vont de 70,8 à 77,7 m (RGE ALTI).

## Ce que Claude n'a pas pu trancher

- **Identité de la parcelle** — L'annonce ne donne pas la référence. BO 0160 est la seule à 535 m² exactement en bord d'avenue ; si le terrain est un lot en cours de division (BO 0157, 0159, 0160 sont voisines), la parcelle et ses limites changent. Le règlement s'apprécie alors lot par lot. (source : trouver_parcelle.py ; règlement p. 138)
- **Dénivelé de 6,9 m** — La hauteur est mesurée « à compter du terrain naturel existant avant travaux en tout point de la construction » : sur la partie basse (≈ 70,8 m, côté BO 0159), 7 m d'égout se comptent depuis ce point. Le creux au milieu du côté droit peut aussi être un artefact du modèle de terrain. Un relevé topographique est indispensable. (source : définitions p. 309 ; RGE ALTI)
- **Implantation sur une limite latérale** — Dans la bande de 25 m, la construction peut s'implanter sur une seule limite latérale (façade ≥ 13 m), sur 10 m au plus, prolongés de 4 m à 4 m de haut. Le calcul ne dessine pas ce cas : il gagnerait environ 3,5 m de largeur sur 10 m de long. (source : p. 141)
- **Plan de zonage non consulté** — Le Géoportail ne rattache à la parcelle qu'une information (classement sonore). Une absence dans l'API n'est pas une preuve d'absence : vérifier sur le plan de zonage et le plan des servitudes (espace vert protégé, marge de reculement, bande constructible, emplacement réservé, corridor écologique). (source : API Carto GPU ; dispositions générales p. 8-11, 15)
- **Retrait-gonflement des argiles** — La commune comporte des secteurs argileux ; précautions de fondation. Une étude géotechnique est obligatoire à la vente d'un terrain à bâtir en zone d'aléa moyen ou fort. (source : p. 6)
- **Non viabilisé** — L'annonce le dit : raccordements eau, assainissement, électricité à chiffrer auprès des concessionnaires. (source : annonce)
- **Classement sonore** — « RD categorie 4 » : isolation acoustique renforcée des façades sur l'avenue ; pas d'effet sur le volume. (source : Géoportail (info-surf) ; p. 16)
- **Garage dans la bande de 5 m** — Un garage peut être construit à l'alignement si son emprise reste sous 20 % de la bande de 5 m (≈ 14,75 m² ici). Non dessiné. (source : p. 140)
- **Distance à une gare** — Estimation : environ 700 m de la gare de Lozère, plus de 1,5 km de Palaiseau. Hors du rayon de 500 m où le stationnement exigé est plafonné ; à vérifier sur le plan annexé au PLU. (source : p. 6-7 ; L151-35 et L151-36 du code de l'urbanisme)

## Côtés de la parcelle (déduits du cadastre)

- laterale_1 : 34.79 m — voisin 91477000BO0164
- voie_2 : 14.75 m — Avenue du Général Leclerc (axe à 8.9 m)
- laterale_3 : 35.26 m — voisin 91477000BO0159
- fond_4 : 14.95 m — voisin 91477000BO0161


--- fichier créé : resultats.json ---
{"pas_m": 0.25, "repere": {"eu": [0.9940968587073559, -0.10849624651649174], "ev": [0.10849624651649174, 0.9940968587073559], "u0": -7.986835910049617, "v0": -16.660949430876443, "nu": 64, "nv": 142, "voie_ref": "voie_2"}, "cellules": [[4, 0], [5, 0], [6, 0], [7, 0], [8, 0], [9, 0], [10, 0], [11, 0], [12, 0], [13, 0], [14, 0], [15, 0], [16, 0], [17, 0], [18, 0], [19, 0], [20, 0], [21, 0], [22, 0], [23, 0], [24, 0], [25, 0], [26, 0], [27, 0], [28, 0], [29, 0], [30, 0], [31, 0], [32, 0], [33, 0], [34, 0], [35, 0], [36, 0], [37, 0], [38, 0], [39, 0], [40, 0], [41, 0], [42, 0], [43, 0], [44, 0], [45, 0], [46, 0], [47, 0], [48, 0], [49, 0], [50, 0], [51, 0], [52, 0], [53, 0], [54, 0], [55, 0], [56, 0], [57, 0], [58, 0], [59, 0], [60, 0], [61, 0], [62, 0], [4, 1], [5, 1], [6, 1], [7, 1], [8, 1], [9, 1], [10, 1], [11, 1], [12, 1], [13, 1], [14, 1], [15, 1], [16, 1], [17, 1], [18, 1], [19, 1], [20, 1], [21, 1], [22, 1], [23, 1], [24, 1], [25, 1], [26, 1], [27, 1], [28, 1], [29, 1], [30, 1], [31, 1], [32, 1], [33, 1], [34, 1], [35, 1], [36, 1], [37, 1], [38, 1], [39, 1], [40, 1], [41, 1], [42, 1], [43, 1], [44, 1], [45, 1], [46, 1], [47, 1], [48, 1], [49, 1], [50, 1], [51, 1], [52, 1], [53, 1], [54, 1], [55, 1], [56, 1], [57, 1], [58, 1], [59, 1], [60, 1], [61, 1], [62, 1], [4, 2], [5, 2], [6, 2], [7, 2], [8, 2], [9, 2], [10, 2], [11, 2], [12, 2], [13, 2], [14, 2], [15, 2], [16, 2], [17, 2], [18, 2], [19, 2], [20, 2], [21, 2], [22, 2], [23, 2], [24, 2], [25, 2], [26, 2], [27, 2], [28, 2], [29, 2], [30, 2], [31, 2], [32, 2], [33, 2], [34, 2], [35, 2], [36, 2], [37, 2], [38, 2], [39, 2], [40, 2], [41, 2], [42, 2], [43, 2], [44, 2], [45, 2], [46, 2], [47, 2], [48, 2], [49, 2], [50, 2], [51, 2], [52, 2], [53, 2], [54, 2], [55, 2], [56, 2], [57, 2], [58, 2], [59, 2], [60, 2], [61, 2], [62, 2], [4, 3], [5, 3], [6, 3], [7, 3], [8, 3], [9, 3], [10, 3], [11, 3], [12, 3], [13, 3], [14, 3], [15, 3], [16, 3], [17, 3], [18, 3], [19, 3], [20, 3], [21, 3], [22, 3], [23, 3], [24, 3], [25, 3], [26, 3], [27, 3], [28, 3], [29, 3], [30, 3], [31, 3], [32, 3], [33, 3], [34, 3], [35, 3], [36, 3], [37, 3], [38, 3], [39, 3], [40, 3], [41, 3], [42, 3], [43, 3], [44, 3], [45, 3], [46, 3], [47, 3], [48, 3], [49, 3], [50, 3], [51, 3], [52, 3], [53, 3], [54, 3], [55, 3], [56, 3], [57, 3], [58, 3], [59, 3], [60, 3], [61, 3], [62, 3], [4, 4], [5, 4], [6, 4], [7, 4], [8, 4], [9, 4], [10, 4], [11, 4], [12, 4], [13, 4], [14, 4], [15, 4], [16, 4], [17, 4], [18, 4], [19, 4], [20, 4], [21, 4], [22, 4], [23, 4], [24, 4], [25, 4], [26, 4], [27, 4], [28, 4], [29, 4], [30, 4], [31, 4], [32, 4], [33, 4], [34, 4], [35, 4], [36, 4], [37, 4], [38, 4], [39, 4], [40, 4], [41, 4], [42, 4], [43, 4], [44, 4], [45, 4], [46, 4], [47, 4], [48, 4], [49, 4], [50, 4], [51, 4], [52, 4], [53, 4], [54, 4], [55, 4], [56, 4], [57, 4], [58, 4], [59, 4], [60, 4], [61, 4], [62, 4], [4, 5], [5, 5], [6, 5], [7, 5], [8, 5], [9, 5], [10, 5], [11, 5], [12, 5], [13, 5], [14, 5], [15, 5], [16, 5], [17, 5], [18, 5], [19, 5], [20, 5], [21, 5], [22, 5], [23, 5], [24, 5], [25, 5], [26, 5], [27, 5], [28, 5], [29, 5], [30, 5], [31, 5], [32, 5], [33, 5], [34, 5], [35, 5], [36, 5], [37, 5], [38, 5], [39, 5], [40, 5], [41, 5], [42, 5], [43, 5], [44, 5], [45, 5], [46, 5], [47, 5], [48, 5], [49, 5], [50, 5], [51, 5], [52, 5], [53, 5], [54, 5], [55, 5], [56, 5], [57, 5], [58, 5], [59, 5], [60, 5], [61, 5], [62, 5], [4, 6], [5, 6], [6, 6], [7, 6], [8, 6], [9, 6], [10, 6], [11, 6], [12, 6], [13, 6], [14, 6], [15, 6], [16, 6], [17, 6], [18, 6], [19, 6], [20, 6], [21, 6], [22, 6], [23, 6], [24, 6], [25, 6], [26, 6], [27, 6], [28, 6], [29, 6], [30, 6], [31, 6], [32, 6], [33, 6], [34, 6], [35, 6], [36, 6], [37, 6], [38, 6], [39, 6], [40, 6], [41, 6], [42, 6], [43, 6], [44, 6], [45, 6], [46, 6], [47, 6], [48, 6], [49, 6], [50, 6], [51, 6], [52, 6], [53, 6], [54, 6], [55, 6], [56, 6], [57, 6], [58, 6], [59, 6], [60, 6], [61, 6], [62, 6], [4, 7], [5, 7], [6, 7], [7, 7], [8, 7], [9, 7], [10, 7], [11, 7], [12, 7], [13, 7], [14, 7], [15, 7], [16, 7], [17, 7], [18, 7], [19, 7], [20, 7], [21, 7], [22, 7], [23, 7], [24, 7], [25, 7], [26, 7], [27, 7], [28, 7], [29, 7], [30, 7], [31, 7], [32, 7], [33, 7], [34, 7], [35, 7], [36, 7], [37, 7], [38, 7], [39, 7], [40, 7], [41, 7], [42, 7], [43, 7], [44, 7], [45, 7], [46, 7], [47, 7], [48, 7], [49, 7], [50, 7], [51, 7], [52, 7], [53, 7], [54, 7], [55, 7], [56, 7], [57, 7], [58, 7], [59, 7], [60, 7], [61, 7], [62, 7], [4, 8], [5, 8], [6, 8], [7, 8], [8, 8], [9, 8], [10, 8], [11, 8], [12, 8], [13, 8], [14, 8], [15, 8], [16, 8], [17, 8], [18, 8], [19, 8], [20, 8], [21, 8], [22, 8], [23, 8], [24, 8], [25, 8], [26, 8], [27, 8], [28, 8], [29, 8], [30, 8], [31, 8], [32, 8], [33, 8], [34, 8], [35, 8], [36, 8], [37, 8], [38, 8], [39, 8], [40, 8], [41, 8], [42, 8], [43, 8], [44, 8], [45, 8], [46, 8], [47, 8], [48, 8], [49, 8], [50, 8], [51, 8], [52, 8], [53, 8], [54, 8], [55, 8], [56, 8], [57, 8], [58, 8], [59, 8], [60, 8], [61, 8], [62, 8], [4, 9], [5, 9], [6, 9], [7, 9], [8, 9], [9, 9], [10, 9], [11, 9], [12, 9], [13, 9], [14, 9], [15, 9], [16, 9], [17, 9], [18, 9], [19, 9], [20, 9], [21, 9], [22, 9], [23, 9], [24, 9], [25, 9], [26, 9], [27, 9], [28, 9], [29, 9], [30, 9], [31, 9], [32, 9], [33, 9], [34, 9], [35, 9], [36, 9], [37, 9], [38, 9], [39, 9], [40, 9], [41, 9], [42, 9], [43, 9], [44, 9], [45, 9], [46, 9], [47, 9], [48, 9], [49, 9], [50, 9], [51, 9], [52, 9], [53, 9], [54, 9], [55, 9], [56, 9], [57, 9], [58, 9], [59, 9], [60, 9], [61, 9], [62, 9], [4, 10], [5, 10], [6, 10], [7, 10], [8, 10], [9, 10], [10, 10], [11, 10], [12, 10], [13, 10], [14, 10], [15, 10], [16, 10], [17, 10], [18, 10], [19, 10], [20, 10], [21, 10], [22, 10], [23, 10], [24, 10], [25, 10], [26, 10], [27, 10], [28, 10], [29, 10], [30, 10], [31, 10], [32, 10], [33, 10], [34, 10], [35, 10], [36, 10], [37, 10], [38, 10], [39, 10], [40, 10], [41, 10], [42, 10], [43, 10], [44, 10], [45, 10], [46, 10], [47, 10], [48, 10], [49, 10], [50, 10], [51, 10], [52, 10], [53, 10], [54, 10], [55, 10], [56, 10], [57, 10], [58, 10], [59, 10], [60, 10], [61, 10], [62, 10], [4, 11], [5, 11], [6, 11], [7, 11], [8, 11], [9, 11], [10, 11], [11, 11], [12, 11], [13, 11], [14, 11], [15, 11], [16, 11], [17, 11], [18, 11], [19, 11], [20, 11], [21, 11], [22, 11], [23, 11], [24, 11], [25, 11], [26, 11], [27, 11], [28, 11], [29, 11], [30, 11], [31, 11], [32, 11], [33, 11], [34, 11], [35, 11], [36, 11], [37, 11], [38, 11], [39, 11], [40, 11], [41, 11], [42, 11], [43, 11], [44, 11], [45, 11], [46, 11], [47, 11], [48, 11], [49, 11], [50, 11], [51, 11], [52, 11], [53, 11], [54, 11], [55, 11], [56, 11], [57, 11], [58, 11], [59, 11], [60, 11], [61, 11], [62, 11], [4, 12], [5, 12], [6, 12], [7, 12], [8, 12], [9, 12], [10, 12], [11, 12], [12, 12], [13, 12], [14, 12], [15, 12], [16, 12], [17, 12], [18, 12], [19, 12], [20, 12], [21, 12], [22, 12], [23, 12], [24, 12], [25, 12], [26, 12], [27, 12], [28, 12], [29, 12], [30, 12], [31, 12], [32, 12], [33, 12], [34, 12], [35, 12], [36, 12], [37, 12], [38, 12], [39, 12], [40, 12], [41, 12], [42, 12], [43, 12], [44, 12], [45, 12], [46, 12], [47, 12], [48, 12], [49, 12], [50, 12], [51, 12], [52, 12], [53, 12], [54, 12], [55, 12], [56, 12], [57, 12], [58, 12], [59, 12], [60, 12], [61, 12], [62, 12], [4, 13], [5, 13], [6, 13], [7, 13], [8, 13], [9, 13], [10, 13], [11, 13], [12, 13], [13, 13], [14, 13], [15, 13], [16, 13], [17, 13], [18, 13], [19, 13], [20, 13], [21, 13], [22, 13], [23, 13], [24, 13], [25, 13], [26, 13], [27, 13], [28, 13], [29, 13], [30, 13], [31, 13], [32, 13], [33, 13], [34, 13], [35, 13], [36, 13], [37, 13], [38, 13], [39, 13], [40, 13], [41, 13], [42, 13], [43, 13], [44, 13], [45, 13], [46, 13], [47, 13], [48, 13], [49, 13], [50, 13], [51, 13], [52, 13], [53, 13], [54, 13], [55, 13], [56, 13], [57, 13], [58, 13], [59, 13], [60, 13], [61, 13], [62, 13], [4, 14], [5, 14], [6, 14], [7, 14], [8, 14], [9, 14], [10, 14], [11, 14], [12, 14], [13, 14], [14, 14], [15, 14], [16, 14], [17, 14], [18, 14], [19, 14], [20, 14], [21, 14], [22, 14], [23, 14], [24, 14], [25, 14], [26, 14], [27, 14], [28, 14], [29, 14], [30, 14], [31, 14], [32, 14], [33, 14], [34, 14], [35, 14], [36, 14], [37, 14], [38, 14], [39, 14], [40, 14], [41, 14], [42, 14], [43, 14], [44, 14], [45, 14], [46, 14], [47, 14], [48, 14], [49, 14], [50, 14], [51, 14], [52, 14], [53, 14], [54, 14], [55, 14], [56, 14], [57, 14], [58, 14], [59, 14], [60, 14], [61, 14], [62, 14], [4, 15], [5, 15], [6, 15], [7, 15], [8, 15], [9, 15], [10, 15], [11, 15], [12, 15], [13, 15], [14, 15], [15, 15], [16, 15], [17, 15], [18, 15], [19, 15], [20, 15], [21, 15], [22, 15], [23, 15], [24, 15], [25, 15], [26, 15], [27, 15], [28, 15], [29, 15], [30, 15], [31, 15], [32, 15], [33, 15], [34, 15], [35, 15], [36, 15], [37, 15], [38, 15], [39, 15], [40, 15], [41, 15], [42, 15], [43, 15], [44, 15], [45, 15], [46, 15], [47, 15], [48, 15], [49, 15], [50, 15], [51, 15], [52, 15], [53, 15], [54, 15], [55, 15], [56, 15], [57, 15], [58, 15], [59, 15], [60, 15], [61, 15], [62, 15], [4, 16], [5, 16], [6, 16], [7, 16], [8, 16], [9, 16], [10, 16], [11, 16], [12, 16], [13, 16], [14, 16], [15, 16], [16, 16], [17, 16], [18, 16], [19, 16], [20, 16], [21, 16], [22, 16], [23, 16], [24, 16], [25, 16], [26, 16], [27, 16], [28, 16], [29, 16], [30, 16], [31, 16], [32, 16], [33, 16], [34, 16], [35, 16], [36, 16], [37, 16], [38, 16], [39, 16], [40, 16], [41, 16], [42, 16], [43, 16], [44, 16], [45, 16], [46, 16], [47, 16], [48, 16], [49, 16], [50, 16], [51, 16], [52, 16], [53, 16], [54, 16], [55, 16], [56, 16], [57, 16], [58, 16], [59, 16], [60, 16], [61, 16], [62, 16], [4, 17], [5, 17], [6, 17], [7, 17], [8, 17], [9, 17], [10, 17], [11, 17], [12, 17], [13, 17], [14, 17], [15, 17], [16, 17], [17, 17], [18, 17], [19, 17], [20, 17], [21, 17], [22, 17], [23, 17], [24, 17], [25, 17], [26, 17], [27, 17], [28, 17], [29, 17], [30, 17], [31, 17], [32, 17], [33, 17], [34, 17], [35, 17], [36, 17], [37, 17], [38, 17], [39, 17], [40, 17], [41, 17], [42, 17], [43, 17], [44, 17], [45, 17], [46, 17], [47, 17], [48, 17], [49, 17], [50, 17], [51, 17], [52, 17], [53, 17], [54, 17], [55, 17], [56, 17], [57, 17], [58, 17], [59, 17], [60, 17], [61, 17], [62, 17], [4, 18], [5, 18], [6, 18], [7, 18], [8, 18], [9, 18], [10, 18], [11, 18], [12, 18], [13, 18], [14, 18], [15, 18], [16, 18], [17, 18], [18, 18], [19, 18], [20, 18], [21, 18], [22, 18], [23, 18], [24, 18], [25, 18], [26, 18], [27, 18], [28, 18], [29, 18], [30, 18], [31, 18], [32, 18], [33, 18], [34, 18], [35, 18], [36, 18], [37, 18], [38, 18], [39, 18], [40, 18], [41, 18], [42, 18], [43, 18], [44, 18], [45, 18], [46, 18], [47, 18], [48, 18], [49, 18], [50, 18], [51, 18], [52, 18], [53, 18], [54, 18], [55, 18], [56, 18], [57, 18], [58, 18], [59, 18], [60, 18], [61, 18], [62, 18], [4, 19], [5, 19], [6, 19], [7, 19], [8, 19], [9, 19], [10, 19], [11, 19], [12, 19], [13, 19], [14, 19], [15, 19], [16, 19], [17, 19], [18, 19], [19, 19], [20, 19], [21, 19], [22, 19], [23, 19], [24, 19], [25, 19], [26, 19], [27, 19], [28, 19], [29, 19], [30, 19], [31, 19], [32, 19], [33, 19], [34, 19], [35, 19], [36, 19], [37, 19], [38, 19], [39, 19], [40, 19], [41, 19], [42, 19], [43, 19], [44, 19], [45, 19], [46, 19], [47, 19], [48, 19], [49, 19], [50, 19], [51, 19], [52, 19], [53, 19], [54, 19], [55, 19], [56, 19], [57, 19], [58, 19], [59, 19], [60, 19], [61, 19], [62, 19], [4, 20], [5, 20], [6, 20], [7, 20], [8, 20], [9, 20], [10, 20], [11, 20], [12, 20], [13, 20], [14, 20], [15, 20], [16, 20], [17, 20], [18, 20], [19, 20], [20, 20], [21, 20], [22, 20], [23, 20], [24, 20], [25, 20], [26, 20], [27, 20], [28, 20], [29, 20], [30, 20], [31, 20], [32, 20], [33, 20], [34, 20], [35, 20], [36, 20], [37, 20], [38, 20], [39, 20], [40, 20], [41, 20], [42, 20], [43, 20], [44, 20], [45, 20], [46, 20], [47, 20], [48, 20], [49, 20], [50, 20], [51, 20], [52, 20], [53, 20], [54, 20], [55, 20], [56, 20], [57, 20], [58, 20], [59, 20], [60, 20], [61, 20], [62, 20], [4, 21], [5, 21], [6, 21], [7, 21], [8, 21], [9, 21], [10, 21], [11, 21], [12, 21], [13, 21], [14, 21], [15, 21], [16, 21], [17, 21], [18, 21], [19, 21], [20, 21], [21, 21], [22, 21], [23, 21], [24, 21], [25, 21], [26, 21], [27, 21], [28, 21], [29, 21], [30, 21], [31, 21], [32, 21], [33, 21], [34, 21], [35, 21], [36, 21], [37, 21], [38, 21], [39, 21], [40, 21], [41, 21], [42, 21], [43, 21], [44, 21], [45, 21], [46, 21], [47, 21], [48, 21], [49, 21], [50, 21], [51, 21], [52, 21], [53, 21], [54, 21], [55, 21], [56, 21], [57, 21], [58, 21], [59, 21], [60, 21], [61, 21], [62, 21], [4, 22], [5, 22], [6, 22], [7, 22], [8, 22], [9, 22], [10, 22], [11, 22], [12, 22], [13, 22], [14, 22], [15, 22], [16, 22], [17, 22], [18, 22], [19, 22], [20, 22], [21, 22], [22, 22], [23, 22], [24, 22], [25, 22], [26, 22], [27, 22], [28, 22], [29, 22], [30, 22], [31, 22], [32, 22], [33, 22], [34, 22], [35, 22], [36, 22], [37, 22], [38, 22], [39, 22], [40, 22], [41, 22], [42, 22], [43, 22], [44, 22], [45, 22], [46, 22], [47, 22], [48, 22], [49, 22], [50, 22], [51, 22], [52, 22], [53, 22], [54, 22], [55, 22], [56, 22], [57, 22], [58, 22], [59, 22], [60, 22], [61, 22], [62, 22], [4, 23], [5, 23], [6, 23], [7, 23], [8, 23], [9, 23], [10, 23], [11, 23], [12, 23], [13, 23], [14, 23], [15, 23], [16, 23], [17, 23], [18, 23], [19, 23], [20, 23], [21, 23], [22, 23], [23, 23], [24, 23], [25, 23], [26, 23], [27, 23], [28, 23], [29, 23], [30, 23], [31, 23], [32, 23], [33, 23], [34, 23], [35, 23], [36, 23], [37, 23], [38, 23], [39, 23], [40, 23], [41, 23], [42, 23], [43, 23], [44, 23], [45, 23], [46, 23], [47, 23], [48, 23], [49, 23], [50, 23], [51, 23], [52, 23], [53, 23], [54, 23], [55, 23], [56, 23], [57, 23], [58, 23], [59, 23], [60, 23], [61, 23], [62, 23], [4, 24], [5, 24], [6, 24], [7, 24], [8, 24], [9, 24], [10, 24], [11, 24], [12, 24], [13, 24], [14, 24], [15, 24], [16, 24], [17, 24], [18, 24], [19, 24], [20, 24], [21, 24], [22, 24], [23, 24], [24, 24], [25, 24], [26, 24], [27, 24], [28, 24], [29, 24], [30, 24], [31, 24], [32, 24], [33, 24], [34, 24], [35, 24], [36, 24], [37, 24], [38, 24], [39, 24], [40, 24], [41, 24], [42, 24], [43, 24], [44, 24], [45, 24], [46, 24], [47, 24], [48, 24], [49, 24], [50, 24], [51, 24], [52, 24], [53, 24], [54, 24], [55, 24], [56, 24], [57, 24], [58, 24], [59, 24], [60, 24], [61, 24], [62, 24], [3, 25], [4, 25], [5, 25], [6, 25], [7, 25], [8, 25], [9, 25], [10, 25], [11, 25], [12, 25], [13, 25], [14, 25], [15, 25], [16, 25], [17, 25], [18, 25], [19, 25], [20, 25], [21, 25], [22, 25], [23, 25], [24, 25], [25, 25], [26, 25], [27, 25], [28, 25], [29, 25], [30, 25], [31, 25], [32, 25], [33, 25], [34, 25], [35, 25], [36, 25], [37, 25], [38, 25], [39, 25], [40, 25], [41, 25], [42, 25], [43, 25], [44, 25], [45, 25], [46, 25], [47, 25], [48, 25], [49, 25], [50, 25], [51, 25], [52, 25], [53, 25], [54, 25], [55, 25], [56, 25], [57, 25], [58, 25], [59, 25], [60, 25], [61, 25], [62, 25], [3, 26], [4, 26], [5, 26], [6, 26], [7, 26], [8, 26], [9, 26], [10, 26], [11, 26], [12, 26], [13, 26], [14, 26], [15, 26], [16, 26], [17, 26], [18, 26], [19, 26]

--- fichier créé : verdict.html ---
<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8"><style>
html,body{margin:0;width:1080px;height:1920px;background:#F3EFE6;color:#1E1E1C;font-family:"Helvetica Neue",Helvetica,Arial,sans-serif}
.p{position:absolute;inset:0;padding:120px 84px;box-sizing:border-box;display:flex;flex-direction:column}
.k{font:600 28px/1 "Courier New",monospace;letter-spacing:.12em;color:#8C867B;text-transform:uppercase}
.annonce{margin-top:26px;font-size:46px;font-weight:700;line-height:1.15}
.parc{margin-top:54px;border-top:3px solid #1E1E1C;padding-top:22px;font-size:36px;line-height:1.35}
.parc b{font-weight:800}
.lignes{margin-top:46px}
.l{display:flex;justify-content:space-between;align-items:baseline;gap:24px;border-bottom:1px solid #d8d1c3;padding:20px 0;font-size:36px}
.l .r{color:#4b473f}.l .v{font-weight:800;text-align:right;font-variant-numeric:tabular-nums}
.l .s{display:block;font-size:24px;color:#8C867B;font-weight:400;margin-top:4px}
.bas{margin-top:auto}
.chiffre{font-size:200px;font-weight:900;letter-spacing:-.03em;line-height:1;color:#1E1E1C}
.leg{font-size:42px;font-weight:700;margin-top:14px}
.sous{font-size:40px;margin-top:22px;color:#4b473f}
.src{font-size:22px;color:#8C867B;margin-top:46px;line-height:1.4}
</style></head><body><div class="p">
<div class="k">L'annonce</div><div class="annonce">Terrain à bâtir · 535 m² · 329 000 €</div>
<div class="parc"><b>Palaiseau · 91477 BO 0160 · 535 m² au cadastre</b><br>UR1 · zone résidentielle (PLU du 24/03/2025)</div>
<div class="lignes"><div class="l"><span class="r">Emprise au sol<span class=s>p. 138</span></span><span class="v">35 % → 182 m²</span></div><div class="l"><span class="r">Hauteur (bande des 25 m)<span class=s>p. 138</span></span><span class="v">7 m égout · 11,5 m faîte</span></div><div class="l"><span class="r">Recul sur la voie<span class=s>p. 139</span></span><span class="v">5 m</span></div><div class="l"><span class="r">Latérales sans vues<span class=s>p. 143</span></span><span class="v">H/2 ≥ 2,5 m → 3 m</span></div><div class="l"><span class="r">Retrait d&#x27;une limite au choix<span class=s>p. 143</span></span><span class="v">12 m du fond</span></div><div class="l"><span class="r">Pleine terre<span class=s>p. 150</span></span><span class="v">40 % → 208 m²</span></div></div>
<div class="bas"><div class="k">Ce que tu peux construire</div><div class="chiffre">≈ 297 m²</div>
<div class="leg">de plancher (brut, indicatif) · R+1, 8,3 × 18 m</div><div class="sous">≈ 1 110 € par m² constructible</div><div class="src">cadastre IGN, Géoportail de l&#x27;urbanisme, règlement de la zone UR p. 138-150 · enveloppe maximale théorique, volume indicatif, pas une autorisation de construire</div></div>
</div></body></html>

--- fichier créé : verdict.json ---
{
  "annonce": "Terrain à bâtir · 535 m² · 329 000 €",
  "parcelle": "Palaiseau · 91477 BO 0160 · 535 m² au cadastre",
  "zone": "UR1 · zone résidentielle (PLU du 24/03/2025)",
  "constructible": true,
  "chiffre": "≈ 297 m²",
  "chiffre_legende": "de plancher (brut, indicatif) · R+1, 8,3 × 18 m",
  "sous_chiffre": "≈ 1 110 € par m² constructible",
  "lignes": [
    {"regle": "Emprise au sol", "valeur": "35 % → 182 m²", "source": "p. 138"},
    {"regle": "Hauteur (bande des 25 m)", "valeur": "7 m égout · 11,5 m faîte", "source": "p. 138"},
    {"regle": "Recul sur la voie", "valeur": "5 m", "source": "p. 139"},
    {"regle": "Latérales sans vues", "valeur": "H/2 ≥ 2,5 m → 3 m", "source": "p. 143"},
    {"regle": "Retrait d'une limite au choix", "valeur": "12 m du fond", "source": "p. 143"},
    {"regle": "Pleine terre", "valeur": "40 % → 208 m²", "source": "p. 150"}
  ],
  "sources": "cadastre IGN, Géoportail de l'urbanisme, règlement de la zone UR p. 138-150 · enveloppe maximale théorique, volume indicatif, pas une autorisation de construire"
}
