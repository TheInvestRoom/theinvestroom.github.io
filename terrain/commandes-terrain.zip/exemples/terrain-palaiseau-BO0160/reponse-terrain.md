J'ai retrouvé le terrain au cadastre : c'est très probablement la parcelle **91477 BO 0160** à Palaiseau. Elle est en zone **UR1** (résidentielle), donc constructible. La fiche « 0 m² » ne s'applique pas.

## La parcelle

- **Référence :** 91477 BO 0160, avenue du Général Leclerc. Contenance cadastrale 535 m², surface calculée sur le plan 520 m². Aucun bâtiment.
- **Pourquoi elle :** sur l'avenue, c'est la seule parcelle à exactement 535 m². Sa façade sur l'avenue mesure 14,75 m, ce qui colle avec « environ 15 m ». Elle fait environ 35 m de profondeur.
- **Autres candidates (à 3 % de la surface) :** BT 0216 (527 m²), AW 0351 (524), BO 0116 (548), BO 0157 (521), BR 0174 (520), BO 0159 (550), BR 0111 (551). BO 0157 et BO 0159 sont ses voisines. Si le terrain est un lot en cours de division, la parcelle peut être différente. Seul le vendeur ou le notaire peut donner la vraie référence.
- **Pente :** le terrain naturel descend de près de 7 m (de 77,7 à 70,8 m aux sommets). Or le règlement mesure la hauteur « en tout point » depuis le terrain naturel, donc c'est le point bas qui compte. Il faudra un relevé topographique.

## Les règles qui vont brider le volume

Règlement du PLU de Palaiseau modifié le 24 mars 2025, chapitre UR, règles du secteur UR1. Les pages sont celles du PDF, identiques aux numéros imprimés.

1. **12 m d'une des limites séparatives, au choix** (p. 143). Avec 14,75 m de large, ce sera forcément le fond. Avec les 5 m de recul sur la voie (p. 139), il reste une bande d'environ 18 m de profondeur.
2. **Limites latérales : 8 m si la façade a des fenêtres, sinon la moitié de la hauteur à l'égout, avec 2,5 m au minimum** (p. 142-143). 8 m de chaque côté ne laissent rien. Les façades latérales seront donc aveugles, à 3,5 m des limites, soit environ 7,75 m de large. Le règlement permet aussi de bâtir sur une seule limite latérale, sur 10 m de long plus 4 m de prolongement (p. 141).
3. **Hauteur : 7 m à l'égout ou à l'acrotère, 11,50 m au faîtage** dans les 25 m depuis la voie (p. 138). Cela donne un rez-de-chaussée, un étage et des combles.
4. **Emprise au sol : 35 %, soit 187 m²** (p. 138). **Pleine terre : 40 %, soit 214 m²** (p. 150).

Le stationnement est d'une place par tranche entamée de 60 m², par logement (p. 151). Les exemples du règlement donnent 3 places pour 120 m², ce qui impose la formule « partie entière de (surface/60) + 1 ».

## Ce qui reste à vérifier

Les points sont notés dans `regles.json`, du plus lourd au plus léger :
- l'identité de la parcelle, à confirmer par le vendeur ;
- la pente ;
- le plan de zonage, que je n'ai pas consulté : le Géoportail ne signale que le classement sonore de l'avenue, mais une absence dans l'API ne prouve rien ;
- les argiles (étude de sol) ;
- la viabilisation, que l'annonce dit absente.

Tout est dans `terrain-palaiseau-BO0160/` : `annonce.json`, `site.json`, `regles.json`. J'ai vérifié que chaque citation du règlement se retrouve mot pour mot à la page indiquée.

Ce n'est ni un certificat d'urbanisme ni un relevé de géomètre : c'est une lecture de premier niveau du règlement de la zone UR1.

Lance /terrain-volume terrain-palaiseau-BO0160/ pour le volume maximum.

--- fichier créé : candidates.json ---
{
 "rue": "Avenue du Général Leclerc 91120 Palaiseau",
 "surface_annonce": 535.0,
 "candidates": [
  {
   "insee": "91477",
   "section": "BO",
   "numero": "0160",
   "contenance_m2": 535.0,
   "surface_calculee_m2": 520.0,
   "distance_rue_m": 9.9,
   "batiments": 0
  },
  {
   "insee": "91477",
   "section": "BT",
   "numero": "0216",
   "contenance_m2": 527.0,
   "surface_calculee_m2": 534.2,
   "distance_rue_m": 15.9,
   "batiments": 0
  },
  {
   "insee": "91477",
   "section": "AW",
   "numero": "0351",
   "contenance_m2": 524.0,
   "surface_calculee_m2": 578.4,
   "distance_rue_m": 10.5,
   "batiments": 0
  },
  {
   "insee": "91477",
   "section": "BO",
   "numero": "0116",
   "contenance_m2": 548.0,
   "surface_calculee_m2": 564.7,
   "distance_rue_m": 10.1,
   "batiments": 0
  },
  {
   "insee": "91477",
   "section": "BO",
   "numero": "0157",
   "contenance_m2": 521.0,
   "surface_calculee_m2": 522.0,
   "distance_rue_m": 10.0,
   "batiments": 0
  },
  {
   "insee": "91477",
   "section": "BR",
   "numero": "0174",
   "contenance_m2": 520.0,
   "surface_calculee_m2": 521.6,
   "distance_rue_m": 8.0,
   "batiments": 0
  },
  {
   "insee": "91477",
   "section": "BO",
   "numero": "0159",
   "contenance_m2": 550.0,
   "surface_calculee_m2": 533.1,
   "distance_rue_m": 9.9,
   "batiments": 0
  },
  {
   "insee": "91477",
   "section": "BR",
   "numero": "0111",
   "contenance_m2": 551.0,
   "surface_calculee_m2": 558.3,
   "distance_rue_m": 9.0,
   "batiments": 0
  }
 ]
}

--- fichier créé : texte.txt ---

=== PAGE 1 ===
1 
Règlement – PLU approuvé 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
6. RÈGLEMENT 
Plan Local d’Urbanisme (PLU) révisé, approuvé par délibération du 25 juin 2018 
Rectifié par délibération du 10 décembre 2018 
Modification simplifiée approuvée par délibération en date du 28 juin 2021 
Mis en compatibilité par déclaration de projet approuvée par délibération en date du 2 octobre 2023 
Mise à jour constatée par arrêté du 20 février 2025 
Modification approuvée par délibération du 24 mars 2025 
 

=== PAGE 2 ===
2 
Règlement – PLU approuvé 
Règlement conçu pour être imprimé en recto-verso 
 
 
 

=== PAGE 3 ===
3 
Règlement – PLU approuvé 
SOMMAIRE 
 
 
INTRODUCTION ....................................................................................................................................... 5 
ZONE UCV1 ........................................................................................................................................ 19 
ZONE UCV2 ........................................................................................................................................ 44 
ZONE UP ............................................................................................................................................ 67 
ZON UC1 ............................................................................................................................................ 88 
ZONE UC2 ........................................................................................................................................ 111 
ZONE UR .......................................................................................................................................... 134 
ZONE UAE ........................................................................................................................................ 162 
ZONE UL........................................................................................................................................... 185 
ZONE UM ......................................................................................................................................... 203 
ZONE UX .......................................................................................................................................... 219 
ZONE 1AUC ...................................................................................................................................... 238 
ZONE AU .......................................................................................................................................... 261 
ZONE A ............................................................................................................................................ 265 
ZONE N ............................................................................................................................................ 284 
DÉFINITIONS ........................................................................................................................................ 305 
ANNEXES…………………………………………………………………………………………………………………………….………… 313 
 
 
 
 
 

=== PAGE 4 ===
4 
Règlement – PLU approuvé 
 
 

=== PAGE 5 ===
DISPOSITIONS GÉNÉRALES 
5 
Règlement – PLU approuvé 
INTRODUCTION 
 
Le présent règlement est établi conformément aux dispositions des articles L151-8 à L151-42 du Code de 
l’Urbanisme. Il s’applique à l’ensemble du territoire de Palaiseau.  
Le territoire couvert par le Plan Local d’Urbanisme (PLU) est divisé en zones urbaines (U), à urbaniser (AU), 
en zones naturelles et forestières (N) et agricoles (A) dont les délimitations sont reportées sur le plan de 
zonage. 
Les zones urbaines 
- 
UCV 1 : le centre-ville historique  
- 
UCV 2 : l’extension du centre-ville 
- 
UP : les sites de projet en centre-ville (Tronchet et Ferrié/Paveurs de Montrouge) 
- 
UC 1 : les centralités de quartiers historiques (Lozère, Garenne, Pileu) 
- 
UC 2 : les centralités récentes (Camille Claudel, Gare militaire, La Mesure) 
- 
UR 1 : les quartiers résidentiels 
- 
UR 2 : les ensembles pavillonnaires du coteau  
- 
UAE : les zones à vocation économique qui comprennent 3 sous-secteurs 
- 
UL : les zones d’équipements et loisirs 
- 
UM : les emprises ferroviaires 
- 
UX : le quartier de l’Ecole Polytechnique divisé en 5 sous-secteurs, et deux entités distinctes : 
l’ONERA et l’ENSTA 
 
Les zones à urbaniser 
- 
AU : la zone à urbaniser du plateau 
 
Les zones naturelles et agricoles 
- 
N : les espaces naturels avec un sous-secteur (zone NA sur le plateau) et un STECAL (zone NH) 
- 
A : les terrains agricoles du plateau 
 
 
 

=== PAGE 6 ===
DISPOSITIONS GÉNÉRALES 
6 
Règlement – PLU approuvé 
DISPOSITIONS GÉNÉRALES 
 
Accessibilité des personnes handicapées 
En application des dispositions de l’article L152-3 du Code l’urbanisme, l'autorité compétente pour délivrer 
le permis de construire peut, dans des conditions définies par décret en Conseil d'Etat, accorder des 
dérogations à une ou plusieurs règles du plan local d'urbanisme pour autoriser des travaux nécessaires à 
l'accessibilité des personnes handicapées à un logement existant. 
Adaptations mineures 
En application de l’article L 152-3 du Code de l’Urbanisme, les règles et servitudes définies par un Plan Local 
d'Urbanisme ne peuvent faire l'objet d'aucune dérogation, à l'exception des adaptations mineures rendues 
nécessaires par la nature du sol, la configuration des parcelles ou le caractère des constructions 
avoisinantes. 
Aléa retrait-gonflement des argiles  
Le territoire communal comporte des secteurs argileux. Les terrains argileux et marneux sont sensibles à 
l’eau : gonflement sous l’effet de fortes pluies, retrait en cas de sécheresse, et risque de glissement en cas 
de talutage. Des précautions particulières doivent être prises pour terrasser et fonder un ouvrage dans ces 
secteurs. Ces précautions sont rappelées dans la plaquette jointe dans les annexes du P.L.U. 
Aires de stationnement 
En application de l’article L. 151-33, lorsque le bénéficiaire du permis ou de la décision de non-opposition à 
une déclaration préalable ne peut pas satisfaire aux obligations, il peut être tenu quitte de ces obligations 
en justifiant, pour les places qu'il ne peut réaliser lui-même, soit de l'obtention d'une concession à long 
terme dans un parc public de stationnement existant ou en cours de réalisation et situé à proximité de 
l'opération dans la limite de 300 mètres, soit de l'acquisition ou de la concession de places dans un parc 
privé de stationnement répondant aux mêmes conditions. 
Lorsqu'une aire de stationnement a été prise en compte dans le cadre d'une concession à long terme ou 
d'un parc privé de stationnement, au titre des obligations prévues aux deux premiers alinéas du présent 
article, elle ne peut plus être prise en compte, en tout ou en partie, à l'occasion d'une nouvelle autorisation. 
En application de l’article L151-34 du Code de l’urbanisme, le règlement peut ne pas imposer la réalisation 
d'aires de stationnement lors de la construction : 
1° De logements locatifs financés avec un prêt aidé par l'Etat ; 
2° Des établissements assurant l'hébergement des personnes âgées mentionnés au 6° du I de l'article L. 
312-1 du code de l'action sociale et des familles ; 
3° Des résidences universitaires mentionnées à l'article L. 631-12 du code de la construction et de 
l'habitation. 
En application de l’article L151-35 du Code de l’urbanisme il ne peut, nonobstant toute disposition du plan 
local d'urbanisme, être exigé pour les constructions destinées à l'habitation mentionnées aux 1° à 3° de 
l'article L. 151-34 la réalisation de plus d'une aire de stationnement par logement. 

=== PAGE 7 ===
DISPOSITIONS GÉNÉRALES 
7 
Règlement – PLU approuvé 
Toutefois, lorsque les logements mentionnées aux 1° à 3° de l'article L. 151-34 sont situés à moins de cinq 
cents mètres d'une gare ou d'une station de transport public guidé ou de transport collectif en site propre 
figuré sur le plan en annexe du présent PLU et que la qualité de la desserte le permet, il ne peut, nonobstant 
toute disposition du plan local d'urbanisme, être exigé la réalisation de plus de 0,5 aire de stationnement 
par logement conformément à l’article L151-35 du Code de l’urbanisme. 
L'obligation de réaliser des aires de stationnement n'est pas applicable aux travaux de transformation ou 
d'amélioration de bâtiments affectés à des logements locatifs financés avec un prêt aidé par l'Etat, y 
compris dans le cas où ces travaux s'accompagnent de la création de surface de plancher, dans la limite 
d'un plafond fixé par décret en Conseil d'Etat. 
Pour la mise en œuvre des plafonds mentionnés aux premier et deuxième alinéas, la définition des 
établissements assurant l'hébergement des personnes âgées et des résidences universitaires mentionnés 
aux 2° et 3° de l'article L. 151-34 est précisée par décret en Conseil d'Etat. 
Quand les places de stationnement sont créées à l’extérieur, leur aménagement doit faire l’objet d’un 
traitement paysager. 
Dimensions minimales : 
Les places de stationnement doivent avoir une dimension minimale de 2,50 m x 5 m. Toutefois, la largeur 
d’une place peut être de 2,30 m dès lors qu’elle est mesurée entre deux poteaux ou à compter d’un poteau. 
Stationnement pour les véhicules électriques : 
Conformément au Code de la construction et de l’habitation, une part des places à réaliser doit être pré-
équipée pour faciliter l'accueil d'une borne de recharge de véhicule électrique, dotée d'un système 
individuel de comptage des consommations. 
Rappel de l’article R111-14-2 du Code de la construction et de l’habitation :  
Lorsque les bâtiments neufs à usage principal d'habitation groupant au moins deux logements sont équipés 
d'un parc de stationnement, ce parc est alimenté par un circuit électrique spécialisé pour permettre la 
recharge des véhicules électriques ou hybrides rechargeables. 
L'équipement réalisé est relié à un tableau général basse tension en aval du dispositif de mise hors tension 
général de l'installation électrique du bâtiment ou de celui du point de livraison spécifique de l'infrastructure 
de recharge des véhicules électriques ou hybrides rechargeables. 
Lorsque la capacité de ce parc de stationnement est inférieure ou égale à 40 places, 50 % des places de 
stationnement destinées aux véhicules automobiles et deux roues motorisés doivent être conçues de 
manière à pouvoir accueillir ultérieurement un point de recharge pour véhicule électrique ou hybride 
rechargeable, disposant d'un système de mesure permettant une facturation individuelle des 
consommations. Dans ce but, des fourreaux, des chemins de câble ou des conduits sont installés à partir du 
tableau général basse tension de façon à pouvoir desservir au moins 50 % des places destinées aux véhicules 
automobiles et deux roues motorisés, avec un minimum d'une place. 
Lorsque la capacité de ce parc de stationnement est supérieure à 40 places, 75 % des places de 
stationnement destinées aux véhicules automobiles et deux roues motorisés doivent être conçues de 
manière à pouvoir accueillir ultérieurement un point de recharge pour véhicule électrique ou hybride 
rechargeable, disposant d'un système de mesure permettant une facturation individuelle des 
consommations. Dans ce but, des fourreaux, des chemins de câble ou des conduits sont installés à partir du 

=== PAGE 8 ===
DISPOSITIONS GÉNÉRALES 
8 
Règlement – PLU approuvé 
tableau général basse tension de façon à pouvoir desservir au moins 75 % des places destinées aux véhicules 
automobiles et deux roues motorisés. 
Le tableau général basse tension est dimensionné de façon à pouvoir alimenter au moins 20 % de la totalité 
des places de stationnement, avec un minimum d'une place. 
Les passages de câbles desservant les places de stationnement doivent être dimensionnés avec une section 
minimale de 100 mm. 
Les places desservies sont soit des places individuelles, soit un espace commun. 
Un arrêté conjoint des ministres chargés de la construction et de l'énergie précise les modalités d'application 
du présent article, notamment les caractéristiques de dimensionnement des installations électriques 
destinées à la recharge des véhicules électriques ou hybrides rechargeables. 
Bande constructible 
Une bande constructible est délimitée au plan de zonage. Elle est définie d’un côté par l’alignement sur rue 
et de l’autre par la limite de constructibilité. Au-delà de la Bande constructible délimitée aux documents 
graphiques, seuls les constructions annexes et garages, peuvent être implantés. 
Bande inconstructible 
En application des dispositions de l’article L111-6 du Code de l’urbanisme, est délimitée sur le plan de 
zonage, en dehors des espaces urbanisés, une bande inconstructible : 
- 
de 100 mètres de part et d’autre de l’axe de l’autoroute A126 
- 
de 75 mètres de part et d’autre de l’axe de la RD36 
Bâtiments détruits ou démolis 
Au titre de l’article L111-15 du Code de l’Urbanisme, la reconstruction à l'identique d'un bâtiment détruit 
ou démoli depuis moins de dix ans est autorisée nonobstant toute disposition d'urbanisme contraire dès 
lors qu'il a été régulièrement édifié. La construction doit avoir été réalisée conformément à une autorisation 
du droit des sols préalablement obtenue (permis de construire, déclaration préalable…). Cette obligation 
ne s’impose pas pour les constructions anciennes édifiées avant la mise en place des autorisations du droit 
des sols, celles-ci sont réputées régulièrement édifiées. 
Peut également être autorisée, sauf dispositions contraires des documents d'urbanisme et sous réserve des 
dispositions de l'article L 111-23, la restauration d'un bâtiment dont il reste l'essentiel des murs porteurs 
lorsque son intérêt architectural ou patrimonial en justifie le maintien et sous réserve de respecter les 
principales caractéristiques de ce bâtiment. 
Cas d’une copropriété   
À la date d’approbation du règlement, et au sens du présent règlement, dans le cadre d’une copropriété, la 
limite de chaque lot de copropriété a valeur de limite séparative. 
 
 

=== PAGE 9 ===
DISPOSITIONS GÉNÉRALES 
9 
Règlement – PLU approuvé 
Circulations douces 
Des espaces publics dédiés aux circulations douces à maintenir ou développer sont figurés sur le plan de 
zonage au titre de l’article L151-38 du Code de l’urbanisme. Sur ces espaces, la continuité douce doit être 
protégée et valorisée. 
Constructibilité des emplacements réservés 
Conformément à l’article L. 151-41 du Code de l’urbanisme, des emplacements réservés sont définis sur le 
plan de zonage, où sont également définis leur destination, ainsi que les collectivités, services et organismes 
publics bénéficiaires. Les constructions sont interdites sur les terrains, bâtis ou non, compris dans lesdits 
emplacements réservés, sauf exception prévue au Code de l’urbanisme pour les constructions à titre

--- fichier créé : annonce.json ---
{
  "source": "annonce.txt",
  "titre": "TERRAIN À BÂTIR - PALAISEAU (91120)",
  "commune": "Palaiseau",
  "code_postal": "91120",
  "insee": "91477",
  "rue": "Avenue du Général Leclerc",
  "surface_m2": 535,
  "prix_eur": 329000,
  "prix_m2_terrain_eur": 615,
  "promesses": {
    "terrain_a_batir": true,
    "libre_de_constructeur": true,
    "viabilise": false,
    "facade_m": 15,
    "facade_texte": "Façade d'environ 15 m sur l'avenue",
    "autres": ["bien exposé", "proche commerces, écoles et RER B"]
  },
  "reference_cadastrale_donnee": null,
  "parcelle_retenue": {
    "idu": "91477000BO0160",
    "section": "BO",
    "numero": "0160",
    "contenance_cadastrale_m2": 535,
    "facade_sur_voie_m": 14.75,
    "certitude": "très probable, non confirmée par le vendeur",
    "pourquoi": "seule parcelle bordant l'avenue du Général Leclerc dont la contenance cadastrale vaut exactement 535 m² ; non bâtie ; façade sur l'avenue de 14,75 m, cohérente avec « environ 15 m »."
  },
  "autres_candidates": [
    {"ref": "91477 BT 0216", "contenance_m2": 527},
    {"ref": "91477 AW 0351", "contenance_m2": 524},
    {"ref": "91477 BO 0116", "contenance_m2": 548},
    {"ref": "91477 BO 0157", "contenance_m2": 521},
    {"ref": "91477 BR 0174", "contenance_m2": 520},
    {"ref": "91477 BO 0159", "contenance_m2": 550},
    {"ref": "91477 BR 0111", "contenance_m2": 551}
  ]
}


--- fichier créé : regles.json ---
{
  "zone": "UR1",
  "document": {
    "titre": "Palaiseau — PLU, 6. Règlement (révisé le 25 juin 2018, modification approuvée le 24 mars 2025)",
    "date": "2025-03-24",
    "url": "https://data.geopf.fr/annexes/gpu/documents/DU_91477/e6219e2b37cf79f6c55e983adfe5d336/91477_reglement_20250324.pdf",
    "pages_lues": "6-18 (dispositions générales), 134-153 (zone UR), 305-312 (définitions) ; la page du PDF et le numéro imprimé coïncident"
  },
  "regles": [
    {
      "id": "EMP",
      "nom": "Emprise au sol maximale",
      "nom_court": "Emprise 35 %",
      "type": "emprise_max",
      "pourcentage": 35,
      "article": "UR, chap. 2, 1/A",
      "page": 138,
      "citation": "Dans la zone UR1 : L’emprise au sol maximale des constructions est fixée à 35 % de la superficie de l’unité foncière.",
      "lecture": "535 m² × 35 % = 187 m² sur la contenance cadastrale (182 m² sur la surface calculée de 520 m²). L'emprise inclut « tous débords et surplombs » et les terrasses à plus de 60 cm du terrain (définitions, p. 308) : avec 6,9 m de dénivelé, une terrasse côté bas compte vite."
    },
    {
      "id": "PT",
      "nom": "Espace vert de pleine terre",
      "nom_court": "Pleine terre 40 %",
      "type": "pleine_terre_min",
      "pourcentage": 40,
      "article": "UR, chap. 2, 3",
      "page": 150,
      "citation": "Dans la zone UR1, une part de 40 % minimum de la superficie de l’unité foncière doit être conservée en espace vert de pleine terre.",
      "lecture": "214 m² à garder en vraie pleine terre (rien dessous sur 4 m, ni allée, ni stationnement, ni terrasse : définitions p. 308-309). Il reste 535 − 187 − 214 ≈ 134 m² pour l'accès, le stationnement extérieur et les terrasses."
    },
    {
      "id": "RV",
      "nom": "Retrait par rapport à la voie",
      "nom_court": "Recul voie 5 m",
      "type": "retrait",
      "depuis": ["voie"],
      "min": 5,
      "article": "UR, chap. 2, 1/C",
      "page": 139,
      "citation": "Toute nouvelle construction devra être implantée en retrait de la voie existante ouverte à la circulation à la date d’approbation du présent règlement, avec une distance minimum de 5 mètres.",
      "lecture": "5 m comptés depuis la limite de la parcelle sur l'avenue (l'alignement), pas depuis l'axe."
    },
    {
      "id": "H",
      "nom": "Hauteur selon la bande de 25 m",
      "nom_court": "Hauteur 7 / 11,5 m",
      "type": "hauteur_bande",
      "depuis": ["voie"],
      "bandes": [
        {"jusqua": 25, "egout": 7, "acrotere": 7, "faitage": 11.5},
        {"jusqua": null, "egout": 3.5, "acrotere": 4, "faitage": 7}
      ],
      "article": "UR, chap. 2, 1/B",
      "page": 138,
      "citation": "La hauteur des constructions ne doit pas excéder : Dans la bande des 25 mètres comptée à partir de la limite de voirie : - 7 mètres à l’égout du toit ou l’acrotère pour les toitures terrasses, - 11,50 mètres au faîtage. Au-delà de la limite de 25 mètres comptée à partir de la limite de voirie : - 3,5 mètres à l’égout du toit ou 4 mètres à l’acrotère pour les toitures terrasses, - 7 mètres au faîtage",
      "lecture": "La hauteur se mesure « à compter du terrain naturel existant avant travaux en tout point de la construction » (définitions, p. 309) : sur un terrain qui descend de près de 7 m, c'est le point bas qui fixe la hauteur. Avec 5 m de recul et 12 m de retrait au fond, tout le volume tombe dans la bande des 25 m."
    },
    {
      "id": "RLa",
      "groupe": "laterales",
      "variante": "façades avec vues",
      "nom": "Limites latérales, façade avec vues",
      "nom_court": "Latérales 8 m (vues)",
      "type": "retrait",
      "depuis": ["laterale"],
      "min": 8,
      "article": "UR, chap. 2, 1/D",
      "page": 142,
      "citation": "Dans la zone UR1 : En cas d’implantation en retrait de la limite séparative, la distance doit être au moins égale à : - 8 mètres si la façade en vis-à-vis de la limite séparative comporte des ouvertures créant des vues",
      "lecture": "Sur 14,75 m de façade, 8 m des deux côtés ne laissent rien : les latérales seront aveugles (ou une seule fenêtrée, avec l'autre façade en limite)."
    },
    {
      "id": "RLb",
      "groupe": "laterales",
      "indicatif": true,
      "variante": "façades sans vues",
      "nom": "Limites latérales, façade sans vues",
      "nom_court": "Latérales H/2 ≥ 2,5 m",
      "type": "prospect",
      "depuis": ["laterale"],
      "ratio": 0.5,
      "min": 2.5,
      "applique_a": "egout",
      "article": "UR, chap. 2, 1/D",
      "page": 143,
      "citation": "- la moitié de la hauteur à l'égout du toit le plus haut, avec un minimum de 2,5 mètres si la façade en vis-à-vis de la limite séparative ne comporte pas d’ouvertures créant des vues au sens du présent règlement.",
      "lecture": "À 7 m d'égout : 3,5 m de chaque latérale. Le texte vise « l'égout du toit le plus haut » : c'est la hauteur du bâtiment qui fixe le retrait de toute la façade, pas la hauteur point par point ; le prospect incliné dessiné ici est l'enveloppe la plus large, le volume indicatif doit garder 3,5 m."
    },
    {
      "id": "RFa",
      "groupe": "fond",
      "indicatif": true,
      "variante": "façade avec vues",
      "nom": "Fond de parcelle, façade avec vues",
      "nom_court": "Fond 8 m (vues)",
      "type": "retrait",
      "depuis": ["fond"],
      "min": 8,
      "article": "UR, chap. 2, 1/D",
      "page": 142,
      "citation": "Dans la zone UR1 : En cas d’implantation en retrait de la limite séparative, la distance doit être au moins égale à : - 8 mètres si la façade en vis-à-vis de la limite séparative comporte des ouvertures créant des vues",
      "lecture": "Le texte parle des limites séparatives sans distinguer latérales et fond. Ici sans effet propre : le retrait de 12 m (règle R12) s'applique au fond."
    },
    {
      "id": "RFb",
      "groupe": "fond",
      "variante": "façade sans vues",
      "nom": "Fond de parcelle, façade sans vues",
      "nom_court": "Fond H/2 ≥ 2,5 m",
      "type": "prospect",
      "depuis": ["fond"],
      "ratio": 0.5,
      "min": 2.5,
      "applique_a": "egout",
      "article": "UR, chap. 2, 1/D",
      "page": 143,
      "citation": "- la moitié de la hauteur à l'égout du toit le plus haut, avec un minimum de 2,5 mètres si la façade en vis-à-vis de la limite séparative ne comporte pas d’ouvertures créant des vues au sens du présent règlement."
    },
    {
      "id": "R12",
      "nom": "Retrait de 12 m d'une limite au choix",
      "nom_court": "12 m d'une limite",
      "type": "retrait_au_choix",
      "parmi": ["laterale", "fond"],
      "min": 12,
      "article": "UR, chap. 2, 1/D",
      "page": 143,
      "citation": "Par ailleurs, les constructions principales doivent être implantées, en tout point de la construction, en retrait avec un minimum de 12 mètres de l’une des limites séparatives (au choix : latérale ou fond de parcelle).",
      "lecture": "Sur 14,75 m de large, 12 m d'une latérale ne laisseraient que 2,75 m : le choix sera le fond. Profondeur constructible alors : de 5 m à environ 23 m de l'avenue (≈ 18 m)."
    },
    {
      "id": "STAT",
      "nom": "Stationnement des logements",
      "nom_court": "1 place / 60 m² entamés",
      "type": "stationnement",
      "formule": "math.floor(sdp/60) + 1",
      "article": "UR, chap. 2, 4/A",
      "page": 151,
      "citation": "• 1 place de stationnement par tranche consommée de 60 m² de surface de plancher (exemple : obligation de stationnement pour un logement de : 40 m² SDP = 1 place ; 70 m² SDP = 2 places ; 120 m² SDP = 3 places)",
      "lecture": "Les exemples du texte (40 → 1, 70 → 2, 120 → 3) ne collent pas à un arrondi supérieur de sdp/60 (120 → 2) : la formule qui les reproduit est floor(sdp/60) + 1. Elle vaut pour UN logement (une maison) ; pour plusieurs logements, appliquer par logement et ajouter « au moins 1 place de stationnement supplémentaire par tranche de 3 logements » dès 3 logements. 50 % des places (arrondi inférieur) intégrées à la construction ; places commandées interdites si plusieurs logements. Exemple : une maison de 150 m² → 3 places, dont 1 dans la construction."
    }
  ],
  "hypotheses": {
    "hauteur_etage_m": 3.0,
    "pente_toit_max_deg": 45,
    "batiments_existants": "aucun (BD TOPO, 0 bâtiment sur la parcelle)"
  },
  "hypotheses_texte": [
    "Hauteur d'étage de 3,0 m : hypothèse de dessin pour du logement, pas une règle du PLU. Avec 7 m à l'égout : rez-de-chaussée + 1 étage, et des combles sous le faîtage de 11,50 m.",
    "Parcelle retenue : 91477 BO 0160, seule candidate à exactement 535 m² sur l'avenue, façade 14,75 m ≈ « environ 15 m ». Non confirmée par le vendeur.",
    "Secteur UR1 : donné par le Géoportail de l'urbanisme (libellé « UR1 », zone résidentielle). Le règlement n'a qu'un chapitre UR, avec ses règles UR1 et UR2 séparées ; seules les règles UR1 sont reprises.",
    "Latérales traitées sans vues (H/2, 2,5 m minimum), fenêtres sur la rue et le jardin : 8 m des deux côtés ne laisseraient aucune largeur sur 14,75 m.",
    "Retrait de 12 m pris au fond : c'est la seule option qui laisse une largeur utile.",
    "Terrain dessiné plat, alors que les sommets cadastraux vont de 70,8 à 77,7 m (RGE ALTI)."
  ],
  "a_verifier": [
    {
      "sujet": "Identité de la parcelle",
      "court": "BO 0160 à confirmer par le vendeur",
      "pourquoi": "L'annonce ne donne pas la référence. BO 0160 est la seule à 535 m² exactement en bord d'avenue ; si le terrain est un lot en cours de division (BO 0157, 0159, 0160 sont voisines), la parcelle et ses limites changent. Le règlement s'apprécie alors lot par lot.",
      "source": "trouver_parcelle.py ; règlement p. 138"
    },
    {
      "sujet": "Dénivelé de 6,9 m",
      "court": "Pente 6,9 m : hauteur prise au point bas",
      "pourquoi": "La hauteur est mesurée « à compter du terrain naturel existant avant travaux en tout point de la construction » : sur la partie basse (≈ 70,8 m, côté BO 0159), 7 m d'égout se comptent depuis ce point. Le creux au milieu du côté droit peut aussi être un artefact du modèle de terrain. Un relevé topographique est indispensable.",
      "source": "définitions p. 309 ; RGE ALTI"
    },
    {
      "sujet": "Implantation sur une limite latérale",
      "court": "Possible sur 1 latérale, 10 m (+4 m)",
      "pourquoi": "Dans la bande de 25 m, la construction peut s'implanter sur une seule limite latérale (façade ≥ 13 m), sur 10 m au plus, prolongés de 4 m à 4 m de haut. Le calcul ne dessine pas ce cas : il gagnerait environ 3,5 m de largeur sur 10 m de long.",
      "source": "p. 141"
    },
    {
      "sujet": "Plan de zonage non consulté",
      "court": "Plan de zonage : marges, EVP à voir",
      "pourquoi": "Le Géoportail ne rattache à la parcelle qu'une information (classement sonore). Une absence dans l'API n'est pas une preuve d'absence : vérifier sur le plan de zonage et le plan des servitudes (espace vert protégé, marge de reculement, bande constructible, emplacement réservé, corridor écologique).",
      "source": "API Carto GPU ; dispositions générales p. 8-11, 15"
    },
    {
      "sujet": "Retrait-gonflement des argiles",
      "court": "Argiles : étude de sol G1/G2",
      "pourquoi": "La commune comporte des secteurs argileux ; précautions de fondation. Une étude géotechnique est obligatoire à la vente d'un terrain à bâtir en zone d'aléa moyen ou fort.",
      "source": "p. 6"
    },
    {
      "sujet": "Non viabilisé",
      "court": "Non viabilisé : coût des réseaux",
      "pourquoi": "L'annonce le dit : raccordements eau, assainissement, électricité à chiffrer auprès des concessionnaires.",
      "source": "annonce"
    },
    {
      "sujet": "Classement sonore",
      "court": "Voie bruyante cat. 4 : isolation",
      "pourquoi": "« RD categorie 4 » : isolation acoustique renforcée des façades sur l'avenue ; pas d'effet sur le volume.",
      "source": "Géoportail (info-surf) ; p. 16"
    },
    {
      "sujet": "Garage dans la bande de 5 m",
      "court": "Garage possible dans les 5 m",
      "pourquoi": "Un garage peut être construit à l'alignement si son emprise reste sous 20 % de la bande de 5 m (≈ 14,75 m² ici). Non dessiné.",
      "source": "p. 140"
    },
    {
      "sujet": "Distance à une gare",
      "court": "Gare RER > 500 m (à confirmer)",
      "pourquoi": "Estimation : environ 700 m de la gare de Lozère, plus de 1,5 km de Palaiseau. Hors du rayon de 500 m où le stationnement exigé est plafonné ; à vérifier sur le plan annexé au PLU.",
      "source": "p. 6-7 ; L151-35 et L151-36 du code de l'urbanisme"
    }
  ]
}


--- fichier créé : site.json ---
{
 "genere_le": "2026-11-06T01:03",
 "sources": {
  "cadastre": "IGN Parcellaire Express (WFS data.geopf.fr) + API Carto cadastre",
  "batiments_routes": "IGN BD TOPO V3 (WFS data.geopf.fr)",
  "urbanisme": "Géoportail de l'urbanisme via API Carto GPU",
  "altimetrie": "IGN RGE ALTI (data.geopf.fr/altimetrie)"
 },
 "adresse_geocodee": null,
 "parcelle": {
  "idu": "91477000BO0160",
  "commune": "Palaiseau",
  "insee": "91477",
  "section": "BO",
  "numero": "0160",
  "contenance_cadastrale_m2": 535,
  "surface_calculee_m2": 520.0,
  "polygone": [
   [
    -5.975,
    18.868
   ],
   [
    -8.685,
    -15.812
   ],
   [
    5.975,
    -17.412
   ],
   [
    7.425,
    -0.182
   ],
   [
    7.955,
    6.058
   ],
   [
    8.935,
    17.728
   ]
  ]
 },
 "origine_lambert93": [
  643404.25,
  6845164.17
 ],
 "cotes": [
  {
   "type": "separative",
   "segments": [
    [
     -5.975,
     18.868,
     -8.685,
     -15.812
    ]
   ],
   "longueur": 34.79,
   "voisin": "91477000BO0164",
   "route": "Avenue du Général Leclerc",
   "dist_route": 27.3,
   "largeur_chaussee": 5,
   "route_privee": false,
   "emprise_voie_m": null,
   "role": "laterale",
   "id": "laterale_1"
  },
  {
   "type": "voie",
   "segments": [
    [
     -8.685,
     -15.812,
     5.975,
     -17.412
    ]
   ],
   "longueur": 14.75,
   "voisin": null,
   "route": "Avenue du Général Leclerc",
   "dist_route": 8.9,
   "largeur_chaussee": 5,
   "route_privee": false,
   "emprise_voie_m": 19.0,
   "id": "voie_2"
  },
  {
   "type": "separative",
   "segments": [
    [
     5.975,
     -17.412,
     7.425,
     -0.182
    ],
    [
     7.425,
     -0.182,
     7.955,
     6.058
    ],
    [
     7.955,
     6.058,
     8.935,
     17.728
    ]
   ],
   "longueur": 35.26,
   "voisin": "91477000BO0159",
   "route": "Avenue du Général Leclerc",
   "dist_route": 18.6,
   "largeur_chaussee": 5,
   "route_privee": false,
   "emprise_voie_m": null,
   "role": "laterale",
   "id": "laterale_3"
  },
  {
   "type": "separative",
   "segments": [
    [
     8.935,
     17.728,
     -5.975,
     18.868
    ]
   ],
   "longueur": 14.95,
   "voisin": "91477000BO0161",
   "route": "Avenue du Général Leclerc",
   "dist_route": 45.9,
   "largeur_chaussee": 5,
   "route_privee": false,
   "emprise_voie_m": null,
   "role": "fond",
   "id": "fond_4"
  }
 ],
 "voisins": [
  {
   "idu": "91477000BO0167",
   "poly": [
    [
     -44.215,
     -8.262
    ],
    [
     -43.045,
     14.728
    ],
    [
     -42.635,
     22.548
    ],
    [
     -41.245,
     49.648
    ],
    [
     -31.215,
     49.158
    ],
    [
     -29.435,
     49.068
    ],
    [
     -31.075,
     22.098
    ],
    [
     -31.565,
     14.228
    ],
    [
     -33.375,
     -13.052
    ],
    [
     -40.355,
     -9.902
    ]
   ]
  },
  {
   "idu": "91477000BO0145",
   "poly": [
    [
     173.695,
     93.608
    ],
    [
     168.705,
     92.378
    ],
    [
     168.675,
     91.488
    ],
    [
     168.585,
     88.058
    ],
    [
     168.115,
     70.138
    ],
    [
     168.285,
     37.278
    ],
    [
     168.625,
     1.618
    ],
    [
     168.165,
     1.478
    ],
    [
     127.925,
     -8.182
    ],
    [
     98.785,
     -15.482
    ],
    [
     77.335,
     -19.282
    ],
    [
     76.765,
     -3.872
    ],
    [
     76.675,
     -1.582
    ],
    [
     76.325,
     6.958
    ],
    [
     75.015,
     37.478
    ],
    [
     73.865,
     69.898
    ],
    [
     73.795,
     71.928
    ],
    [
     72.985,
     94.658
    ],
    [
     72.935,
     95.678
    ],
    [
     87.595,
     94.478
    ],
    [
     91.825,
     93.978
    ],
    [
     105.345,
     93.168
    ],
    [
     116.055,
     92.848
    ],
    [
     125.985,
     92.578
    ],
    [
     129.735,
     92.488
    ],
    [
     132.425,
     92.498
    ],
    [
     152.385,
     94.558
    ],
    [
     152.535,
     95.848
    ],
    [
     173.465,
     98.138
    ]
   ]
  },
  {
   "idu": "91477000BO0146",
   "poly": [
    [
     77.335,
     -19.282
    ],
    [
     67.125,
     -21.362
    ],
    [
     66.915,
     -21.352
    ],
    [
     66.595,
     -13.542
    ],
    [
     66.195,
     -4.282
    ],
    [
     65.835,
     4.208
    ],
    [
     65.745,
     6.448
    ],
    [
     64.455,
     37.128
    ],
    [
     75.015,
     37.478
    ],
    [
     76.325,
     6.958
    ],
    [
     76.675,
     -1.582
    ],
    [
     76.765,
     -3.872
    ]
   ]
  },
  {
   "idu": "91477000BO0147",
   "poly": [
    [
     75.015,
     37.478
    ],
    [
     64.455,
     37.128
    ],
    [
     63.865,
     51.338
    ],
    [
     63.445,
     61.638
    ],
    [
     62.905,
     74.758
    ],
    [
     62.505,
     83.898
    ],
    [
     61.995,
     95.428
    ],
    [
     72.985,
     94.658
    ],
    [
     73.795,
     71.928
    ],
    [
     73.865,
     69.898
    ]
   ]
  },
  {
   "idu": "91477000BO0148",
   "poly": [
    [
     63.445,
     61.638
    ],
    [
     53.535,
     61.318
    ],
    [
     52.965,
     74.478
    ],
    [
     52.955,
     74.938
    ],
    [
     52.675,
     81.488
    ],
    [
     52.635,
     82.578
    ],
    [
     52.095,
     95.298
    ],
    [
     52.055,
     96.118
    ],
    [
     61.995,
     95.428
    ],
    [
     62.505,
     83.898
    ],
    [
     62.905,
     74.758
    ]
   ]
  },
  {
   "idu": "91477000BO0151",
   "poly": [
    [
     45.725,
     22.498
    ],
    [
     55.155,
     22.888
    ],
    [
     55.995,
     5.178
    ],
    [
     56.045,
     3.988
    ],
    [
     56.445,
     -4.672
    ],
    [
     56.865,
     -13.372
    ],
    [
     57.055,
     -17.682
    ],
    [
     48.145,
     -18.082
    ],
    [
     47.595,
     -18.112
    ],
    [
     46.985,
     -5.032
    ],
    [
     46.575,
     3.968
    ],
    [
     46.545,
     4.748
    ]
   ]
  },
  {
   "idu": "91477000BO0154",
   "poly": [
    [
     45.725,
     22.498
    ],
    [
     46.545,
     4.748
    ],
    [
     46.575,
     3.968
    ],
    [
     46.985,
     -5.032
    ],
    [
     47.595,
     -18.112
    ],
    [
     46.955,
     -18.132
    ],
    [
     37.745,
     -18.552
    ],
    [
     37.635,
     -15.982
    ],
    [
     37.545,
     -14.082
    ],
    [
     37.115,
     -5.432
    ],
    [
     36.645,
     3.608
    ],
    [
     35.715,
     22.098
    ]
   ]
  },
  {
   "idu": "91477000BO0155",
   "poly": [
    [
     45.725,
     22.498
    ],
    [
     35.715,
     22.098
    ],
    [
     34.875,
     38.508
    ],
    [
     32.005,
     96.478
    ],
    [
     42.265,
     95.878
    ],
    [
     44.215,
     55.438
    ],
    [
     45.045,
     37.478
    ],
    [
     45.375,
     30.258
    ]
   ]
  },
  {
   "idu": "91477000BO0156",
   "poly": [
    [
     26.785,
     38.168
    ],
    [
     25.285,
     98.458
    ],
    [
     31.855,
     97.848
    ],
    [
     32.005,
     96.478
    ],
    [
     34.875,
     38.508
    ]
   ]
  },
  {
   "idu": "91477000BO0157",
   "poly": [
    [
     26.785,
     38.168
    ],
    [
     34.875,
     38.508
    ],
    [
     35.715,
     22.098
    ],
    [
     36.645,
     3.608
    ],
    [
     37.115,
     -5.432
    ],
    [
     37.545,
     -14.082
    ],
    [
     37.635,
     -15.982
    ],
    [
     37.745,
     -18.552
    ],
    [
     37.825,
     -20.212
    ],
    [
     33.265,
     -20.072
    ],
    [
     28.015,
     -19.912
    ],
    [
     27.825,
     -7.722
    ],
    [
     27.695,
     -2.142
    ],
    [
     27.535,
     4.708
    ],
    [
     26.805,
     36.978
    ]
   ]
  },
  {
   "idu": "91477000BO0158",
   "poly": [
    [
     22.695,
     16.668
    ],
    [
     23.625,
     16.598
    ],
    [
     24.405,
     -16.502
    ],
    [
     21.415,
     -18.932
    ],
    [
     22.115,
     -10.162
    ],
    [
     22.395,
     -5.732
    ],
    [
     22.715,
     -1.092
    ]
   ]
  },
  {
   "idu": "91477000BO0159",
   "poly": [
    [
     8.935,
     17.728
    ],
    [
     22.695,
     16.668
    ],
    [
     22.715,
     -1.092
    ],
    [
     22.395,
     -5.732
    ],
    [
     22.115,
     -10.162
    ],
    [
     21.415,
     -18.932
    ],
    [
     21.175,
     -19.142
    ],
    [
     5.975,
     -17.412
    ],
    [
     7.425,
     -0.182
    ],
    [
     7.955,
     6.058
    ]
   ]
  },
  {
   "idu": "91477000BO0161",
   "poly": [
    [
     -5.615,
     23.438
    ],
    [
     9.315,
     22.248
    ],
    [
     8.935,
     17.728
    ],
    [
     -5.975,
     18.868
    ]
   ]
  },
  {
   "idu": "91477000BO0162",
   "poly": [
    [
     26.805,
     36.978
    ],
    [
     27.535,
     4.708
    ],
    [
     27.695,
     -2.142
    ],
    [
     27.825,
     -7.722
    ],
    [
     28.015,
     -19.912
    ],
    [
     21.175,
     -19.142
    ],
    [
     21.415,
     -18.932
    ],
    [
     24.405,
     -16.502
    ],
    [
     23.625,
     16.598
    ],
    [
     22.695,
     16.668
    ],
    [
     8.935,
     17.728
    ],
    [
     9.315,
     22.248
    ],
    [
     -5.615,
     23.438
    ],
    [
     -4.385,
     39.178
    ],
    [
     9.975,
     38.168
    ],
    [
     17.715,
     37.618
    ]
   ]
  },
  {
   "idu": "91477000BO0163",
   "poly": [
    [
     26.785,
     38.168
    ],
    [
     26.805,
     36.978
    ],
    [
     17.715,
     37.618
    ],
    [
     9.975,
     38.168
    ],
    [
     -4.385,
     39.178
    ],
    [
     -5.615,
     23.438
    ],
    [
     -13.175,
     24.028
    ],
    [
     -13.605,
     24.068
    ],
    [
     -17.945,
     24.408
    ],
    [
     -17.035,
     38.858
    ],
    [
     -16.425,
     48.448
    ],
    [
     -13.025,
     102.078
    ],
    [
     -12.845,
     102.078
    ],
    [
     25.285,
     98.458
    ]
   ]
  },
  {
   "idu": "91477000BO0164",
   "poly": [
    [
     -5.615,
     23.438
    ],
    [
     -5.975,
     18.868
    ],
    [
     -8.685,
     -15.812
    ],
    [
     -15.085,
     -15.102
    ],
    [
     -18.825,
     -14.712
    ],
    [
     -20.365,
     -14.532
    ],
    [
     -19.325,
     0.358
    ],
    [
     -18.945,
     6.848
    ],
    [
     -18.785,
     9.748
    ],
    [
     -18.735,
     10.638
    ],
    [
     -18.165,
     20.608
    ],
    [
     -17.945,
     24.408
    ],
    [
     -13.605,
     24.068
    ],
    [
     -13.175,
     24.028
    ]
   ]
  },
  {
   "idu": "91477000BO0165",
   "poly": [
    [
     -17.945,
     24.408
    ],
    [
     -18.165,
     20.608
    ],
    [
     -18.735,
     10.638
    ],
    [
     -18.785,
     9.748
    ],
    [
     -18.945,
     6.848
    ],
    [
     -19.325,
     0.358
    ],
    [
     -20.365,
     -14.532
    ],
    [
     -33.375,
     -13.052
    ],
    [
     -31.565,
     14.228
    ],
    [
     -31.075,
     22.098
    ],
    [
     -29.435,
     49.068
    ],
    [
     -16.425,
     48.448
    ],
    [
     -17.035,
     38.858
    ]
   ]
  },
  {
   "idu": "91477000BO0166",
   "poly": [
    [
     -44.505,
     -13.942
    ],
    [
     -44.215,
     -8.262
    ],
    [
     -40.355,
     -9.902
    ],
    [
     -33.375,
     -13.052
    ]
   ]
  },
  {
   "idu": "91477000BO0168",
   "poly": [
    [
     -16.425,
     48.448
    ],
    [
     -29.435,
     49.068
    ],
    [
     -31.215,
     49.158
    ],
    [
     -29.485,
     84.418
    ],
    [
     -29.165,
     90.778
    ],
    [
     -28.845,
     97.318
    ],
    [
     -28.605,
     102.288
    ],
    [
     -13.025,
     102.078
    ]
   ]
  },
  {
   "idu": "91477000BO0169",
   "poly": [
    [
     -41.245,
     49.648
    ],
    [
     -40.935,
     55.948
    ],
    [
     -44.115,
     56.088
    ],
    [
     -48.515,
     56.288
    ],
    [
     -48.235,
     63.578
    ],
    [
     -48.155,
     65.608
    ],
    [
     -47.835,
     73.648
    ],
    [
     -47.715,
     76.798
    ],
    [
     -47.595,
     79.908
    ],
    [
     -46.605,
     79.858
    ],
    [
     -39.765,
     79.548
    ],
    [
     -39.715,
     80.838
    ],
    [
     -39.445,
     88.428
    ],
    [
     -39.395,
     89.958
    ],
    [
     -39.355,
     91.358
    ],
    [
     -39.125,
     97.888
    ],
    [
     -38.965,
     102.438
    ],
    [
     -34.975,
     102.358
    ],
    [
     -28.605,
     102.288
    ],
    [
     -28.845,
     97.318
    ],
    [
     -29.165,
     90.778
    ],
    [
     -29.485,
     84.418
    ],
    [
     -31.215,
     49.158
    ]
   ]
  },
  {
   "idu": "91477000BO0170",
   "poly": [
    [
     -47.595,
     79.908
    ],
    [
     -47.315,
     88.798
    ],
    [
     -47.265,
     90.348
    ],
    [
     -46.935,
     100.308
    ],
    [
     -46.875,
     102.038
    ],
    [
     -40.105,
     102.368
    ],
    [
     -38.965,
     102.438
    ],
    [
     -39.125,
     97.888
    ],
    [
     -39.355,
     91.358
    ],
    [
     -39.395,
     89.958
    ],
    [
     -39.445,
     88.428
    ],
    [
     -39.715,
     80.838
    ],
    [
     -39.765,
     79.548
    ],
    [
     -46.605,
     79.858
    ]
   ]
  },
  {
   "idu": "91477000BO0196",
   "poly": [
    [
     64.455,
     37.128
    ],
    [
     65.745,
     6.448
    ],
    [
     65.835,
     4.208
    ],
    [
     66.195,
     -4.282
    ],
    [
     66.595,
     -13.542
    ],
    [
     66.915,
     -21.352
    ],
    [
     59.255,
     -20.822
    ],
    [
     57.195,
     -20.772
    ],
    [
     57.055,
     -17.682
    ],
    [
     56.865,
     -13.372
    ],
    [
     56.445,
     -4.672
    ],
    [
     56.045,
     3.988
    ],
    [
     55.995,
     5.178
    ],
    [
     55.155,
     22.888
    ],
    [
     53.965,
     50.978
    ],
    [
     63.865,
     51.338
    ]
   ]
  },
  {
   "idu": "91477000BO0197",
   "poly": [
    [
     63.865,
     51.338
    ],
    [
     53.965,
     50.978
    ],
    [
     53.545,
     61.078
    ],
    [
     53.535,
     61.318
    ],
    [
     63.445,
     61.638
    ]
   ]
  },
  {
   "idu": "91477000BO0228",
   "poly": [
    [
     45.725,
     22.498
    ],
    [
     45.375,
     30.258
    ],
    [
     45.045,
     37.478
    ],
    [
     44.215,
     55.438
    ],
    [
     42.265,
     95.878
    ],
    [
     44.045,
     95.768
    ],
    [
     45.635,
     60.718
    ],
    [
     53.545,
     61.078
    ],
    [
     53.965,
     50.978
    ],
    [
     55.155,
     22.888
    ]
   ]
  },
  {
   "idu": "91477000BO0229",
   "poly": [
    [
     53.535,
     61.318
    ],
    [
     53.545,
     61.078
    ],
    [
     45.635,
     60.718
    ],
    [
     44.045,
     95.768
    ],
    [
     52.095,
     95.298
    ],
    [
     52.635,
     82.578
    ],
    [
     52.675,
     81.488
    ],
    [
     52.955,
     74.938
    ],
    [
     52.965,
     74.478
    ]
   ]
  },
  {
   "idu": "91477000BO0244",
   "poly": [
    [
     -46.875,
     102.038
    ],
    [
     -46.935,
   